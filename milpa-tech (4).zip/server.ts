import express from "express";
import path from "path";
import cors from "cors";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import {
  executeGeminiChat,
  generateDomainFallbackReply,
  getGeminiDiagnostics,
  getGeminiClient,
  buildSystemPrompt
} from "./src/server/geminiService";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware
  app.use(cors({
    origin: process.env.CORS_ORIGIN || "*",
    methods: ["GET", "POST", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization", "x-gemini-api-key"]
  }));
  app.use(express.json({ limit: "5mb" }));

  // 1. Health & External Server Diagnostics
  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      uptime: process.uptime(),
      service: "Milpa Tech Fullstack Server",
      timestamp: new Date().toISOString()
    });
  });

  app.get("/api/ai/health", (req, res) => {
    const diagnostics = getGeminiDiagnostics();
    res.json({
      status: "ok",
      ai: diagnostics
    });
  });

  // 2. Standard JSON Chat Endpoint (with Caching & Multi-tier Fallbacks)
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { message, history, lang, cropsContext, userContext } = req.body;

      if (!message || typeof message !== 'string') {
        return res.status(400).json({ error: "Message is required." });
      }

      const result = await executeGeminiChat({
        message,
        history,
        lang,
        cropsContext,
        userContext
      });

      return res.json(result);
    } catch (error: any) {
      console.error("Chat API error:", error?.message || error);
      const fallback = generateDomainFallbackReply(
        req.body?.message || "",
        req.body?.lang || "es",
        req.body?.cropsContext || []
      );
      return res.status(200).json({
        reply: fallback,
        groundingChunks: [],
        source: "fallback"
      });
    }
  });

  // 3. Real-Time Token Streaming Endpoint (Server-Sent Events)
  // Drastically improves Time-To-First-Byte (TTFB) for external servers
  app.post("/api/ai/chat/stream", async (req, res) => {
    const { message, history = [], lang = 'es', cropsContext = [], userContext = null } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: "Message is required." });
    }

    // Set streaming headers for SSE
    res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Accel-Buffering", "no"); // Disable buffering on Nginx reverse proxies
    res.flushHeaders?.();

    const ai = getGeminiClient();

    if (!ai) {
      // Stream domain fallback directly
      const fallback = generateDomainFallbackReply(message, lang, cropsContext);
      res.write(`data: ${JSON.stringify({ chunk: fallback, done: true, source: 'fallback' })}\n\n`);
      return res.end();
    }

    try {
      const systemPrompt = buildSystemPrompt(lang, cropsContext, userContext);
      const contents: any[] = [];

      if (Array.isArray(history) && history.length > 0) {
        history.slice(-8).forEach((h: any) => {
          if (h.role && h.text) {
            contents.push({
              role: h.role === 'user' ? 'user' : 'model',
              parts: [{ text: h.text }]
            });
          }
        });
      }
      contents.push({ role: 'user', parts: [{ text: message }] });

      const responseStream = await ai.models.generateContentStream({
        model: "gemini-3.7-flash",
        contents: contents,
        config: {
          systemInstruction: systemPrompt,
          temperature: 0.7
        }
      });

      for await (const chunk of responseStream) {
        const text = chunk.text;
        if (text) {
          res.write(`data: ${JSON.stringify({ chunk: text, done: false })}\n\n`);
        }
      }

      res.write(`data: ${JSON.stringify({ chunk: "", done: true, source: 'gemini-stream' })}\n\n`);
      res.end();
    } catch (streamErr: any) {
      console.warn("Streaming error on external connection, falling back:", streamErr?.message || streamErr);
      const fallback = generateDomainFallbackReply(message, lang, cropsContext);
      res.write(`data: ${JSON.stringify({ chunk: fallback, done: true, source: 'fallback' })}\n\n`);
      res.end();
    }
  });

  // Vite middleware for dev / static serving for prod
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Milpa Tech fullstack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
