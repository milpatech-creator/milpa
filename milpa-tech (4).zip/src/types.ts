export type Language = 'es' | 'en';

export interface WeatherCondition {
  tempC: number;
  humidityPct: number;
  rainfallMm: number;
  soilMoisturePct: number;
  condition: string;
  conditionEn: string;
  uvIndex: number;
}

export interface DevelopmentLog {
  date: string;
  title: string;
  description: string;
  type: 'IOT' | 'INSPECTION' | 'WEATHER' | 'DRONE' | 'BIODYNAMICS';
}

export interface CropDevelopment {
  stage: string;
  stageEn: string;
  progressPct: number; // 0 to 100
  daysToHarvest: number;
  healthScore: number; // e.g. 96
  lastUpdateDate: string;
  updateNote: string;
  updateNoteEn: string;
  logEvents: DevelopmentLog[];
}

export interface Crop {
  id: string;
  name: string;
  producerName: string;
  producerId?: string;
  location: string;
  type: string;
  imageUrl: string;
  description: string;
  riskLevel: 'BAJO' | 'MEDIO' | 'ALTO' | 'LOW' | 'MEDIUM' | 'HIGH';
  tokenPrice: number;
  previousTokenPrice?: number;
  priceChange24h?: number; // e.g. +4.2 or -1.5
  totalTokens: number;
  soldTokens: number;
  yieldProjection: number;
  harvestDate: string;
  sustainabilityScore: number;
  openseaUrl?: string;
  nftContract?: string;
  nftTokenId?: string;
  nftStandard?: string;
  weather?: WeatherCondition;
  development?: CropDevelopment;
}

export interface MarketplaceItem {
  id: string;
  sellerId: string;
  sellerName: string;
  sellerRole: 'PRODUCER' | 'INVESTOR' | 'TRADER';
  sellerAvatar?: string;
  sellerLocation?: string;
  isVerified?: boolean;
  title: string;
  titleEn?: string;
  category: 'ORGANIC_INPUTS' | 'SEEDS' | 'MACHINERY' | 'SERVICES' | 'LOGISTICS' | 'HARVEST_PRODUCTS';
  description: string;
  priceMxn: number;
  unit: string;
  availableStock: number;
  imageUrl: string;
  escrowProtected?: boolean;
  fraudScore?: number;
  certifications?: string[];
  contactPhone?: string;
  contactEmail?: string;
  createdAt: string;
}

export interface SellerRegistrationApplication {
  id: string;
  userId: string;
  legalName: string;
  rfc: string;
  personType: 'FISICA' | 'MORAL';
  businessCategory: string;
  address: string;
  state: string;
  phone: string;
  email: string;
  sanitaryPermitSENASICA?: string;
  organicCertProof?: string;
  escrowDepositAgreed: boolean;
  termsAccepted: boolean;
  verificationStatus: 'VERIFIED' | 'PENDING';
  fraudRiskAssessment: 'LOW' | 'MEDIUM' | 'HIGH';
  createdAt: string;
}

export interface UserProfile {
  id: string;
  name: string;
  role: 'PRODUCER' | 'INVESTOR' | 'TRADER';
  balance: number;
  avatar: string;
  email?: string;
  walletAddress?: string;
  bio?: string;
  location?: string;
  phone?: string;
  website?: string;
  experienceYears?: number;
  farmHectares?: number;
  tradingVolume?: number;
  certifications?: string[] | string;
  badges?: string[];
  photos?: string[];
  rating?: number;
  reviewCount?: number;
  joinedDate?: string;
  // Security, KYC/AML & Anti-Fraud fields
  isVerifiedSeller?: boolean;
  verificationLevel?: 1 | 2 | 3; // 1: Contact, 2: Tax/RFC, 3: Field-Inspected & Escrow
  kycStatus?: 'TIER_3_FULL' | 'TIER_2_VERIFIED' | 'TIER_1_BASIC' | 'PENDING' | 'UNDER_REVIEW';
  amlStatus?: 'PASSED_CLEAN' | 'CLEAR' | 'UNDER_MONITORING' | 'PENDING';
  kycScore?: number; // e.g. 99.4%
  fraudScore?: number; // 0-100 (e.g. 98)
  kycVerifiedDate?: string;
  kycAuditor?: string;
  amlScreeningScore?: number; // e.g. 99.8
  amlRiskLevel?: 'VERY_LOW' | 'LOW' | 'MEDIUM';
  identityDocumentsVerified?: string[];
  kycCheckpoints?: {
    idDocument?: boolean;
    biometrics?: boolean;
    proofOfAddress?: boolean;
    taxRegistrySat?: boolean;
    pepSanctionsClear?: boolean;
    sourceOfFunds?: boolean;
    agriculturalDeed?: boolean;
    senasicaPermit?: boolean;
  };
  rfcTaxId?: string;
  legalName?: string;
  escrowSecured?: boolean;
  businessCategory?: 'PRODUCER' | 'INPUTS_SUPPLIER' | 'AGRONOMY_SERVICES' | 'LOGISTICS' | 'INVESTMENT_FUND' | 'GRAIN_TRADER';
  online?: boolean;
  activeListingsCount?: number;
}

export interface PeerReview {
  id: string;
  targetUserId: string;
  authorId: string;
  authorName: string;
  authorRole: 'PRODUCER' | 'INVESTOR' | 'TRADER';
  authorAvatar: string;
  rating: number;
  comment: string;
  endorsements?: string[];
  date: string;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  text: string;
  timestamp: string;
  senderName?: string;
  senderAvatar?: string;
  proposalType?: 'GENERAL' | 'INVESTMENT_OFFER' | 'MARKETPLACE_ORDER' | 'SERVICE_INQUIRY';
  proposalDetails?: {
    itemName?: string;
    amount?: number;
    proposedPrice?: number;
  };
}

export interface CardDetails {
  cardNumber: string;
  cardholderName: string;
  expiryDate: string;
  cvv: string;
  postalCode?: string;
  cardBrand: 'VISA' | 'MASTERCARD' | 'AMEX' | 'UNKNOWN';
  cardType: 'CREDIT' | 'DEBIT';
  installments?: number;
  saveCard?: boolean;
}

export interface SavedCard {
  id: string;
  last4: string;
  brand: 'VISA' | 'MASTERCARD' | 'AMEX';
  cardholder: string;
  expiry: string;
  cardType: 'CREDIT' | 'DEBIT';
}

export interface PaymentReceipt {
  transactionId: string;
  authCode: string;
  amountMxn: number;
  itemDescription: string;
  paymentMethod: 'CARD_VISA' | 'CARD_MASTERCARD' | 'CARD_AMEX' | 'WALLET_BALANCE' | 'CRYPTO_POLYGON';
  cardLast4?: string;
  cardBrand?: string;
  installments?: number;
  timestamp: string;
  txHash?: string;
}

export interface Transaction {
  id: string;
  cropName: string;
  cropId?: string;
  userName?: string;
  userRole?: 'PRODUCER' | 'INVESTOR' | 'TRADER';
  amount: number;
  price: number;
  total: number;
  date: string;
  type: 'BUY' | 'SELL' | 'FUND' | 'MINT' | 'MARKETPLACE_BUY' | 'SERVICE_CONTRACT' | 'WALLET_RECHARGE';
  txHash: string;
  blockNumber?: number;
  paymentMethod?: 'CARD_VISA' | 'CARD_MASTERCARD' | 'CARD_AMEX' | 'WALLET_BALANCE' | 'CRYPTO_POLYGON';
  cardBrand?: 'VISA' | 'MASTERCARD' | 'AMEX';
  cardLast4?: string;
  authCode?: string;
  installments?: number;
}


