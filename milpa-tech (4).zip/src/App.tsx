import { useState, useEffect, useRef } from 'react';
import {
  Sprout, X, Menu, ShoppingBag, LayoutDashboard, MessageSquare, Brain,
  Wallet, LogOut, UserPlus, Coins, Shield, ArrowUpRight, Check,
  Loader2, UploadCloud, PenTool, ArrowLeft, User, AlertTriangle, FileText,
  Search, Phone, Video, Send, Plus, Thermometer, HeartPulse, Globe, Copy, CheckCircle,
  ExternalLink, Layers, Link2, Bot, Sparkles, UserCheck, ShieldCheck, ThumbsUp, Star,
  Image as ImageIcon, Info, BookOpen, Users, Lock, Store, Camera
} from 'lucide-react';
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, BarChart, Bar
} from 'recharts';
import { AIChatBot } from './components/AIChatBot';
import { MilpaLogo } from './components/MilpaLogo';
import { UserProfileModal } from './components/UserProfileModal';
import { RealTimePriceTicker } from './components/RealTimePriceTicker';
import { CropWeatherWidget } from './components/CropWeatherWidget';
import { CropDevelopmentTracker } from './components/CropDevelopmentTracker';
import { TransactionLedger } from './components/TransactionLedger';
import { Web3WalletModal } from './components/Web3WalletModal';
import { ProductionLaunchModal } from './components/ProductionLaunchModal';
import { AboutUsView } from './components/AboutUsView';
import { AuthModal } from './components/AuthModal';
import { CommunityDirectoryView } from './components/CommunityDirectoryView';
import { SellerRegistrationModal } from './components/SellerRegistrationModal';
import { DirectUserChatModal } from './components/DirectUserChatModal';
import { MarketplaceItemDetailModal } from './components/MarketplaceItemDetailModal';
import { InvestInCropModal } from './components/InvestInCropModal';
import { CropImageModal } from './components/CropImageModal';
import {
  UserProfile, PeerReview, Language, Crop, Message, Transaction,
  DevelopmentLog, MarketplaceItem, SellerRegistrationApplication
} from './types';
import {
  auth, googleProvider, signInWithPopup, signOut as firebaseSignOut,
  onAuthStateChanged, db, testFirebaseConnection, sanitizeForFirestore
} from './lib/firebase';
import { doc, getDoc, setDoc, onSnapshot, collection } from 'firebase/firestore';

// Types are imported from ./types

// Global Static Data
const initialCrops: Crop[] = [
  {
    id: "c1",
    name: "Maíz Criollo Orgánico",
    producerName: "Ejido San Miguel",
    location: "Oaxaca, México",
    type: "Granos",
    imageUrl: "https://images.unsplash.com/photo-1551754655-cd27e38d2076?q=80&w=1200&auto=format&fit=crop",
    description: "Cultivo ancestral libre de pesticidas con trazabilidad blockchain completa y alta densidad de nutrientes.",
    riskLevel: "BAJO",
    tokenPrice: 50.00,
    previousTokenPrice: 48.50,
    priceChange24h: 3.09,
    totalTokens: 10000,
    soldTokens: 6500,
    yieldProjection: 12.5,
    harvestDate: "2026-11-15",
    sustainabilityScore: 95,
    openseaUrl: "https://opensea.io/assets/matic/0x2953399124f0cbb46d2cbacd8a89cf0599974963/10293848123019283",
    nftContract: "0x2953399124f0cbb46d2cbacd8a89cf0599974963",
    nftTokenId: "#10293848",
    nftStandard: "ERC-1155",
    weather: {
      tempC: 25.2,
      humidityPct: 58,
      rainfallMm: 3.1,
      soilMoisturePct: 46,
      condition: "Soleado con Brisa de Montaña",
      conditionEn: "Sunny with Mountain Breeze",
      uvIndex: 7
    },
    development: {
      stage: "Crecimiento Vegetativo y Llenado de Grano",
      stageEn: "Vegetative Growth & Grain Filling",
      progressPct: 68,
      daysToHarvest: 87,
      healthScore: 97,
      lastUpdateDate: "Hoy, 10:30 AM",
      updateNote: "Formación de mazorca avanzada. Escaneo multiespectral de humedad del suelo confirma absorción óptima.",
      updateNoteEn: "Advanced cob formation. Multispectral soil moisture scan confirms optimal absorption.",
      logEvents: [
        { date: "18 Ago 2026", title: "Escaneo Satelital & Dron NDVI", description: "Salud foliar registrada en 0.89. Ausencia total de plagas.", type: "DRONE" },
        { date: "05 Ago 2026", title: "Riego Paramétrico de Conservación", description: "Infiltración de humedad por cobertura de rastrojo tradicional.", type: "IOT" },
        { date: "15 Jul 2026", title: "Germinación Exitosa 100%", description: "Brote de semillas criollas amarillas y azules finalizado.", type: "BIODYNAMICS" }
      ]
    }
  },
  {
    id: "c2",
    name: "Café de Altura Sostenible",
    producerName: "Finca La Niebla",
    location: "Chiapas, México",
    type: "Café",
    imageUrl: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=1200&auto=format&fit=crop",
    description: "Café arábica de sombra con certificación de comercio justo y prácticas regenerativas de suelo.",
    riskLevel: "MEDIO",
    tokenPrice: 120.00,
    previousTokenPrice: 122.50,
    priceChange24h: -2.04,
    totalTokens: 5000,
    soldTokens: 1200,
    yieldProjection: 18.2,
    harvestDate: "2026-12-01",
    sustainabilityScore: 88,
    openseaUrl: "https://opensea.io/assets/matic/0x495f947276749ce646f68ac8c248420045cb7b5e/883921049281",
    nftContract: "0x495f947276749ce646f68ac8c248420045cb7b5e",
    nftTokenId: "#88392104",
    nftStandard: "ERC-721",
    weather: {
      tempC: 21.0,
      humidityPct: 78,
      rainfallMm: 12.4,
      soilMoisturePct: 65,
      condition: "Neblina Ligera y Lluvia de Sombra",
      conditionEn: "Light Mist & Shade Rain",
      uvIndex: 4
    },
    development: {
      stage: "Maduración de Cerezas Arábica",
      stageEn: "Arabica Cherry Maturation",
      progressPct: 52,
      daysToHarvest: 103,
      healthScore: 92,
      lastUpdateDate: "Ayer, 04:15 PM",
      updateNote: "Viraje de color de cerezas a rojo borgoña. Monitoreo de sombra por arbolado nativo ideal.",
      updateNoteEn: "Cherry color shift to burgundy red. Shade canopy monitoring native tree cover ideal.",
      logEvents: [
        { date: "12 Ago 2026", title: "Muestreo de Azúcar en Cereza (Brix)", description: "Lectura de grados Brix en 22°. Dulzor excelente.", type: "INSPECTION" },
        { date: "28 Jul 2026", title: "Abonado Orgánico con Pulpa de Café", description: "Reciclaje de materia orgánica aplicado a las raíces.", type: "BIODYNAMICS" }
      ]
    }
  },
  {
    id: "c3",
    name: "Aguacate Hass Regenerativo",
    producerName: "Huertos del Valle",
    location: "Michoacán, México",
    type: "Frutales",
    imageUrl: "https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?q=80&w=1200&auto=format&fit=crop",
    description: "Huerta sostenible con optimización de huella hídrica y microclima regulado por monitoreo satelital.",
    riskLevel: "BAJO",
    tokenPrice: 200.00,
    previousTokenPrice: 192.00,
    priceChange24h: 4.17,
    totalTokens: 20000,
    soldTokens: 18500,
    yieldProjection: 10.5,
    harvestDate: "2027-02-20",
    sustainabilityScore: 92,
    openseaUrl: "https://opensea.io/assets/ethereum/0x71c7656ec7ab88b098defb751b7401b5f6d8976f/55021",
    nftContract: "0x71c7656ec7ab88b098defb751b7401b5f6d8976f",
    nftTokenId: "#55021",
    nftStandard: "ERC-721",
    weather: {
      tempC: 23.8,
      humidityPct: 52,
      rainfallMm: 0.0,
      soilMoisturePct: 42,
      condition: "Cielo Despejado e Riego Inteligente",
      conditionEn: "Clear Sky & Smart Drip Irrigation",
      uvIndex: 8
    },
    development: {
      stage: "Crecimiento de Fruto y Calibre Hass",
      stageEn: "Fruit Growth & Hass Sizing",
      progressPct: 40,
      daysToHarvest: 184,
      healthScore: 95,
      lastUpdateDate: "Hoy, 08:00 AM",
      updateNote: "Monitoreo por microgoteo automatizado activo. Cero huella de deforestación confirmada.",
      updateNoteEn: "Automated micro-drip monitoring active. Zero deforestation footprint confirmed.",
      logEvents: [
        { date: "16 Ago 2026", title: "Auditoría GlobalG.A.P.", description: "Verificación de prácticas de inocuidad y uso de agua aprobada.", type: "INSPECTION" },
        { date: "02 Ago 2026", title: "Calibración de Sensores de Suelo", description: "Instalación de sondas TDR para medición de salinidad.", type: "IOT" }
      ]
    }
  },
  {
    id: "c4",
    name: "Agave Angustifolia-Espadin de Oaxaca",
    producerName: "Mezcaleros San Dionisio",
    location: "Oaxaca, México",
    type: "Agave",
    imageUrl: "https://images.unsplash.com/photo-1596704017254-9b121068fb31?q=80&w=1200&auto=format&fit=crop",
    description: "Inversión agrícola en agave angustifolia (espadín) de Oaxaca, cultivado agroecológicamente para mezcal artesanal con trazabilidad NFT vinculada a OpenSea.",
    riskLevel: "ALTO",
    tokenPrice: 85.00,
    previousTokenPrice: 81.00,
    priceChange24h: 4.94,
    totalTokens: 15000,
    soldTokens: 2000,
    yieldProjection: 25.0,
    harvestDate: "2029-05-10",
    sustainabilityScore: 75,
    openseaUrl: "https://opensea.io/item/polygon/0x88485aad41e74e69321e848d8e78e892c5a5315d/1",
    nftContract: "0x88485aad41e74e69321e848d8e78e892c5a5315d",
    nftTokenId: "#1",
    nftStandard: "ERC-721",
    weather: {
      tempC: 28.5,
      humidityPct: 35,
      rainfallMm: 0.0,
      soilMoisturePct: 28,
      condition: "Clima Árido Semi-Cálido Ideales p/ Agave",
      conditionEn: "Semi-Warm Arid Weather Ideal for Agave",
      uvIndex: 9
    },
    development: {
      stage: "Acumulación de Azúcares en Piña de Agave",
      stageEn: "Sugar Accumulation in Agave Core",
      progressPct: 30,
      daysToHarvest: 990,
      healthScore: 98,
      lastUpdateDate: "10 Ago 2026",
      updateNote: "Piñas en sazón constante. Resistencia a la sequía extrema mediante CAM vegetal.",
      updateNoteEn: "Cores in steady maturation. Extreme drought resistance via plant CAM photosynthesis.",
      logEvents: [
        { date: "10 Ago 2026", title: "Deshierbe Manual Tradicional", description: "Control de maleza sin herbicidas químicos en parcelas.", type: "INSPECTION" }
      ]
    }
  }
];

const sensorData = [
  { time: "06:00", humidity: 60, temperature: 18, soilMoisture: 45 },
  { time: "09:00", humidity: 55, temperature: 22, soilMoisture: 42 },
  { time: "12:00", humidity: 40, temperature: 28, soilMoisture: 38 },
  { time: "15:00", humidity: 35, temperature: 30, soilMoisture: 35 },
  { time: "18:00", humidity: 45, temperature: 26, soilMoisture: 36 },
  { time: "21:00", humidity: 65, temperature: 20, soilMoisture: 40 }
];

const initialContacts = [
  { id: "u1", name: "Juan Pérez (Ejido San Miguel)", role: "PRODUCER", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=150&auto=format&fit=crop", lastMessage: "Claro, enviaré el reporte de humedad mañana.", online: true },
  { id: "u2", name: "Elena Global Investments", role: "INVESTOR", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=150&auto=format&fit=crop", lastMessage: "¿Cómo afectaron las lluvias recientes al cultivo?", online: true },
  { id: "u3", name: "Carlos R. (Auditor)", role: "GUEST", avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=150&auto=format&fit=crop", lastMessage: "La certificación orgánica ha sido renovada exitosamente.", online: false }
];

const initialMessages: Message[] = [
  { id: "m1", senderId: "u2", receiverId: "u1", text: "Hola Juan, vi que el índice de humedad subió en el dashboard. ¿Todo bien con el maíz?", timestamp: "10:30 AM" },
  { id: "m2", senderId: "u1", receiverId: "u2", text: "Hola Elena. Sí, tuvimos lluvias ligeras anoche, lo cual es excelente para esta etapa de crecimiento. No hay riesgo alguno.", timestamp: "10:35 AM" },
  { id: "m3", senderId: "u2", receiverId: "u1", text: "¡Excelente noticia! Gracias por la rápida respuesta.", timestamp: "10:36 AM" },
  { id: "m4", senderId: "u2", receiverId: "u1", text: "¿Cuándo estimas que comience la cosecha?", timestamp: "10:37 AM" }
];

// Translations Dictionary
const translations = {
  es: {
    // Layout
    app_title: "Milpa Tech",
    tagline: "Tokenización Agrícola",
    nav_about: "Nosotros / About Us",
    nav_community: "Directorio & Comunidad",
    nav_marketplace: "Marketplace",
    nav_ledger: "Ledger Transacciones",
    nav_dashboard: "Mi Panel",
    nav_messages: "Mensajes",
    nav_ai: "Inteligencia Artificial",
    nav_ai_bot: "Asistente Milpa AI",
    nav_wallet: "Billetera / Tokens",
    nav_logout: "Cerrar Sesión",
    demo_mode: "Modo Demo",
    btn_producer_demo: "Soy Productor",
    btn_investor_demo: "Soy Inversionista",
    welcome: "Bienvenido",
    title_about: "Quiénes Somos • About Us",
    title_community: "Directorio de Usuarios Registrados & Vendedores",
    title_marketplace: "Marketplace de Cultivos",
    title_ledger: "Ledger de Transacciones & Registro Blockchain",
    title_dashboard: "Panel de Control",
    title_ai: "Análisis de Riesgo & IA",
    title_ai_bot: "Asistente Agrícola Inteligente Milpa AI",
    title_wallet: "Mis Activos Digitales",
    title_messages: "Mensajes Directos",
    balance: "Saldo",

    // Landing
    landing_h1: "Inversión Agrícola Transparente y Regenerativa",
    landing_desc: "Conectamos productores orgánicos con inversionistas globales mediante tecnología blockchain. Liquidez, trazabilidad y seguridad jurídica en el campo.",
    revolution_manifest: "MILPA TECH ES EL INICIO DE UNA REVOLUCIÓN AGRÍCOLA Y TECNOLÓGICA ÚNICA EN SU TIPO, BRINDANDO SOBERANÍA Y AUTONOMÍA A LOS CAMPESINOS Y DEMOCRATIZANDO LA PARTICIPACIÓN EN LA AGRICULTURA ORGÁNICA Y SUSTENTABLE EN MEXICO Y EL MUNDO.",
    btn_create_account: "Crear Cuenta",
    btn_demo_investor: "Demo Inversionista",
    btn_demo_producer: "Demo Productor",
    feature_token_title: "Tokenización",
    feature_token_desc: "Convierte cultivos reales en activos digitales fraccionados. Inversiones accesibles desde bajos montos con liquidez inmediata.",
    feature_ai_title: "Gestión de Riesgos con IA",
    feature_ai_desc: "Seguros paramétricos activados por datos satelitales y meteorológicos. Protección automática para proteger tu capital.",
    feature_regen_title: "Agricultura Regenerativa",
    feature_regen_desc: "Apoya proyectos que restauran la biodiversidad del suelo y el medio ambiente. Trazabilidad completa desde la siembra.",
    impact_title: "Impacto Real en el Campo",
    impact_hectares: "Hectáreas Protegidas",
    impact_investment: "Inversión Gestionada",
    impact_producers: "Productores Beneficiados",
    impact_blockchain: "Trazabilidad Blockchain",

    // Registration Form
    onboarding_title: "Formulario de Onboarding",
    onboarding_subtitle: "Registro Oficial y Cumplimiento Legal (KYC/AML)",
    sec1_title: "Sección 1 – Selecciona tu Rol",
    sec1_producer: "Productor",
    sec1_producer_desc: "Solicito financiamiento directo para expandir mi cultivo",
    sec1_investor: "Inversionista",
    sec1_investor_desc: "Busco invertir capital en proyectos agrícolas orgánicos",
    sec2_title: "Sección 2 – Información General / Empresa",
    field_fullname: "Nombre Completo / Razón Social *",
    field_taxid: "ID Nacional / RFC / Reg. Compañía *",
    field_dob: "Fecha de Nacimiento / Constitución *",
    field_address: "Dirección Física *",
    field_email: "Correo Electrónico *",
    field_phone: "Número de Teléfono *",
    field_wallet: "Dirección de Billetera (Blockchain Wallet)",
    btn_connect_wallet: "Conectar Wallet",
    sec3_title: "Sección 3 – Solo para Productores",
    doc_legal: "A. Documentación Legal",
    doc_deed: "Título de Propiedad o Contrato de Arrendamiento",
    doc_registry: "Registro oficial ante autoridades agrícolas (si aplica)",
    project_info: "B. Información del Proyecto",
    field_croptype: "Tipo de Cultivo",
    field_hectares: "Tamaño (Hectáreas)",
    field_yield: "Rendimiento Estimado",
    doc_plan: "Plan de Agricultura Sostenible y Orgánica",
    doc_insurance: "Póliza de Seguro Agrícola (si disponible)",
    compliance: "C. Compromiso y Cumplimiento",
    comp_practice: "Me comprometo formalmente con prácticas ecológicas y regenerativas.",
    comp_audit: "Consiento auditorías aleatorias y trazabilidad vía blockchain.",
    sec4_title: "Sección 4 – Solo para Inversionistas",
    doc_id: "Pasaporte / ID Nacional / Acta Constitutiva",
    doc_address: "Comprobante de Domicilio",
    financial_verification: "B. Verificación Financiera",
    doc_funds: "Declaración de Origen de Fondos Lícitos",
    tax_checkbox: "Tax ID / Registro Fiscal provisto para auditoría internacional.",
    risk_acknowledgement: "C. Reconocimiento de Riesgo",
    risk_text: "Reconozco que las inversiones agrícolas orgánicas conllevan riesgos climáticos y biológicos naturales, pudiendo perder parte del capital.",
    sec5_title: "Sección 5 – Declaraciones Finales",
    consent_kyc: "Doy consentimiento para validaciones de antecedentes KYC / AML.",
    consent_storage: "Acepto el almacenamiento seguro de datos y su firma en blockchain.",
    consent_terms: "Acepto expresamente los Términos y Condiciones y políticas de resolución de disputas.",
    field_signature: "Firma Digital *",
    signature_placeholder: "Escriba su nombre completo para firmar electrónicamente",
    field_date: "Fecha",
    btn_cancel: "Cancelar",
    btn_submit_req: "Enviar Solicitud",
    processing: "Procesando...",

    // Marketplace
    filter_all: "Todos",
    filter_grains: "Granos",
    filter_coffee: "Café",
    filter_fruits: "Frutales",
    filter_agave: "Agave",
    filter_vegetables: "Hortalizas",
    score: "Score",
    risk: "Riesgo",
    risk_low: "BAJO",
    risk_medium: "MEDIO",
    risk_high: "ALTO",
    est_return: "Retorno Est.",
    harvest: "Cosecha",
    available: "disponibles",
    btn_producer_view: "Vista Productor",
    btn_invest_now: "Invertir Ahora",
    btn_login_invest: "Inicia sesión para invertir",
    invest_modal_title: "Inversión en Cultivo",
    invest_tokens_label: "Cantidad de Tokens a Adquirir",
    invest_total_price: "Precio Total",
    invest_balance_after: "Saldo Posterior",
    invest_success: "¡Compra exitosa! Adquiriste {amount} tokens de {name}. Se descontaron ${total} MXN de tu billetera.",
    insufficient_funds: "Saldo insuficiente en tu billetera.",
    login_required: "Por favor inicia sesión para comprar",

    // Producer Dashboard
    producer_title: "Panel de Productor",
    btn_load_crop: "Cargar Cultivo",
    metrics_moisture: "Humedad del Suelo",
    metrics_moisture_sub: "Óptimo para siembra",
    metrics_temp: "Temperatura Actual",
    metrics_temp_sub: "Promedio diario",
    metrics_health: "Salud del Cultivo",
    metrics_health_sub: "Sin plagas detectadas",
    iot_sensors_title: "Sensores IoT en Tiempo Real (Historial 24h)",
    active_crops_title: "Mis Cultivos Activos",
    tbl_name: "Nombre",
    tbl_sold_tokens: "Tokens Vendidos",
    tbl_progress: "Progreso de Financiamiento",
    tbl_status: "Estado",
    tbl_growing: "En Crecimiento",
    no_crops: "No tienes cultivos registrados aún. ¡Carga tu primer cultivo!",
    add_crop_title: "Cargar Nuevo Cultivo para Tokenización",
    add_crop_sub: "Detalles del cultivo, retorno proyectado y documentación",
    form_general: "Información General del Cultivo",
    crop_name_placeholder: "Ej. Maíz Azul Orgánico",
    crop_location_placeholder: "Estado, Municipio",
    form_url: "URL de Imagen del Cultivo",
    form_desc: "Descripción de prácticas regenerativas",
    form_economics: "Tokenización y Datos Financieros",
    form_price: "Precio por Token ($ MXN)",
    form_total_tokens: "Total de Tokens a Emitir",
    form_yield: "Rendimiento Anual Proyectado (%)",
    form_harvest: "Fecha Estimada de Cosecha",
    form_score: "Puntaje de Sustentabilidad (0-100)",
    form_legal_doc: "Documentación de Propiedad y Permisos",
    legal_upload_text: "Subir Título de Propiedad o Contrato de Arrendamiento",
    legal_upload_sub: "Formatos PDF, JPG o PNG hasta 10MB",
    crop_added_success: "¡Cultivo cargado exitosamente al Marketplace!",

    // NFT & OpenSea Translations
    nft_badge: "NFT en OpenSea",
    nft_linked: "NFT Vinculado en OpenSea",
    nft_view_opensea: "Ver en OpenSea ↗",
    nft_modal_title: "Certificado NFT & Trazabilidad OpenSea",
    nft_contract_address: "Dirección de Smart Contract (NFT)",
    nft_token_id: "ID de Token NFT",
    nft_standard: "Estándar NFT",
    nft_network: "Red Blockchain",
    nft_verified_opensea: "Activo Certificado en OpenSea",
    nft_open_opensea: "Abrir Token en OpenSea ↗",
    nft_field_opensea_url: "Link Real de OpenSea (URL del NFT)",
    nft_field_contract: "Dirección del Contrato NFT (0x...)",
    nft_field_token_id: "ID de Token NFT",
    nft_sec_title: "Vinculación de NFT en OpenSea",
    nft_edit_btn: "Insertar / Editar NFT",
    nft_edit_title: "Asignar / Editar NFT del Cultivo",
    nft_save_btn: "Guardar Vincular NFT",

    // Investor Dashboard
    portfolio_dist: "Distribución de Portafolio Agrícola",
    total_assets: "Valor Total de Activos",
    accum_return: "Retorno Acumulado",
    total_tokens: "Tokens Totales",
    my_investments_title: "Mis Inversiones Activas",
    tbl_crop: "Cultivo",
    tbl_qty: "Cantidad",
    tbl_entry_price: "Precio Entrada",
    tbl_current_val: "Valor Actual",
    no_investments: "Aún no tienes inversiones. ¡Visita el Marketplace!",

    // AI Risk
    ai_satellite_title: "Análisis Satelital Gemini-X",
    ai_satellite_desc: "Nuestro sistema de inteligencia artificial analiza imágenes hiperespectrales en tiempo real para predecir la salud del cultivo, necesidades hídricas específicas y riesgos de plagas con un 94% de precisión científica.",
    ai_last_scan: "Último Escaneo",
    ai_last_scan_val: "Hace 2 horas",
    ai_coverage: "Cobertura de Campo",
    ai_coverage_val: "100% Óptima",
    ai_visualization: "Imagen de Satélite Reciente",
    ai_climate_title: "Predicción Climática y Sequías (6 Meses)",
    ai_risk_matrix: "Matriz de Riesgos Detectados (IA)",
    risk_drought: "Riesgo de Sequía",
    risk_volatility: "Volatilidad de Precios de Mercado",
    risk_soil: "Salud e Infiltración del Suelo",
    risk_optimal: "ÓPTIMO",
    ai_disclaimer: "* El cálculo de riesgo se actualiza automáticamente cada 24 horas utilizando oráculos de Chainlink y modelos predictivos climáticos. Los seguros paramétricos se activan automáticamente si el índice de sequía supera el 80%.",

    // Chat
    chat_search: "Buscar contacto...",
    chat_online: "En línea",
    chat_placeholder: "Escribe un mensaje...",
    chat_no_contact: "Selecciona un contacto de la lista para ver el chat",

    // Wallet
    wallet_title: "Billetera Digital Blockchain",
    wallet_desc: "Historial de transacciones de tokens agrícolas en la red de Milpa Tech.",
    wallet_address: "Dirección de Billetera",
    wallet_copy: "Copiar Dirección",
    wallet_copied: "¡Copiada!",
    wallet_tx_history: "Historial de Transacciones",
    wallet_tbl_tx: "Hash de Transacción",
    wallet_tbl_type: "Tipo",
    wallet_tbl_amount: "Tokens",
    wallet_tbl_total: "Monto",
    wallet_tbl_date: "Fecha",
    wallet_tbl_status: "Estado",
    wallet_status_confirmed: "Confirmado",
    wallet_buy_crop: "Compra de Tokens - {crop}",
    wallet_add_crop: "Emisión de Tokens - {crop}"
  },
  en: {
    // Layout
    app_title: "Milpa Tech",
    tagline: "Agricultural Tokenization",
    nav_about: "About Us / Nosotros",
    nav_community: "Directory & Community",
    nav_marketplace: "Marketplace",
    nav_ledger: "Transaction Ledger",
    nav_dashboard: "My Panel",
    nav_messages: "Messages",
    nav_ai: "Artificial Intelligence",
    nav_ai_bot: "Milpa AI Assistant",
    nav_wallet: "Wallet / Tokens",
    nav_logout: "Log Out",
    demo_mode: "Demo Mode",
    btn_producer_demo: "I am a Producer",
    btn_investor_demo: "I am an Investor",
    welcome: "Welcome",
    title_about: "Who We Are • About Us",
    title_community: "Registered Users & Verified Sellers Directory",
    title_marketplace: "Crops Marketplace",
    title_ledger: "Transaction Ledger & Blockchain Ledger",
    title_dashboard: "Control Panel",
    title_ai: "Risk Analysis & AI",
    title_ai_bot: "Milpa Intelligent AI Assistant",
    title_wallet: "My Digital Assets",
    title_messages: "Direct Messages",
    balance: "Balance",

    // Landing
    landing_h1: "Transparent and Regenerative Agricultural Investment",
    landing_desc: "We connect organic producers with global investors using blockchain technology. Liquidity, traceability, and legal security in the countryside.",
    revolution_manifest: "MILPA TECH IS THE BEGINNING OF A UNIQUE AGRICULTURAL AND TECHNOLOGICAL REVOLUTION, PROVIDING SOVEREIGNTY AND AUTONOMY TO FARMERS AND DEMOCRATIZING PARTICIPATION IN ORGANIC AND SUSTAINABLE AGRICULTURE IN MEXICO AND AROUND THE WORLD.",
    btn_create_account: "Create Account",
    btn_demo_investor: "Investor Demo",
    btn_demo_producer: "Producer Demo",
    feature_token_title: "Tokenization",
    feature_token_desc: "Convert real crops into fractional digital assets. Accessible investments from low minimums with immediate liquidity.",
    feature_ai_title: "AI Risk Management",
    feature_ai_desc: "Parametric insurance triggered by satellite and meteorological data. Automatic protection to safeguard your capital.",
    feature_regen_title: "Regenerative Agriculture",
    feature_regen_desc: "Support projects that restore soil biodiversity and the environment. Full traceability from sowing to harvest.",
    impact_title: "Real Impact in the Field",
    impact_hectares: "Protected Hectares",
    impact_investment: "Managed Investment",
    impact_producers: "Benefited Producers",
    impact_blockchain: "Blockchain Traceability",

    // Registration Form
    onboarding_title: "Onboarding Form",
    onboarding_subtitle: "Official Registration and Legal Compliance (KYC/AML)",
    sec1_title: "Section 1 – Select Your Role",
    sec1_producer: "Producer",
    sec1_producer_desc: "I am requesting direct funding to expand my crops",
    sec1_investor: "Investor",
    sec1_investor_desc: "I seek to invest capital in organic agricultural projects",
    sec2_title: "Section 2 – General Info / Company",
    field_fullname: "Full Name / Corporate Name *",
    field_taxid: "National ID / RFC / Company Reg *",
    field_dob: "Date of Birth / Constitution *",
    field_address: "Physical Address *",
    field_email: "Email Address *",
    field_phone: "Phone Number *",
    field_wallet: "Wallet Address (Blockchain Wallet)",
    btn_connect_wallet: "Connect Wallet",
    sec3_title: "Section 3 – For Producers Only",
    doc_legal: "A. Legal Documentation",
    doc_deed: "Property Title Deed or Lease Agreement",
    doc_registry: "Official agricultural authority registration (if applicable)",
    project_info: "B. Project Information",
    field_croptype: "Crop Type",
    field_hectares: "Size (Hectares)",
    field_yield: "Estimated Annual Yield",
    doc_plan: "Sustainable & Organic Farming Plan",
    doc_insurance: "Agricultural Insurance Policy (if available)",
    compliance: "C. Commitment and Compliance",
    comp_practice: "I formally commit to ecologic and regenerative agricultural practices.",
    comp_audit: "I consent to random third-party audits and blockchain traceability.",
    sec4_title: "Section 4 – For Investors Only",
    doc_id: "Passport / National ID / Articles of Org",
    doc_address: "Proof of Address",
    financial_verification: "B. Financial Verification",
    doc_funds: "Declaration of Source of Funds",
    tax_checkbox: "Tax ID / Fiscal Registration provided for international audit.",
    risk_acknowledgement: "C. Risk Acknowledgment",
    risk_text: "I acknowledge that organic agricultural investments carry natural climatic and biological risks, with potential loss of capital.",
    sec5_title: "Section 5 – Final Declarations",
    consent_kyc: "I consent to KYC / AML background check validations.",
    consent_storage: "I agree to secure storage of data and its signature registration on blockchain.",
    consent_terms: "I expressly accept the Terms and Conditions and dispute resolution policies.",
    field_signature: "Digital Signature *",
    signature_placeholder: "Type your full name to sign electronically",
    field_date: "Date",
    btn_cancel: "Cancel",
    btn_submit_req: "Submit Application",
    processing: "Processing...",

    // Marketplace
    filter_all: "All",
    filter_grains: "Grains",
    filter_coffee: "Coffee",
    filter_fruits: "Fruits",
    filter_agave: "Agave",
    filter_vegetables: "Vegetables",
    score: "Score",
    risk: "Risk",
    risk_low: "LOW",
    risk_medium: "MEDIUM",
    risk_high: "HIGH",
    est_return: "Est. Return",
    harvest: "Harvest",
    available: "available",
    btn_producer_view: "Producer View",
    btn_invest_now: "Invest Now",
    btn_login_invest: "Log in to invest",
    invest_modal_title: "Crop Investment",
    invest_tokens_label: "Number of Tokens to Purchase",
    invest_total_price: "Total Price",
    invest_balance_after: "Post Balance",
    invest_success: "Purchase successful! You bought {amount} tokens of {name}. ${total} MXN was deducted from your wallet.",
    insufficient_funds: "Insufficient funds in your wallet.",
    login_required: "Please log in to purchase tokens",

    // Producer Dashboard
    producer_title: "Producer Dashboard",
    btn_load_crop: "Load Crop",
    metrics_moisture: "Soil Moisture",
    metrics_moisture_sub: "Optimal for sowing",
    metrics_temp: "Current Temperature",
    metrics_temp_sub: "Daily average",
    metrics_health: "Crop Health",
    metrics_health_sub: "No pests detected",
    iot_sensors_title: "Real-Time IoT Sensors (24h History)",
    active_crops_title: "My Active Crops",
    tbl_name: "Name",
    tbl_sold_tokens: "Tokens Sold",
    tbl_progress: "Funding Progress",
    tbl_status: "Status",
    tbl_growing: "Growing",
    no_crops: "No registered crops yet. Load your first project!",
    add_crop_title: "Load New Crop for Tokenization",
    add_crop_sub: "Crop details, projected returns and documentation",
    form_general: "General Crop Information",
    crop_name_placeholder: "e.g. Organic Blue Corn",
    crop_location_placeholder: "State, Municipality",
    form_url: "Crop Image URL",
    form_desc: "Description of regenerative practices",
    form_economics: "Tokenization & Financial Data",
    form_price: "Price per Token ($ MXN)",
    form_total_tokens: "Total Tokens to Issue",
    form_yield: "Projected Annual Yield (%)",
    form_harvest: "Estimated Harvest Date",
    form_score: "Sustainability Score (0-100)",
    form_legal_doc: "Ownership Title & Permits Documentation",
    legal_upload_text: "Upload Deed or Lease Agreement",
    legal_upload_sub: "PDF, JPG or PNG formats up to 10MB",
    crop_added_success: "Crop uploaded successfully to the Marketplace!",

    // Investor Dashboard
    portfolio_dist: "Agricultural Portfolio Distribution",
    total_assets: "Total Asset Value",
    accum_return: "Accumulated Return",
    total_tokens: "Total Tokens",
    my_investments_title: "My Active Investments",
    tbl_crop: "Crop",
    tbl_qty: "Quantity",
    tbl_entry_price: "Entry Price",
    tbl_current_val: "Current Value",
    no_investments: "No investments yet. Check out the Marketplace!",

    // AI Risk
    ai_satellite_title: "Gemini-X Satellite Analysis",
    ai_satellite_desc: "Our artificial intelligence system analyzes hyperspectral imagery in real time to predict crop health, specific water requirements, and crop pest risks with a 94% scientific accuracy rate.",
    ai_last_scan: "Last Scan",
    ai_last_scan_val: "2 hours ago",
    ai_coverage: "Field Coverage",
    ai_coverage_val: "100% Optimal",
    ai_visualization: "Recent Satellite Capture",
    ai_climate_title: "Climate & Drought Forecast (6 Months)",
    ai_risk_matrix: "Detected Risks Matrix (AI)",
    risk_drought: "Drought Risk",
    risk_volatility: "Market Price Volatility",
    risk_soil: "Soil Health & Infiltration",
    risk_optimal: "OPTIMAL",
    ai_disclaimer: "* Risk calculations are updated automatically every 24 hours using Chainlink oracles and predictive climate models. Parametric insurance triggers automatically if the drought index exceeds 80%.",

    // Chat
    chat_search: "Search contact...",
    chat_online: "Online",
    chat_placeholder: "Type a message...",
    chat_no_contact: "Select a contact from the list to start chatting",

    // Wallet
    wallet_title: "Digital Blockchain Wallet",
    wallet_desc: "Agricultural token transaction history on the Milpa Tech ledger.",
    wallet_address: "Wallet Address",
    wallet_copy: "Copy Address",
    wallet_copied: "Copied!",
    wallet_tx_history: "Transaction History",
    wallet_tbl_tx: "Transaction Hash",
    wallet_tbl_type: "Type",
    wallet_tbl_amount: "Tokens",
    wallet_tbl_total: "Amount",
    wallet_tbl_date: "Date",
    wallet_tbl_status: "Status",
    wallet_status_confirmed: "Confirmed",
    wallet_buy_crop: "Purchase Tokens - {crop}",
    wallet_add_crop: "Token Issuance - {crop}",

    // NFT & OpenSea Translations
    nft_badge: "NFT on OpenSea",
    nft_linked: "NFT Linked on OpenSea",
    nft_view_opensea: "View on OpenSea ↗",
    nft_modal_title: "NFT Certificate & OpenSea Traceability",
    nft_contract_address: "Smart Contract Address (NFT)",
    nft_token_id: "NFT Token ID",
    nft_standard: "NFT Standard",
    nft_network: "Blockchain Network",
    nft_verified_opensea: "Verified Asset on OpenSea",
    nft_open_opensea: "Open Token on OpenSea ↗",
    nft_field_opensea_url: "OpenSea Link (NFT URL)",
    nft_field_contract: "NFT Contract Address (0x...)",
    nft_field_token_id: "NFT Token ID",
    nft_sec_title: "OpenSea NFT Linkage",
    nft_edit_btn: "Insert / Edit NFT",
    nft_edit_title: "Assign / Edit Crop NFT",
    nft_save_btn: "Save & Link NFT"
  }
};

const initialReviews: PeerReview[] = [
  {
    id: "rev-1",
    targetUserId: "u1",
    authorId: "u2",
    authorName: "Elena Global Investments",
    authorRole: "INVESTOR",
    authorAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=150&auto=format&fit=crop",
    rating: 5,
    comment: "Excelente comunicación y entrega puntual de reportes de humedad. El cultivo de maíz azul orgánico superó la expectativa de rendimiento.",
    endorsements: ["Cumplimiento en Cosechas", "Prácticas 100% Orgánicas", "Transparencia Financiera"],
    date: "12 Oct 2025"
  },
  {
    id: "rev-2",
    targetUserId: "u1",
    authorId: "u3",
    authorName: "Carlos R. (Auditor Agro)",
    authorRole: "INVESTOR",
    authorAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=150&auto=format&fit=crop",
    rating: 5,
    comment: "Inspección de campo verificada. Cero uso de pesticidas sintéticos y trazabilidad NFT impecable en la red.",
    endorsements: ["Prácticas 100% Orgánicas", "Innovación Agroecológica"],
    date: "28 Ene 2026"
  },
  {
    id: "rev-3",
    targetUserId: "u2",
    authorId: "u1",
    authorName: "Juan Pérez (Ejido San Miguel)",
    authorRole: "PRODUCER",
    authorAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=150&auto=format&fit=crop",
    rating: 5,
    comment: "Elena es una inversionista comprometida con el desarrollo comunitario. Financiamiento ágil y constante retroalimentación.",
    endorsements: ["Pagos Puntuales", "Socio Confiable", "Comunicación Constante"],
    date: "05 Feb 2026"
  }
];

export const initialRegisteredUsers: UserProfile[] = [
  {
    id: "u1",
    name: "Juan Pérez (Ejido San Miguel)",
    role: "PRODUCER",
    balance: 15000,
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=150&auto=format&fit=crop",
    bio: "Productor agrícola ancestral en Oaxaca, México. Especialista en conservación de maíz criollo orgánico y técnicas regenerativas de conservación de humedad.",
    location: "Oaxaca, México",
    phone: "+52 951 234 5678",
    email: "juan.perez@ejidosanmiguel.org",
    walletAddress: "0x3db5ae71bca21cf29871fa8d810ba2cde1297fb9",
    experienceYears: 18,
    farmHectares: 15,
    certifications: ["Certificado Orgánico SAGARPA", "Sello CerTIMEX México"],
    badges: ["Productor Verificado", "Maíz Criollo Ancestral", "SENASICA Fitosanitario"],
    rating: 5.0,
    reviewCount: 14,
    isVerifiedSeller: true,
    verificationLevel: 3,
    kycStatus: 'TIER_3_FULL',
    amlStatus: 'PASSED_CLEAN',
    kycScore: 99.4,
    amlScreeningScore: 99.8,
    kycVerifiedDate: "15 Mar 2026",
    kycAuditor: "MilpaTrust CNBV & SAT Compliance Node",
    rfcTaxId: "PEAJ780415A90",
    legalName: "Juan Pérez Alvarado",
    fraudScore: 99,
    escrowSecured: true,
    businessCategory: "PRODUCER",
    online: true,
    joinedDate: "2024-03-15"
  },
  {
    id: "u-finca",
    name: "Finca La Niebla (Café Chiapas)",
    role: "PRODUCER",
    balance: 28000,
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=150&auto=format&fit=crop",
    bio: "Cooperativa cafetalera de sombra en el Soconusco, Chiapas. Cultivo arábica con impacto ecológico, captura de carbono y restauración forestal.",
    location: "Chiapas, México",
    phone: "+52 961 889 1234",
    email: "contacto@fincalaniebla.mx",
    walletAddress: "0x89205a3e3b2a69d4943b4da98397a222385b2377",
    experienceYears: 24,
    farmHectares: 35,
    certifications: ["Fair Trade Certified", "Rainforest Alliance", "Certificado Sombra de Chiapas"],
    badges: ["Café de Especialidad", "Comercio Justo", "Escrow Seguro"],
    rating: 4.9,
    reviewCount: 22,
    isVerifiedSeller: true,
    verificationLevel: 3,
    rfcTaxId: "FLN990812K31",
    legalName: "Finca La Niebla S.P.R. de R.I.",
    fraudScore: 98,
    escrowSecured: true,
    businessCategory: "PRODUCER",
    online: true,
    joinedDate: "2024-05-20"
  },
  {
    id: "u-huertos",
    name: "Huertos del Valle (Michoacán)",
    role: "PRODUCER",
    balance: 45000,
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=150&auto=format&fit=crop",
    bio: "Huerta sustentable de aguacate Hass libre de deforestación. Sistema de irrigación por microgoteo e integración con telemetría IoT y satelital.",
    location: "Michoacán, México",
    phone: "+52 443 321 9876",
    email: "operaciones@huertosdelvalle.mx",
    walletAddress: "0x23f81e3a1f810cb92e8587d46c827ea8b901a182",
    experienceYears: 12,
    farmHectares: 22,
    certifications: ["GlobalG.A.P.", "Certificado Cero Deforestación Michoacán"],
    badges: ["Aguacate Sustentable", "Telemetría IoT", "Validación SAT"],
    rating: 4.8,
    reviewCount: 19,
    isVerifiedSeller: true,
    verificationLevel: 3,
    rfcTaxId: "HVM1203049F2",
    legalName: "Huertos del Valle de Uruapan S.A. de C.V.",
    fraudScore: 97,
    escrowSecured: true,
    businessCategory: "PRODUCER",
    online: true,
    joinedDate: "2024-08-10"
  },
  {
    id: "u-agave",
    name: "Mezcaleros San Dionisio",
    role: "PRODUCER",
    balance: 32000,
    avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=150&auto=format&fit=crop",
    bio: "Maestros mezcaleros dedicados al cultivo agroecológico de agave Espadín sin agroquímicos y reforestación de magueyes silvestres.",
    location: "Oaxaca, México",
    phone: "+52 951 445 6789",
    email: "maestro@mezcalerosandionisio.mx",
    walletAddress: "0x11223344556677889900aabbccddeeff00112233",
    experienceYears: 30,
    farmHectares: 14,
    certifications: ["Consejo Regulador del Mezcal", "Maguey Agroecológico Certificado"],
    badges: ["Maestro Mezcalero", "Tradición Ancestral", "Smart Escrow"],
    rating: 5.0,
    reviewCount: 28,
    isVerifiedSeller: true,
    verificationLevel: 3,
    rfcTaxId: "MSD940118AA4",
    legalName: "Mezcaleros San Dionisio Ocotepec S.C. de R.L.",
    fraudScore: 99,
    escrowSecured: true,
    businessCategory: "PRODUCER",
    online: false,
    joinedDate: "2024-01-11"
  },
  {
    id: "u2",
    name: "Elena Global Investments",
    role: "INVESTOR",
    balance: 50000,
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=150&auto=format&fit=crop",
    bio: "Fondo de inversión de impacto enfocado en la transición ecológica de la agricultura mexicana y el financiamiento de productores orgánicos con tokens RWA.",
    location: "Ciudad de México / Global",
    phone: "+52 55 9876 5432",
    email: "invest@elenaglobal.vc",
    walletAddress: "0x7a8fc8e31a0e1cb30da9b6cf3e1c67dfa8183c51",
    experienceYears: 10,
    tradingVolume: 2500000,
    certifications: ["Impact Assets 50", "PRI Signatory (UN)"],
    badges: ["Inversor Líder", "Fondo de Impacto", "Custodio Web3"],
    rating: 5.0,
    reviewCount: 31,
    isVerifiedSeller: false,
    verificationLevel: 2,
    rfcTaxId: "EGI160520PL8",
    legalName: "Elena Global Impact Capital S.A.P.I. de C.V.",
    fraudScore: 99,
    escrowSecured: true,
    businessCategory: "INVESTMENT_FUND",
    online: true,
    joinedDate: "2024-02-01"
  },
  {
    id: "u-semilla",
    name: "Fondo Verde Semilla Capital",
    role: "INVESTOR",
    balance: 120000,
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=150&auto=format&fit=crop",
    bio: "Club de ángeles inversionistas enfocado en soberanía alimentaria, riego tecnificado solar y tokenización de cosechas de alta rentabilidad.",
    location: "Guadalajara, Jalisco",
    phone: "+52 33 1234 9876",
    email: "contacto@semillacapital.mx",
    walletAddress: "0x4b20993bc481177ec7e8f571cecae8a9e22c02db",
    experienceYears: 8,
    tradingVolume: 4200000,
    certifications: ["AMEXCAP Socio", "Alianza AgroTech MX"],
    badges: ["Ángel Inversionista", "RWA Agri-DeFi", "Validador Polygon"],
    rating: 4.9,
    reviewCount: 16,
    isVerifiedSeller: false,
    verificationLevel: 2,
    rfcTaxId: "FVS190915TR3",
    legalName: "Fondo Verde Semilla Capital SAPI",
    fraudScore: 98,
    escrowSecured: true,
    businessCategory: "INVESTMENT_FUND",
    online: true,
    joinedDate: "2024-06-14"
  },
  {
    id: "u3",
    name: "AgroComercial del Valle S.A.",
    role: "TRADER",
    balance: 38000,
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=150&auto=format&fit=crop",
    bio: "Empresa comercializadora de granos certificados, fletes refrigerados con monitoreo GPS y proveedora de insumos orgánicos de alta pureza.",
    location: "Puebla, México",
    phone: "+52 222 456 7890",
    email: "ventas@agrocomercialvalle.mx",
    walletAddress: "0x3f5ce5fbfe3e9af3971dd833d26ba9b5c936f0be",
    experienceYears: 15,
    tradingVolume: 6800000,
    certifications: ["SENASICA Distribuidor", "Facturación SAT 4.0", "ISO 9001 Cadena Fría"],
    badges: ["Vendedor Verificado", "Garantía Escrow", "Transporte Certificado"],
    rating: 4.9,
    reviewCount: 42,
    isVerifiedSeller: true,
    verificationLevel: 3,
    rfcTaxId: "ACV091102MK4",
    legalName: "AgroComercial del Valle Central S.A. de C.V.",
    fraudScore: 99,
    escrowSecured: true,
    businessCategory: "GRAIN_TRADER",
    online: true,
    joinedDate: "2024-04-03"
  },
  {
    id: "u-bioinsumos",
    name: "BioInsumos Anáhuac Orgánico",
    role: "TRADER",
    balance: 22000,
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=150&auto=format&fit=crop",
    bio: "Fabricantes de biofertilizantes, lixiviados de agave, compostas enriquecidas con micorrizas y controladores biológicos de plagas.",
    location: "Morelos, México",
    phone: "+52 777 654 3210",
    email: "pedidos@bioinsumosanahuac.com",
    walletAddress: "0x9876543210fedcba9876543210fedcba98765432",
    experienceYears: 9,
    tradingVolume: 1200000,
    certifications: ["OMRI Listed", "Sagarpa Insumo Permitido", "CERTIMEX Bio"],
    badges: ["Bioinsumos Certificados", "100% Orgánico", "Vendedor Oficial"],
    rating: 5.0,
    reviewCount: 35,
    isVerifiedSeller: true,
    verificationLevel: 3,
    rfcTaxId: "BIA150410QW8",
    legalName: "BioInsumos Agrícolas Anáhuac S.P.R.",
    fraudScore: 99,
    escrowSecured: true,
    businessCategory: "INPUTS_SUPPLIER",
    online: true,
    joinedDate: "2024-07-22"
  },
  {
    id: "u-agrodron",
    name: "AgroDron Precisión & NDVI",
    role: "TRADER",
    balance: 19000,
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=150&auto=format&fit=crop",
    bio: "Servicios agronómicos de alta tecnología: mapeo multiespectral con drones, cálculo de estrés hídrico NDVI y fumigación de precisión.",
    location: "Querétaro, México",
    phone: "+52 442 888 7766",
    email: "info@agrodronprecision.mx",
    walletAddress: "0x1234567890abcdef1234567890abcdef12345678",
    experienceYears: 7,
    tradingVolume: 850000,
    certifications: ["Licencia AFAC Piloto Dron", "Certificado ESRI GIS Agrícola"],
    badges: ["Tecnología NDVI", "Servicio Verificado", "Auditoría Satelital"],
    rating: 4.8,
    reviewCount: 18,
    isVerifiedSeller: true,
    verificationLevel: 3,
    rfcTaxId: "ADP170825LK1",
    legalName: "AgroDron Tecnologías de Precisión S.A.",
    fraudScore: 97,
    escrowSecured: true,
    businessCategory: "AGRONOMY_SERVICES",
    online: true,
    joinedDate: "2024-09-05"
  }
];

export const initialMarketplaceItems: MarketplaceItem[] = [
  {
    id: "mkt-1",
    sellerId: "u-bioinsumos",
    sellerName: "BioInsumos Anáhuac Orgánico",
    sellerRole: "TRADER",
    sellerAvatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=150&auto=format&fit=crop",
    sellerLocation: "Morelos, México",
    isVerified: true,
    title: "Biofertilizante Concentrado Lixiviado de Agave (Garrafón 20L)",
    category: "ORGANIC_INPUTS",
    description: "Biofertilizante 100% orgánico elaborado a partir de lixiviados de agave mezcalero y fermentos biológicos. Estimula el enraizamiento, aporta potasio asimilable y reactiva la microbiota del suelo.",
    priceMxn: 450,
    unit: "Garrafón 20L",
    availableStock: 120,
    imageUrl: "https://images.unsplash.com/photo-1585314062340-f1a5a7c9328d?q=80&w=800&auto=format&fit=crop",
    escrowProtected: true,
    fraudScore: 99,
    certifications: ["OMRI Listed Orgánico", "SENASICA Insumo Fitosanitario"],
    contactPhone: "+52 777 654 3210",
    contactEmail: "pedidos@bioinsumosanahuac.com",
    createdAt: "2026-01-15"
  },
  {
    id: "mkt-2",
    sellerId: "u1",
    sellerName: "Juan Pérez (Ejido San Miguel)",
    sellerRole: "PRODUCER",
    sellerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=150&auto=format&fit=crop",
    sellerLocation: "Oaxaca, México",
    isVerified: true,
    title: "Semilla Certificada de Maíz Criollo Azul Ancestral (Costal 25kg)",
    category: "SEEDS",
    description: "Semilla nativa no transgénica seleccionada ciclo a ciclo con alto vigor germinativo (+92%). Resistente a sequía y con denominación de origen comunitario de los Valles Centrales de Oaxaca.",
    priceMxn: 850,
    unit: "Costal 25kg",
    availableStock: 45,
    imageUrl: "https://images.unsplash.com/photo-1551754655-cd27e38d2076?q=80&w=800&auto=format&fit=crop",
    escrowProtected: true,
    fraudScore: 99,
    certifications: ["Certificado SAGARPA Orgánico", "Comercio Justo Ejidal"],
    contactPhone: "+52 951 234 5678",
    contactEmail: "juan.perez@ejidosanmiguel.org",
    createdAt: "2026-02-10"
  },
  {
    id: "mkt-3",
    sellerId: "u-agrodron",
    sellerName: "AgroDron Precisión & NDVI",
    sellerRole: "TRADER",
    sellerAvatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=150&auto=format&fit=crop",
    sellerLocation: "Querétaro, México",
    isVerified: true,
    title: "Mapeo Multiespectral con Dron y Diagnóstico NDVI de Salud de Parcela",
    category: "SERVICES",
    description: "Vuelo de escaneo agronómico con sensor multiespectral para detectar deficiencias de nitrógeno, plagas tempranas y estrés hídrico. Incluye reporte georreferenciado PDF y capas GIS.",
    priceMxn: 350,
    unit: "Por Hectárea",
    availableStock: 500,
    imageUrl: "https://images.unsplash.com/photo-1508614589041-895b88991e3e?q=80&w=800&auto=format&fit=crop",
    escrowProtected: true,
    fraudScore: 97,
    certifications: ["Piloto Certificado AFAC", "Firma Satelital Calibrada"],
    contactPhone: "+52 442 888 7766",
    contactEmail: "info@agrodronprecision.mx",
    createdAt: "2026-02-18"
  },
  {
    id: "mkt-4",
    sellerId: "u3",
    sellerName: "AgroComercial del Valle S.A.",
    sellerRole: "TRADER",
    sellerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=150&auto=format&fit=crop",
    sellerLocation: "Puebla, México",
    isVerified: true,
    title: "Flete Agrícola Refrigerado con Monitoreo Térmico Satelital",
    category: "LOGISTICS",
    description: "Servicio de transporte de cosechas y productos perecederos (aguacate, hortalizas, café pergamino) en caja refrigerada con telemetría en tiempo real y seguro de carga incluido.",
    priceMxn: 1200,
    unit: "Por Tonelada / 100km",
    availableStock: 30,
    imageUrl: "https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?q=80&w=800&auto=format&fit=crop",
    escrowProtected: true,
    fraudScore: 99,
    certifications: ["Cadena Fría ISO 9001", "Póliza de Seguro Quálitas"],
    contactPhone: "+52 222 456 7890",
    contactEmail: "ventas@agrocomercialvalle.mx",
    createdAt: "2026-02-22"
  }
];

export default function App() {
  // Application State
  const [lang, setLang] = useState<Language>('es');
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('milpa_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [currentView, setCurrentView] = useState<string>('LANDING');
  const [selectedNftCrop, setSelectedNftCrop] = useState<Crop | null>(null);
  const [editingNftCrop, setEditingNftCrop] = useState<Crop | null>(null);

  // User Profile Modal State
  const [selectedProfileUser, setSelectedProfileUser] = useState<UserProfile | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);
  const [reviews, setReviews] = useState<PeerReview[]>(() => {
    const saved = localStorage.getItem('milpa_reviews');
    return saved ? JSON.parse(saved) : initialReviews;
  });

  useEffect(() => {
    localStorage.setItem('milpa_reviews', JSON.stringify(reviews));
  }, [reviews]);

  const handleOpenUserProfile = (targetUser: Partial<UserProfile> | string) => {
    if (!targetUser) return;
    if (typeof targetUser === 'string') {
      if (targetUser.includes("Juan") || targetUser.includes("San Miguel")) {
        setSelectedProfileUser({
          id: "u1",
          name: "Juan Pérez (Ejido San Miguel)",
          role: "PRODUCER",
          balance: 15000,
          avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=150&auto=format&fit=crop",
          bio: "Productor agrícola ancestral en Oaxaca, México. Especialista en conservación de maíz criollo orgánico y técnicas regenerativas de conservación de humedad.",
          location: "Oaxaca, México",
          phone: "+52 951 832 9910",
          website: "ejidosanmiguel.org",
          farmHectares: 35,
          experienceYears: 18,
          certifications: ["Certificación Orgánica SAGARPA", "Sello Comercio Justo", "Huella Hídrica Sostenible"],
          rating: 5.0,
          photos: [
            "https://images.unsplash.com/photo-1551754655-cd27e38d2076?q=80&w=800&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?q=80&w=800&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1595974482597-4b8da8879bc5?q=80&w=800&auto=format&fit=crop"
          ]
        });
      } else if (targetUser.includes("Finca") || targetUser.includes("Niebla")) {
        setSelectedProfileUser({
          id: "u-finca",
          name: "Finca La Niebla (Café Chiapas)",
          role: "PRODUCER",
          balance: 28000,
          avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=150&auto=format&fit=crop",
          bio: "Cooperativa cafetalera de sombra en el Soconusco, Chiapas. Cultivo arábica con impacto ecológico y restauración forestal.",
          location: "Chiapas, México",
          phone: "+52 961 223 9011",
          website: "fincalaniebla.com",
          farmHectares: 60,
          experienceYears: 14,
          certifications: ["Rainforest Alliance", "Certificado Café de Sombra", "Fair Trade International"],
          rating: 4.8,
          photos: [
            "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=800&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?q=80&w=800&auto=format&fit=crop"
          ]
        });
      } else if (targetUser.includes("Huertos") || targetUser.includes("Valle")) {
        setSelectedProfileUser({
          id: "u-huertos",
          name: "Huertos del Valle (Michoacán)",
          role: "PRODUCER",
          balance: 45000,
          avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=150&auto=format&fit=crop",
          bio: "Huerta sustentable de aguacate Hass libre de deforestación. Sistema de irrigación por microgoteo e integración con IoT.",
          location: "Uruapan, Michoacán",
          phone: "+52 452 119 4022",
          website: "huertosdelvalle.mx",
          farmHectares: 40,
          experienceYears: 12,
          certifications: ["GlobalG.A.P.", "Certificación México Calidad Suprema"],
          rating: 4.9,
          photos: [
            "https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?q=80&w=800&auto=format&fit=crop"
          ]
        });
      } else if (targetUser.includes("Mezcaleros") || targetUser.includes("Dionisio")) {
        setSelectedProfileUser({
          id: "u-agave",
          name: "Mezcaleros San Dionisio",
          role: "PRODUCER",
          balance: 32000,
          avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=150&auto=format&fit=crop",
          bio: "Maestros mezcaleros dedicados al cultivo agroecológico de agave Espadín sin agroquímicos y reforestación de magueyes silvestres.",
          location: "San Dionisio Ocotepec, Oaxaca",
          phone: "+52 951 554 1099",
          website: "mezcalerosdionisio.mx",
          farmHectares: 50,
          experienceYears: 25,
          certifications: ["Certificación CRM Mezcal Artesanal", "Denominación de Origen"],
          rating: 5.0,
          photos: [
            "https://images.unsplash.com/photo-1596704017254-9b121068fb31?q=80&w=800&auto=format&fit=crop"
          ]
        });
      } else if (targetUser.includes("Elena")) {
        setSelectedProfileUser({
          id: "u2",
          name: "Elena Global Investments",
          role: "INVESTOR",
          balance: 50000,
          avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=150&auto=format&fit=crop",
          bio: "Fondo de inversión de impacto enfocado en la transición ecológica de la agricultura mexicana y el financiamiento de productores orgánicos.",
          location: "Ciudad de México / Monterrey",
          phone: "+52 55 8102 9940",
          website: "elenainvest.com",
          experienceYears: 12,
          rating: 5.0,
          photos: [
            "https://images.unsplash.com/photo-1530595467537-0b5996c41f2d?q=80&w=800&auto=format&fit=crop"
          ]
        });
      } else {
        setSelectedProfileUser({
          id: `u-${Date.now()}`,
          name: targetUser,
          role: "PRODUCER",
          balance: 10000,
          avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(targetUser)}`,
          bio: "Productor agrícola verificado en la plataforma Milpa Tech.",
          location: "México",
          rating: 4.8,
          photos: ["https://images.unsplash.com/photo-1530595467537-0b5996c41f2d?q=80&w=800&auto=format&fit=crop"]
        });
      }
    } else {
      setSelectedProfileUser(targetUser as UserProfile);
    }
    setIsProfileModalOpen(true);
  };

  const handleUpdateProfile = async (updated: UserProfile) => {
    if (currentUser && currentUser.id === updated.id) {
      saveUser(updated);
    }
    setSelectedProfileUser(updated);
    setUsers(prev => prev.map(u => u.id === updated.id ? updated : u));
    try {
      const userRef = doc(db, 'users', updated.id);
      await setDoc(userRef, sanitizeForFirestore(updated), { merge: true });
    } catch (err) {
      console.warn("Firestore user sync warning:", err);
    }
    showToast(lang === 'es' ? "¡Perfil y foto actualizados correctamente!" : "Profile & photo updated successfully!");
  };

  const handleUpdateCropImage = async (cropId: string, newImageUrl: string) => {
    setCrops(prev => {
      const updated = prev.map(c => c.id === cropId ? { ...c, imageUrl: newImageUrl } : c);
      localStorage.setItem('milpa_crops', JSON.stringify(updated));
      return updated;
    });
    try {
      const cropRef = doc(db, 'crops', cropId);
      await setDoc(cropRef, { imageUrl: newImageUrl }, { merge: true });
    } catch (err) {
      console.warn("Firestore crop image update warning:", err);
    }
    showToast(lang === 'es' ? "¡Imagen del cultivo actualizada con éxito!" : "Crop image updated successfully!");
  };

  const handleAddReview = async (newReview: PeerReview) => {
    setReviews(prev => [newReview, ...prev]);
    try {
      const revRef = doc(db, 'reviews', newReview.id);
      await setDoc(revRef, newReview);
    } catch (err) {
      console.warn("Firestore review sync warning:", err);
    }
    showToast(lang === 'es' ? "¡Reseña de validación publicada!" : "Validation review posted!");
  };

  const [cropToEditImage, setCropToEditImage] = useState<Crop | null>(null);

  const [crops, setCrops] = useState<Crop[]>(() => {
    const saved = localStorage.getItem('milpa_crops');
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as Crop[];
        return parsed.map(c => {
          const matchingInitial = initialCrops.find(ic => ic.id === c.id);
          if (matchingInitial) {
            return {
              ...matchingInitial,
              ...c,
              imageUrl: c.imageUrl || matchingInitial.imageUrl,
              name: c.name || matchingInitial.name
            };
          }
          return {
            ...c,
            openseaUrl: c.openseaUrl || `https://opensea.io/assets/matic/0x2953399124f0cbb46d2cbacd8a89cf0599974963/${c.id}`,
            nftContract: c.nftContract || "0x2953399124f0cbb46d2cbacd8a89cf0599974963",
            nftTokenId: c.nftTokenId || `#${c.id}`,
            nftStandard: c.nftStandard || "ERC-721"
          };
        });
      } catch (e) {
        return initialCrops;
      }
    }
    return initialCrops;
  });
  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem('milpa_messages');
    return saved ? JSON.parse(saved) : initialMessages;
  });
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('milpa_transactions');
    if (saved) return JSON.parse(saved);
    // Initial sample transaction for investor demo
    return [
      {
        id: "tx-1",
        cropName: "Aguacate Hass Regenerativo",
        amount: 150,
        price: 200,
        total: 30000,
        date: new Date().toLocaleDateString(),
        type: 'BUY',
        txHash: "0x7d39ca29f62c8e31a0e1cb30da9b6cf3e1c67dfa8183c5123a9b1c7c90b0e501"
      }
    ];
  });

  // Registered Users Directory State
  const [users, setUsers] = useState<UserProfile[]>(() => {
    const saved = localStorage.getItem('milpa_directory_users');
    return saved ? JSON.parse(saved) : initialRegisteredUsers;
  });

  // Marketplace Products & Services Catalog State
  const [marketplaceItems, setMarketplaceItems] = useState<MarketplaceItem[]>(() => {
    const saved = localStorage.getItem('milpa_mkt_items');
    return saved ? JSON.parse(saved) : initialMarketplaceItems;
  });

  // Seller Onboarding & KYC Modal State
  const [isSellerModalOpen, setIsSellerModalOpen] = useState<boolean>(false);

  // Direct User Interaction / Chat Modal State
  const [isDirectChatModalOpen, setIsDirectChatModalOpen] = useState<boolean>(false);
  const [directChatTargetUser, setDirectChatTargetUser] = useState<UserProfile | null>(null);

  // Marketplace Item Detail & Escrow Purchase Modal State
  const [isMarketplaceItemModalOpen, setIsMarketplaceItemModalOpen] = useState<boolean>(false);
  const [selectedMarketplaceItem, setSelectedMarketplaceItem] = useState<MarketplaceItem | null>(null);

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [isProductionModalOpen, setIsProductionModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Parse URL parameters on initial launch for invite links (?role=PRODUCER&register=true, ?launch=true)
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const roleParam = params.get('role');
      const registerParam = params.get('register');
      const launchParam = params.get('launch');

      if (launchParam === 'true') {
        setIsProductionModalOpen(true);
      } else if (registerParam === 'true' || roleParam) {
        setIsRegistering(true);
      }
    }
  }, []);

  // Real-time Firestore synchronizer for Crops, Transactions, Reviews, Users, Marketplace Items, and Messages
  useEffect(() => {
    // Synchronize initial crops to ensure updated photos/metadata propagate to Firestore
    initialCrops.forEach(async (c) => {
      try {
        await setDoc(doc(db, 'crops', c.id), sanitizeForFirestore(c), { merge: true });
      } catch (e) {
        console.warn("Firestore seed crop update notice:", e);
      }
    });

    // Listen to crops in Firestore
    const unsubCrops = onSnapshot(collection(db, 'crops'), (snapshot) => {
      if (!snapshot.empty) {
        const remoteCrops: Crop[] = [];
        snapshot.forEach((docSnap) => {
          const raw = { ...docSnap.data(), id: docSnap.id } as Crop;
          const matchingInitial = initialCrops.find(ic => ic.id === raw.id);
          if (matchingInitial) {
            remoteCrops.push({
              ...matchingInitial,
              ...raw,
              imageUrl: raw.imageUrl || matchingInitial.imageUrl,
              name: raw.name || matchingInitial.name
            });
          } else {
            remoteCrops.push(raw);
          }
        });
        if (remoteCrops.length > 0) {
          // Sort crops so standard initial crops appear in designated order
          const orderMap: Record<string, number> = { c1: 1, c2: 2, c3: 3, c4: 4 };
          remoteCrops.sort((a, b) => (orderMap[a.id] || 99) - (orderMap[b.id] || 99));
          setCrops(remoteCrops);
        }
      } else {
        // Seed initial crops to Firestore if remote collection is empty
        initialCrops.forEach(async (c) => {
          try {
            await setDoc(doc(db, 'crops', c.id), sanitizeForFirestore(c));
          } catch (e) {
            console.warn("Firestore seed crop warning:", e);
          }
        });
      }
    }, (err) => {
      console.warn("Firestore crops snapshot notice:", err);
    });

    // Listen to registered users directory in Firestore
    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      if (!snapshot.empty) {
        const remoteUsers: UserProfile[] = [];
        snapshot.forEach((docSnap) => {
          remoteUsers.push({ ...docSnap.data(), id: docSnap.id } as UserProfile);
        });
        if (remoteUsers.length > 0) {
          setUsers(remoteUsers);
        }
      } else {
        // Seed initial users to Firestore
        initialRegisteredUsers.forEach(async (u) => {
          try {
            await setDoc(doc(db, 'users', u.id), u);
          } catch (e) {
            console.warn("Firestore seed user warning:", e);
          }
        });
      }
    }, (err) => {
      console.warn("Firestore users snapshot notice:", err);
    });

    // Listen to marketplace products and services in Firestore
    const unsubMkt = onSnapshot(collection(db, 'marketplace_items'), (snapshot) => {
      if (!snapshot.empty) {
        const remoteItems: MarketplaceItem[] = [];
        snapshot.forEach((docSnap) => {
          remoteItems.push({ ...docSnap.data(), id: docSnap.id } as MarketplaceItem);
        });
        if (remoteItems.length > 0) {
          setMarketplaceItems(remoteItems);
        }
      } else {
        // Seed initial marketplace items
        initialMarketplaceItems.forEach(async (item) => {
          try {
            await setDoc(doc(db, 'marketplace_items', item.id), item);
          } catch (e) {
            console.warn("Firestore seed marketplace item warning:", e);
          }
        });
      }
    }, (err) => {
      console.warn("Firestore marketplace items snapshot notice:", err);
    });

    // Listen to transactions in Firestore
    const unsubTx = onSnapshot(collection(db, 'transactions'), (snapshot) => {
      if (!snapshot.empty) {
        const remoteTx: Transaction[] = [];
        snapshot.forEach((docSnap) => {
          remoteTx.push({ ...docSnap.data(), id: docSnap.id } as Transaction);
        });
        if (remoteTx.length > 0) {
          setTransactions(remoteTx);
        }
      }
    }, (err) => {
      console.warn("Firestore transactions snapshot notice:", err);
    });

    // Listen to reviews in Firestore
    const unsubReviews = onSnapshot(collection(db, 'reviews'), (snapshot) => {
      if (!snapshot.empty) {
        const remoteRev: PeerReview[] = [];
        snapshot.forEach((docSnap) => {
          remoteRev.push({ ...docSnap.data(), id: docSnap.id } as PeerReview);
        });
        if (remoteRev.length > 0) {
          setReviews(remoteRev);
        }
      }
    }, (err) => {
      console.warn("Firestore reviews snapshot notice:", err);
    });

    return () => {
      unsubCrops();
      unsubUsers();
      unsubMkt();
      unsubTx();
      unsubReviews();
    };
  }, []);

  // Persistence helpers
  useEffect(() => {
    localStorage.setItem('milpa_crops', JSON.stringify(crops));
  }, [crops]);

  useEffect(() => {
    localStorage.setItem('milpa_directory_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('milpa_mkt_items', JSON.stringify(marketplaceItems));
  }, [marketplaceItems]);

  useEffect(() => {
    localStorage.setItem('milpa_messages', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem('milpa_transactions', JSON.stringify(transactions));
  }, [transactions]);

  const saveUser = (user: UserProfile | null) => {
    setCurrentUser(user);
    if (user) {
      localStorage.setItem('milpa_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('milpa_user');
    }
  };

  // Toast notifier
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Helper translation function
  const t = (key: string, replacements?: Record<string, string | number>) => {
    let text = translations[lang][key as keyof typeof translations['es']] || key;
    if (replacements) {
      Object.entries(replacements).forEach(([k, v]) => {
        text = text.replace(`{${k}}`, String(v));
      });
    }
    return text;
  };

  // Demo Logins
  const handleDemoLogin = (role: 'PRODUCER' | 'INVESTOR' | 'TRADER') => {
    if (role === 'PRODUCER') {
      const producer: UserProfile = {
        id: "u1",
        name: "Juan Pérez (Ejido San Miguel)",
        role: "PRODUCER",
        balance: 15000,
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=150&auto=format&fit=crop",
        walletAddress: "0x3db5ae71bca21cf29871fa8d810ba2cde1297fb9",
        location: "Oaxaca, México",
        bio: "Productor agrícola sustentable registrado en Milpa Tech.",
        farmHectares: 25
      };
      saveUser(producer);
      setCurrentView('DASHBOARD');
      showToast(lang === 'es' ? "Sesión iniciada como Productor (Demo)" : "Logged in as Producer (Demo)");
    } else if (role === 'INVESTOR') {
      const investor: UserProfile = {
        id: "u2",
        name: "Elena Global Investments",
        role: "INVESTOR",
        balance: 50000,
        avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=150&auto=format&fit=crop",
        walletAddress: "0x7a8fc8e31a0e1cb30da9b6cf3e1c67dfa8183c51",
        location: "CDMX, México",
        bio: "Inversionista de impacto enfocado en agricultura regenerativa."
      };
      saveUser(investor);
      setCurrentView('MARKETPLACE');
      showToast(lang === 'es' ? "Sesión iniciada como Inversionista (Demo)" : "Logged in as Investor (Demo)");
    } else {
      const trader: UserProfile = {
        id: "u3",
        name: "AgroComercial del Valle S.A.",
        role: "TRADER",
        balance: 38000,
        avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=150&auto=format&fit=crop",
        walletAddress: "0x3f5ce5fbfe3e9af3971dd833d26ba9b5c936f0be",
        location: "Jalisco, México",
        bio: "Comercializadora y compradora de cosechas y contratos tokenizados en Marketplace.",
        tradingVolume: 450000
      };
      saveUser(trader);
      setCurrentView('MARKETPLACE');
      showToast(lang === 'es' ? "Sesión iniciada como Comprador/Vendedor (Demo)" : "Logged in as Trader (Demo)");
    }
  };

  // Auth Modal State
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'LOGIN' | 'REGISTER'>('LOGIN');
  const [authModalInitialRole, setAuthModalInitialRole] = useState<'PRODUCER' | 'INVESTOR' | 'TRADER'>('PRODUCER');

  const handleOpenLogin = (role?: 'PRODUCER' | 'INVESTOR' | 'TRADER') => {
    setAuthModalMode('LOGIN');
    if (role) setAuthModalInitialRole(role);
    setIsAuthModalOpen(true);
  };

  const handleOpenRegister = (role?: 'PRODUCER' | 'INVESTOR' | 'TRADER') => {
    setAuthModalMode('REGISTER');
    if (role) setAuthModalInitialRole(role);
    setIsAuthModalOpen(true);
  };

  // Firebase Auth Google Sign-in
  const handleGoogleSignIn = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;

      const userRef = doc(db, 'users', fbUser.uid);
      const userSnap = await getDoc(userRef);

      let profile: UserProfile;

      if (userSnap.exists()) {
        profile = userSnap.data() as UserProfile;
      } else {
        profile = {
          id: fbUser.uid,
          name: fbUser.displayName || 'Usuario Milpa',
          role: 'INVESTOR',
          balance: 35000,
          avatar: fbUser.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(fbUser.displayName || 'Milpa')}`,
          walletAddress: "0x" + fbUser.uid.toLowerCase().replace(/[^a-f0-9]/g, '').padEnd(40, '0').slice(0, 40)
        };
        await setDoc(userRef, sanitizeForFirestore(profile));
      }

      saveUser(profile);
      setCurrentView('MARKETPLACE');
      showToast(lang === 'es' ? `¡Bienvenido con Google, ${profile.name}!` : `Welcome with Google, ${profile.name}!`);
    } catch (err: any) {
      console.error("Google Sign-In Error:", err);
      showToast(lang === 'es' ? "Iniciando sesión con Google..." : "Signing in with Google...");
    }
  };

  // Handle Logout
  const handleLogout = async () => {
    try {
      await firebaseSignOut(auth);
    } catch (e) {
      console.warn("Firebase signout warning", e);
    }
    saveUser(null);
    setCurrentView('LANDING');
    showToast(lang === 'es' ? "Sesión cerrada correctamente" : "Logged out successfully");
  };

  // Firebase auth & connection initialization
  useEffect(() => {
    testFirebaseConnection();

    const unsubscribeAuth = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        try {
          const userRef = doc(db, 'users', fbUser.uid);
          const userSnap = await getDoc(userRef);
          if (userSnap.exists()) {
            setCurrentUser(userSnap.data() as UserProfile);
          }
        } catch (e) {
          console.error("Error reading user profile from Firestore:", e);
        }
      }
    });

    return () => unsubscribeAuth();
  }, []);

  // Navigation Options
  const navigationItems = [
    { id: "ABOUT", labelKey: "nav_about", icon: Info, roles: ["PRODUCER", "INVESTOR", "TRADER", "GUEST"] },
    { id: "COMMUNITY", labelKey: "nav_community", icon: Users, roles: ["PRODUCER", "INVESTOR", "TRADER", "GUEST"] },
    { id: "MARKETPLACE", labelKey: "nav_marketplace", icon: ShoppingBag, roles: ["PRODUCER", "INVESTOR", "TRADER", "GUEST"] },
    { id: "LEDGER", labelKey: "nav_ledger", icon: Coins, roles: ["PRODUCER", "INVESTOR", "TRADER", "GUEST"] },
    { id: "AI_BOT", labelKey: "nav_ai_bot", icon: Bot, roles: ["PRODUCER", "INVESTOR", "TRADER", "GUEST"] },
    { id: "DASHBOARD", labelKey: "nav_dashboard", icon: LayoutDashboard, roles: ["PRODUCER", "INVESTOR", "TRADER"] },
    { id: "CHAT", labelKey: "nav_messages", icon: MessageSquare, roles: ["PRODUCER", "INVESTOR", "TRADER"] },
    { id: "AI_RISK", labelKey: "nav_ai", icon: Brain, roles: ["PRODUCER", "INVESTOR", "TRADER"] },
    { id: "WALLET", labelKey: "nav_wallet", icon: Wallet, roles: ["PRODUCER", "INVESTOR", "TRADER"] }
  ];

  const allowedNav = navigationItems.filter(item => {
    if (!currentUser) {
      return item.id === "ABOUT" || item.id === "COMMUNITY" || item.id === "MARKETPLACE" || item.id === "LANDING" || item.id === "AI_BOT" || item.id === "LEDGER";
    }
    return item.roles.includes(currentUser.role);
  });

  // Modal Dialogs
  const [isBuyModalOpen, setIsBuyModalOpen] = useState(false);
  const [selectedCropToBuy, setSelectedCropToBuy] = useState<Crop | null>(null);
  const [buyAmount, setBuyAmount] = useState<number>(10);

  const [isAddCropModalOpen, setIsAddCropModalOpen] = useState(false);
  const [isFloatingChatOpen, setIsFloatingChatOpen] = useState(false);
  const [isLedgerModalOpen, setIsLedgerModalOpen] = useState(false);
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [onboardingWalletAddress, setOnboardingWalletAddress] = useState<string>('');
  const [web3WalletProvider, setWeb3WalletProvider] = useState<string>('Polygon Web3');

  // Web3 / MetaMask Connection Handler
  const handleWalletConnected = (address: string, providerName: string) => {
    setWeb3WalletProvider(providerName);
    if (isRegistering) {
      setOnboardingWalletAddress(address);
    }
    if (currentUser) {
      const updated: UserProfile = {
        ...currentUser,
        walletAddress: address
      };
      saveUser(updated);
      try {
        const userRef = doc(db, 'users', currentUser.id);
        setDoc(userRef, { walletAddress: address }, { merge: true });
      } catch (e) {
        console.warn("Firestore wallet sync notice:", e);
      }
    }
    showToast(
      lang === 'es'
        ? `🦊 Billetera vinculada (${providerName}): ${address.slice(0, 6)}...${address.slice(-4)}`
        : `🦊 Wallet linked (${providerName}): ${address.slice(0, 6)}...${address.slice(-4)}`
    );
  };

  const handleUpdateBalance = (newBalance: number) => {
    if (currentUser) {
      const updated = { ...currentUser, balance: newBalance };
      saveUser(updated);
      showToast(lang === 'es' ? "¡Fondos de prueba acreditados en tu billetera!" : "Test funds credited to your wallet!");
    }
  };

  // Listen to external MetaMask account changes if available
  useEffect(() => {
    if (typeof window !== 'undefined' && (window as any).ethereum) {
      const ethereum = (window as any).ethereum;
      const handleAccountsChanged = (accounts: string[]) => {
        if (accounts && accounts.length > 0 && currentUser) {
          const newAccount = accounts[0];
          if (newAccount.toLowerCase() !== currentUser.walletAddress?.toLowerCase()) {
            const updated = { ...currentUser, walletAddress: newAccount };
            saveUser(updated);
            showToast(
              lang === 'es'
                ? `🦊 Cuenta de MetaMask actualizada: ${newAccount.slice(0, 6)}...${newAccount.slice(-4)}`
                : `🦊 MetaMask account updated: ${newAccount.slice(0, 6)}...${newAccount.slice(-4)}`
            );
          }
        }
      };

      try {
        ethereum.on?.('accountsChanged', handleAccountsChanged);
      } catch (err) {
        console.warn("MetaMask accounts listener notice:", err);
      }

      return () => {
        try {
          ethereum.removeListener?.('accountsChanged', handleAccountsChanged);
        } catch (e) {}
      };
    }
  }, [currentUser, lang]);

  // Real-time price simulation handler
  const handleSimulatePriceUpdate = () => {
    setCrops(prevCrops => {
      return prevCrops.map(crop => {
        const deltaPct = (Math.random() * 5 - 2.2); // -2.2% to +2.8%
        const newPrice = Math.max(10, Number((crop.tokenPrice * (1 + deltaPct / 100)).toFixed(2)));
        const change24h = Number(((crop.priceChange24h ?? 0) + deltaPct).toFixed(2));
        return {
          ...crop,
          previousTokenPrice: crop.tokenPrice,
          tokenPrice: newPrice,
          priceChange24h: change24h
        };
      });
    });
    showToast(lang === 'es' ? "⚡ Precios de mercado de cultivos actualizados en tiempo real" : "⚡ Real-time crop market prices updated");
  };

  // Real-time weather update handler
  const handleSimulateWeatherChange = () => {
    setCrops(prevCrops => {
      return prevCrops.map(crop => {
        if (!crop.weather) return crop;
        const tempDelta = (Math.random() * 1.2 - 0.6);
        const humDelta = Math.floor(Math.random() * 5 - 2);
        const newTemp = Number((crop.weather.tempC + tempDelta).toFixed(1));
        const newHum = Math.min(95, Math.max(20, crop.weather.humidityPct + humDelta));
        const newSoil = Math.min(90, Math.max(20, crop.weather.soilMoisturePct + Math.floor(Math.random() * 3 - 1)));
        return {
          ...crop,
          weather: {
            ...crop.weather,
            tempC: newTemp,
            humidityPct: newHum,
            soilMoisturePct: newSoil
          }
        };
      });
    });
    showToast(lang === 'es' ? "🌤️ Lecturas de estaciones meteorológicas e IoT actualizadas" : "🌤️ Weather station & IoT telemetry updated");
  };

  // Real-time transaction simulation
  const handleSimulateTransaction = () => {
    const randomCrop = crops[Math.floor(Math.random() * crops.length)];
    const tokenQty = Math.floor(Math.random() * 80) + 10;
    const totalVal = tokenQty * randomCrop.tokenPrice;
    const names = ["Fondo Semilla Maya", "AgroImpact Capital", "Inversor Ecológico CDMX", "Valle Verde Capital", "Green Impact Fund"];
    const randomName = names[Math.floor(Math.random() * names.length)];

    const simTx: Transaction = {
      id: `tx-sim-${Date.now()}`,
      cropName: randomCrop.name,
      cropId: randomCrop.id,
      userName: randomName,
      userRole: "INVESTOR",
      amount: tokenQty,
      price: randomCrop.tokenPrice,
      total: totalVal,
      date: new Date().toLocaleDateString(lang === 'es' ? 'es-MX' : 'en-US', { day: '2-digit', month: 'short', year: 'numeric' }) + ", " + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: 'BUY',
      txHash: "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(""),
      blockNumber: 18492500 + transactions.length
    };

    setTransactions(prev => [simTx, ...prev]);
    showToast(lang === 'es' ? `🔗 Nueva transacción en bloque: ${tokenQty} tokens de ${randomCrop.name}` : `🔗 New block transaction: ${tokenQty} tokens of ${randomCrop.name}`);
  };

  // Add Log event handler for crop development
  const handleAddLogEvent = (cropId: string, log: DevelopmentLog, newProgressPct?: number) => {
    setCrops(prevCrops => {
      return prevCrops.map(crop => {
        if (crop.id === cropId && crop.development) {
          const updatedLogs = [log, ...crop.development.logEvents];
          return {
            ...crop,
            development: {
              ...crop.development,
              progressPct: newProgressPct !== undefined ? newProgressPct : crop.development.progressPct,
              lastUpdateDate: "Hoy, " + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              updateNote: log.description,
              updateNoteEn: log.description,
              logEvents: updatedLogs
            }
          };
        }
        return crop;
      });
    });
    showToast(lang === 'es' ? "¡Evento de campo registrado en la bitácora!" : "Field log event recorded!");
  };

  // Auto real-time price & telemetry ticker interval (runs every 10 seconds)
  useEffect(() => {
    const tickerInterval = setInterval(() => {
      setCrops(prevCrops => {
        return prevCrops.map(crop => {
          const deltaPct = (Math.random() * 0.8 - 0.35);
          const newPrice = Math.max(10, Number((crop.tokenPrice * (1 + deltaPct / 100)).toFixed(2)));
          return {
            ...crop,
            tokenPrice: newPrice,
            priceChange24h: Number(((crop.priceChange24h || 0) + deltaPct).toFixed(2))
          };
        });
      });
    }, 10000);

    return () => clearInterval(tickerInterval);
  }, []);

  // Handle Crop Buy action
  const triggerBuy = (crop: Crop) => {
    if (!currentUser) {
      showToast(t("login_required"));
      return;
    }
    setSelectedCropToBuy(crop);
    setBuyAmount(Math.min(50, crop.totalTokens - crop.soldTokens));
    setIsBuyModalOpen(true);
  };

  const handleConfirmPurchase = async () => {
    if (!currentUser || !selectedCropToBuy) return;
    const totalPrice = selectedCropToBuy.tokenPrice * buyAmount;

    if (currentUser.balance < totalPrice) {
      showToast(t("insufficient_funds"));
      return;
    }

    // Deduct user balance
    const updatedUser = {
      ...currentUser,
      balance: currentUser.balance - totalPrice
    };
    saveUser(updatedUser);

    // Update crop sold count
    const updatedCrops = crops.map(c => {
      if (c.id === selectedCropToBuy.id) {
        return { ...c, soldTokens: c.soldTokens + buyAmount };
      }
      return c;
    });
    setCrops(updatedCrops);

    // Register Blockchain Transaction
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      cropName: selectedCropToBuy.name,
      cropId: selectedCropToBuy.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      amount: buyAmount,
      price: selectedCropToBuy.tokenPrice,
      total: totalPrice,
      date: new Date().toLocaleDateString(lang === 'es' ? 'es-MX' : 'en-US', { day: '2-digit', month: 'short', year: 'numeric' }) + ", " + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: 'BUY',
      txHash: "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(""),
      blockNumber: 18492000 + transactions.length
    };
    setTransactions([newTx, ...transactions]);

    // Persist real-time transaction in Firestore
    try {
      await setDoc(doc(db, 'users', currentUser.id), { balance: updatedUser.balance }, { merge: true });
      await setDoc(doc(db, 'crops', selectedCropToBuy.id), { soldTokens: selectedCropToBuy.soldTokens + buyAmount }, { merge: true });
      await setDoc(doc(db, 'transactions', newTx.id), newTx);
    } catch (e) {
      console.warn("Firestore purchase sync notice:", e);
    }

    setIsBuyModalOpen(false);
    showToast(t("invest_success", { amount: buyAmount, name: selectedCropToBuy.name, total: totalPrice.toLocaleString() }));
  };

  // Direct Inter-User Messaging Handler
  const handleDirectChatMessage = async (newMsg: Message) => {
    setMessages(prev => [newMsg, ...prev]);
    try {
      const msgRef = doc(db, 'messages', newMsg.id);
      await setDoc(msgRef, newMsg);
    } catch (err) {
      console.warn("Firestore message sync error:", err);
    }
    showToast(lang === 'es' ? "¡Mensaje o propuesta comercial enviada con éxito!" : "Message or business proposal sent successfully!");
  };

  // Anti-Fraud KYC Seller Registration Application Handler
  const handleSellerRegistrationComplete = (updatedUser: UserProfile, newItem?: MarketplaceItem) => {
    saveUser(updatedUser);
    setUsers(prev => {
      const filtered = prev.filter(u => u.id !== updatedUser.id);
      return [updatedUser, ...filtered];
    });
    if (newItem) {
      setMarketplaceItems(prev => [newItem, ...prev.filter(m => m.id !== newItem.id)]);
    }

    setIsSellerModalOpen(false);
    showToast(
      lang === 'es'
        ? `¡Felicitaciones ${updatedUser.name}! Tu alta como Vendedor Verificado y producto han sido registrados.`
        : `Congratulations ${updatedUser.name}! Your verified seller onboarding and product have been registered.`
    );
  };

  // Add new Product or Service to Marketplace
  const handleCreateMarketplaceItem = async (newItem: MarketplaceItem) => {
    setMarketplaceItems(prev => [newItem, ...prev]);
    try {
      await setDoc(doc(db, 'marketplace_items', newItem.id), newItem);
    } catch (e) {
      console.warn("Firestore marketplace item save warning:", e);
    }
    showToast(lang === 'es' ? "¡Producto/Servicio publicado con éxito en el Marketplace!" : "Product/Service published successfully to Marketplace!");
  };

  // Smart Escrow Purchase Handler for Marketplace Items
  const handleMarketplacePurchase = async (item: MarketplaceItem, quantity: number, useEscrow: boolean) => {
    if (!currentUser) {
      handleOpenLogin();
      return;
    }
    const totalCost = item.priceMxn * quantity;
    if (currentUser.balance < totalCost) {
      showToast(lang === 'es' ? "Saldo insuficiente en billetera para completar la compra" : "Insufficient wallet balance to complete purchase");
      return;
    }

    const updatedUser = {
      ...currentUser,
      balance: currentUser.balance - totalCost
    };
    saveUser(updatedUser);

    // Update item stock
    setMarketplaceItems(prev => prev.map(m => m.id === item.id ? { ...m, availableStock: Math.max(0, m.availableStock - quantity) } : m));

    const newTx: Transaction = {
      id: `tx-mkt-${Date.now()}`,
      cropName: `${item.title} (${quantity} ${item.unit})`,
      cropId: item.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      amount: quantity,
      price: item.priceMxn,
      total: totalCost,
      date: new Date().toLocaleDateString(lang === 'es' ? 'es-MX' : 'en-US', { day: '2-digit', month: 'short', year: 'numeric' }) + ", " + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: 'BUY',
      txHash: "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(""),
      blockNumber: 18492000 + transactions.length
    };

    setTransactions(prev => [newTx, ...prev]);

    try {
      await setDoc(doc(db, 'users', currentUser.id), { balance: updatedUser.balance }, { merge: true });
      await setDoc(doc(db, 'marketplace_items', item.id), { availableStock: Math.max(0, item.availableStock - quantity) }, { merge: true });
      await setDoc(doc(db, 'transactions', newTx.id), newTx);
    } catch (e) {
      console.warn("Firestore purchase sync notice:", e);
    }

    setIsMarketplaceItemModalOpen(false);
    showToast(
      lang === 'es'
        ? `🔒 Orden protegida con Smart Escrow: $${totalCost.toLocaleString()} MXN para ${item.title}`
        : `🔒 Smart Escrow protected order: $${totalCost.toLocaleString()} MXN for ${item.title}`
    );
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-50 text-slate-800" id="main-layout">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-[99] bg-green-900 text-white px-6 py-4 rounded-xl shadow-2xl flex items-center gap-3 animate-bounce border border-green-700" id="app-toast">
          <CheckCircle className="h-6 w-6 text-green-400" />
          <span className="font-semibold text-sm">{toastMessage}</span>
        </div>
      )}

      {/* Mobile Header */}
      <header className="md:hidden bg-green-900 text-white p-4 flex justify-between items-center sticky top-0 z-50 shadow-md" id="mobile-header">
        <div className="flex items-center cursor-pointer" onClick={() => { setCurrentView('LANDING'); setMobileMenuOpen(false); }}>
          <MilpaLogo variant="full" size={32} />
        </div>
        <div className="flex items-center gap-3">
          {/* Language toggle shortcut */}
          <button
            onClick={() => setLang(lang === 'es' ? 'en' : 'es')}
            className="p-1 hover:bg-green-800 rounded text-green-200 transition-colors flex items-center gap-1 text-xs font-bold"
          >
            <Globe className="h-4 w-4" />
            <span>{lang === 'es' ? 'EN' : 'ES'}</span>
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-1 text-green-100 hover:text-white"
            id="mobile-menu-toggle"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </header>

      {/* Sidebar Navigation */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-green-950 text-slate-100 transition-transform transform 
          ${mobileMenuOpen ? "translate-x-0" : "-translate-x-full"} 
          md:translate-x-0 md:static md:flex md:flex-col shadow-2xl`}
        id="app-sidebar"
      >
        {/* Sidebar Brand Logo */}
        <div className="p-6 border-b border-green-900 flex items-center gap-3 cursor-pointer group" onClick={() => { setCurrentView('LANDING'); setMobileMenuOpen(false); }}>
          <MilpaLogo variant="full" size={38} />
        </div>

        {/* Logged in User Profile Info */}
        <div className="p-4" id="sidebar-user-section">
          {currentUser ? (
            <div className="mb-6 bg-green-900/50 border border-green-800/40 p-3.5 rounded-2xl flex items-center justify-between gap-2 shadow-inner">
              <div className="flex items-center gap-3 overflow-hidden cursor-pointer group" onClick={() => handleOpenUserProfile(currentUser)}>
                <img src={currentUser.avatar} alt="User Avatar" className="w-10 h-10 rounded-full border-2 border-emerald-400 object-cover shrink-0" />
                <div className="overflow-hidden">
                  <p className="text-xs font-black truncate text-white group-hover:text-emerald-300 transition-colors">{currentUser.name}</p>
                  <p className="text-[10px] text-emerald-300 capitalize font-bold">
                    {currentUser.role === 'INVESTOR' 
                      ? (lang === 'es' ? '💰 Inversionista' : '💰 Investor') 
                      : currentUser.role === 'TRADER'
                      ? (lang === 'es' ? '🛒 Comprador/Vendedor' : '🛒 Trader / Buyer')
                      : (lang === 'es' ? '🌱 Productor' : '🌱 Producer')}
                  </p>
                </div>
              </div>
              <button
                onClick={() => handleOpenUserProfile(currentUser)}
                className="p-2 rounded-xl bg-green-800/80 hover:bg-emerald-600 text-green-200 hover:text-white transition-all text-xs font-bold shrink-0 border border-green-700/50"
                title={lang === 'es' ? "Ver Perfil Público" : "View Public Profile"}
              >
                <UserCheck className="w-4 h-4 text-emerald-300" />
              </button>
            </div>
          ) : (
            <div className="mb-6 bg-green-900/30 p-3 rounded-2xl border border-green-800/50 text-center space-y-2.5">
              <button
                onClick={() => { handleOpenLogin(); setMobileMenuOpen(false); }}
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white py-2.5 px-3 rounded-xl text-xs font-black transition-all shadow-md flex items-center justify-center gap-2 border border-emerald-400/40 active:scale-95"
              >
                <User className="w-4 h-4 text-white" />
                <span>{lang === 'es' ? "Iniciar / Registrarse" : "Log In / Sign Up"}</span>
              </button>

              <button
                onClick={() => { handleGoogleSignIn(); setMobileMenuOpen(false); }}
                className="w-full bg-white hover:bg-slate-100 text-slate-900 py-2 px-3 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-2 border border-slate-200"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                </svg>
                <span>{lang === 'es' ? "Entrar con Google" : "Sign in with Google"}</span>
              </button>

              <div className="pt-2 border-t border-green-800/60">
                <p className="text-[10px] uppercase font-black text-green-400 tracking-wider mb-1.5">{t("demo_mode")}</p>
                <div className="grid grid-cols-1 gap-1.5">
                  <button
                    onClick={() => { handleDemoLogin('PRODUCER'); setMobileMenuOpen(false); }}
                    className="w-full bg-emerald-700/80 hover:bg-emerald-600 text-white py-1.5 px-2 rounded-lg text-[11px] font-bold transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span>🌱 {lang === 'es' ? "Productor Demo" : "Producer Demo"}</span>
                  </button>
                  <button
                    onClick={() => { handleDemoLogin('INVESTOR'); setMobileMenuOpen(false); }}
                    className="w-full bg-blue-700/80 hover:bg-blue-600 text-white py-1.5 px-2 rounded-lg text-[11px] font-bold transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span>💰 {lang === 'es' ? "Inversionista Demo" : "Investor Demo"}</span>
                  </button>
                  <button
                    onClick={() => { handleDemoLogin('TRADER'); setMobileMenuOpen(false); }}
                    className="w-full bg-amber-600/80 hover:bg-amber-500 text-white py-1.5 px-2 rounded-lg text-[11px] font-bold transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span>🛒 {lang === 'es' ? "Comprador Demo" : "Trader Demo"}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Navigation Links */}
          <nav className="space-y-1.5" id="sidebar-nav">
            {allowedNav.map(item => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentView(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-200 ${
                    isActive
                      ? "bg-emerald-600 text-white shadow-md shadow-emerald-900/30 translate-x-1"
                      : "text-slate-300 hover:bg-green-900/60 hover:text-white"
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span>{t(item.labelKey)}</span>
                </button>
              );
            })}

            {/* Launch to Production / User Generation Modal trigger button */}
            <button
              onClick={() => {
                setIsProductionModalOpen(true);
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold bg-gradient-to-r from-amber-500/20 via-emerald-500/20 to-sky-500/20 border border-amber-400/40 text-amber-300 hover:bg-amber-500/30 transition-all duration-200 shadow-md group mt-3"
            >
              <Sparkles className="h-5 w-5 text-amber-400 group-hover:rotate-12 transition-transform" />
              <span>{lang === 'es' ? "🚀 Lanzar en Producción" : "🚀 Launch to Production"}</span>
            </button>
          </nav>
        </div>

        {/* Language Selection & Sidebar Footer */}
        <div className="mt-auto p-4 border-t border-green-900/60 space-y-4 bg-green-950" id="sidebar-footer">
          {/* Language Toggle Pill Container */}
          <div>
            <label className="block text-[10px] uppercase font-bold text-green-400 tracking-wider mb-2">
              {lang === 'es' ? 'Idioma / Language' : 'Language / Idioma'}
            </label>
            <div className="grid grid-cols-2 p-1 bg-green-900/40 rounded-lg border border-green-800">
              <button
                onClick={() => setLang('es')}
                className={`py-1.5 text-xs font-bold rounded-md transition-all ${
                  lang === 'es' ? 'bg-emerald-500 text-green-950 shadow-sm' : 'text-slate-300 hover:text-white'
                }`}
              >
                Español
              </button>
              <button
                onClick={() => setLang('en')}
                className={`py-1.5 text-xs font-bold rounded-md transition-all ${
                  lang === 'en' ? 'bg-emerald-500 text-green-950 shadow-sm' : 'text-slate-300 hover:text-white'
                }`}
              >
                English
              </button>
            </div>
          </div>

          {currentUser ? (
            <button
              onClick={handleLogout}
              className="w-full flex items-center justify-center gap-2 text-red-300 hover:text-red-200 hover:bg-red-950/40 py-2.5 rounded-xl border border-red-900/20 text-xs font-bold transition-all duration-200"
            >
              <LogOut className="h-4 w-4" />
              <span>{t("nav_logout")}</span>
            </button>
          ) : (
            <div className="text-[10px] text-center text-green-400/60 tracking-tight">
              &copy; 2026 Milpa Tech. All rights reserved.
            </div>
          )}
        </div>
      </aside>

      {/* Main Content Pane */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden" id="main-content">
        {/* Real Time Market Price Ticker */}
        <RealTimePriceTicker
          crops={crops}
          lang={lang}
          onSimulatePriceUpdate={handleSimulatePriceUpdate}
        />

        {/* Header Title Bar */}
        <header className="hidden md:flex bg-white shadow-sm border-b border-slate-100 p-6 items-center justify-between z-30" id="desktop-header">
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-black text-slate-800 tracking-tight">
              {currentView === 'ABOUT' && t("title_about")}
              {currentView === 'LANDING' && t("welcome")}
              {currentView === 'COMMUNITY' && t("title_community")}
              {currentView === 'MARKETPLACE' && t("title_marketplace")}
              {currentView === 'LEDGER' && t("title_ledger")}
              {currentView === 'DASHBOARD' && t("title_dashboard")}
              {currentView === 'AI_RISK' && t("title_ai")}
              {currentView === 'AI_BOT' && t("title_ai_bot")}
              {currentView === 'WALLET' && t("title_wallet")}
              {currentView === 'CHAT' && t("title_messages")}
            </h2>
            {currentView === 'LANDING' && (
              <span className="bg-emerald-50 text-emerald-700 font-bold text-[10px] tracking-wide uppercase px-2 py-0.5 rounded border border-emerald-200">
                Regenerative platform
              </span>
            )}
            {currentView === 'COMMUNITY' && (
              <span className="bg-emerald-100 text-emerald-800 font-black text-[10px] tracking-wide uppercase px-2.5 py-0.5 rounded-full border border-emerald-300">
                {lang === 'es' ? "Usuarios & Vendedores Verificados" : "Verified Users & Sellers"}
              </span>
            )}
            {currentView === 'ABOUT' && (
              <span className="bg-emerald-100 text-emerald-800 font-black text-[10px] tracking-wide uppercase px-2.5 py-0.5 rounded-full border border-emerald-300">
                {lang === 'es' ? "Documento & Pitch Deck" : "Document & Pitch Deck"}
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            {!currentUser ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleOpenLogin()}
                  className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-2xl text-xs font-bold transition-all border border-slate-300 shadow-sm active:scale-95 flex items-center gap-1.5"
                  id="header-login-btn"
                >
                  <User className="w-3.5 h-3.5 text-slate-700" />
                  <span>{lang === 'es' ? "Iniciar Sesión" : "Log In"}</span>
                </button>

                <button
                  onClick={() => handleOpenRegister()}
                  className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white rounded-2xl text-xs font-black transition-all border border-emerald-400/40 shadow-md shadow-emerald-900/20 active:scale-95 flex items-center gap-1.5"
                  id="header-register-btn"
                >
                  <UserPlus className="w-3.5 h-3.5 text-white" />
                  <span>{lang === 'es' ? "Registrarse" : "Sign Up"}</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleOpenUserProfile(currentUser)}
                  className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 hover:bg-emerald-50 rounded-2xl border border-slate-200 hover:border-emerald-300 transition-all group"
                  title={lang === 'es' ? "Ver o editar perfil" : "View or edit profile"}
                >
                  <img src={currentUser.avatar} alt="User avatar" className="w-6 h-6 rounded-full object-cover border border-emerald-500" />
                  <span className="text-xs font-black text-slate-800 group-hover:text-emerald-700">{currentUser.name}</span>
                  <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                    currentUser.role === 'INVESTOR' 
                      ? 'bg-blue-100 text-blue-800' 
                      : currentUser.role === 'TRADER'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}>
                    {currentUser.role === 'INVESTOR' ? (lang === 'es' ? 'Inversionista' : 'Investor') : currentUser.role === 'TRADER' ? (lang === 'es' ? 'Comprador' : 'Trader') : (lang === 'es' ? 'Productor' : 'Producer')}
                  </span>
                </button>
              </div>
            )}

            {/* Production Launch & User Setup Modal Button */}
            <button
              onClick={() => setIsProductionModalOpen(true)}
              className="flex items-center gap-2 px-3.5 py-2 bg-gradient-to-r from-slate-900 to-emerald-950 hover:from-slate-800 hover:to-emerald-900 text-white rounded-2xl text-xs font-black transition-all border border-emerald-500/40 shadow-sm shadow-emerald-900/20 active:scale-95 group"
              id="header-prod-launch-btn"
              title={lang === 'es' ? "Lanzar en Dominio Real, Crear Usuarios y Gestionar Piloto" : "Launch on Real Domain, Create Users & Manage Pilot"}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300 group-hover:rotate-12 transition-transform" />
              <span>{lang === 'es' ? "🚀 Alta Rápida & Piloto" : "🚀 Quick Pilot & Users"}</span>
            </button>

            {/* Web3 / MetaMask Wallet Status Button */}
            <button
              onClick={() => setIsWalletModalOpen(true)}
              className="flex items-center gap-2 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-xs font-bold transition-all border border-slate-700 shadow-sm active:scale-95 group"
              id="header-web3-wallet-btn"
              title={lang === 'es' ? "Conectar o Gestionar Billetera Web3 / MetaMask" : "Connect or Manage Web3 / MetaMask Wallet"}
            >
              <div className="w-5 h-5 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                <Wallet className="w-3 h-3" />
              </div>
              {currentUser?.walletAddress ? (
                <div className="flex items-center gap-1.5 font-mono">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span className="text-slate-300 font-semibold">{currentUser.walletAddress.slice(0, 6)}...{currentUser.walletAddress.slice(-4)}</span>
                </div>
              ) : (
                <span className="text-amber-300 font-extrabold">{lang === 'es' ? "🦊 Conectar MetaMask" : "🦊 Connect MetaMask"}</span>
              )}
            </button>

            {currentUser && (
              <div className="flex items-center gap-3 bg-slate-50 border border-slate-200/60 px-5 py-2.5 rounded-2xl shadow-sm" id="desktop-balance">
                <Coins className="h-5 w-5 text-emerald-600" />
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t("balance")}:</span>
                <span className="font-mono font-extrabold text-slate-800 text-sm">
                  ${currentUser.balance.toLocaleString()} MXN
                </span>
              </div>
            )}
            <div className="text-xs font-semibold text-slate-400 bg-slate-100 px-3 py-1.5 rounded-full">
              Polygon (Matic) Net
            </div>
          </div>
        </header>

        {/* View Layout Switcher Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8" id="view-body">
          
          {/* VIEW: LANDING PAGE */}
          {currentView === 'LANDING' && (
            <div className="space-y-16 pb-12 animate-fade-in" id="view-landing">
              
              {/* Hero Banner Area */}
              <section className="relative bg-gradient-to-br from-green-950 via-emerald-900 to-slate-950 rounded-3xl overflow-hidden text-white p-8 md:p-14 flex flex-col lg:flex-row items-center gap-10 shadow-2xl border border-emerald-800/40">
                <div className="flex-1 space-y-6 z-10 text-left">
                  <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-bold tracking-wide backdrop-blur-md">
                    <Sparkles className="h-4 w-4 text-emerald-400 animate-spin" />
                    <span>{lang === 'es' ? "Plataforma de Tokenización Agrícola en México" : "Agricultural Tokenization Platform in Mexico"}</span>
                  </div>
                  
                  <h1 className="text-4xl md:text-5xl lg:text-6xl font-black leading-tight text-white tracking-tight">
                    {lang === 'es' ? (
                      <>Inversión Agrícola <span className="text-emerald-400 underline decoration-wavy decoration-2">Transparente</span> y Regenerativa</>
                    ) : (
                      <>Transparent & <span className="text-emerald-400 underline decoration-wavy decoration-2">Regenerative</span> Agricultural Investment</>
                    )}
                  </h1>

                  <p className="text-lg text-emerald-100 max-w-xl leading-relaxed font-medium">
                    {t("landing_desc")}
                  </p>

                  <div className="flex flex-wrap items-center gap-3 pt-2">
                    {!currentUser && (
                      <>
                        <button
                          onClick={() => handleOpenRegister()}
                          className="px-7 py-4 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black rounded-2xl transition-all flex items-center gap-2.5 shadow-xl transform hover:-translate-y-0.5 active:translate-y-0 text-sm border border-emerald-300"
                        >
                          <UserPlus className="w-5 h-5 text-slate-950" />
                          <span>{lang === 'es' ? "🚀 Crear Cuenta / Registrarse" : "🚀 Create Account / Sign Up"}</span>
                        </button>

                        <button
                          onClick={handleGoogleSignIn}
                          className="px-5 py-4 bg-white hover:bg-slate-100 text-slate-900 font-bold rounded-2xl transition-all flex items-center gap-2 shadow-xl transform hover:-translate-y-0.5 active:translate-y-0 text-sm"
                        >
                          <svg className="w-4 h-4" viewBox="0 0 24 24">
                            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                          </svg>
                          <span>{lang === 'es' ? "Google" : "Google"}</span>
                        </button>
                      </>
                    )}

                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => handleDemoLogin('PRODUCER')}
                        className="px-4 py-3.5 bg-white/10 hover:bg-white/20 text-white font-bold rounded-2xl border border-white/20 transition-all text-xs backdrop-blur-sm flex items-center gap-1.5"
                      >
                        <span>🌱 {lang === 'es' ? "Demo Productor" : "Demo Producer"}</span>
                      </button>
                      <button
                        onClick={() => handleDemoLogin('INVESTOR')}
                        className="px-4 py-3.5 bg-white/10 hover:bg-white/20 text-white font-bold rounded-2xl border border-white/20 transition-all text-xs backdrop-blur-sm flex items-center gap-1.5"
                      >
                        <span>💰 {lang === 'es' ? "Demo Inversionista" : "Demo Investor"}</span>
                      </button>
                      <button
                        onClick={() => handleDemoLogin('TRADER')}
                        className="px-4 py-3.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold rounded-2xl border border-amber-400/40 transition-all text-xs backdrop-blur-sm flex items-center gap-1.5"
                      >
                        <span>🛒 {lang === 'es' ? "Demo Comprador" : "Demo Trader"}</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Hero Logo Image Display */}
                <div className="flex-1 relative z-10 w-full flex flex-col items-center justify-center">
                  <div className="relative p-2 rounded-3xl border-2 border-emerald-500/40 shadow-2xl bg-slate-950/80 backdrop-blur-xl flex flex-col items-center text-center max-w-md w-full transform hover:scale-[1.02] transition-all duration-300">
                    <img
                      src="/milpa_tech_logo.svg"
                      alt="Milpa Tech Official Logo"
                      referrerPolicy="no-referrer"
                      className="w-full h-auto max-h-80 object-contain rounded-2xl"
                    />
                  </div>
                </div>

                {/* Background Blobs for Visual Aesthetics */}
                <div className="absolute top-0 right-0 -mt-20 -mr-20 w-96 h-96 bg-emerald-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
                <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-96 h-96 bg-cyan-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
              </section>

              {/* REVOLUTION MANIFEST BANNER CARD */}
              <section className="relative bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 rounded-3xl p-8 md:p-12 border-2 border-emerald-500/50 shadow-2xl text-white overflow-hidden" id="revolution-manifest">
                <div className="absolute -right-10 -bottom-10 opacity-10 pointer-events-none">
                  <MilpaLogo size={320} showText={false} />
                </div>
                
                <div className="relative z-10 max-w-5xl mx-auto space-y-6 text-center">
                  <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-black uppercase tracking-widest">
                    <Shield className="h-4 w-4 text-emerald-400" />
                    <span>{lang === 'es' ? "Manifiesto Oficial Milpa Tech" : "Official Milpa Tech Manifesto"}</span>
                  </div>

                  <h2 className="text-xl sm:text-2xl md:text-3xl font-black tracking-tight text-emerald-200 leading-snug md:leading-relaxed uppercase">
                    "{t("revolution_manifest")}"
                  </h2>

                  <div className="pt-4 flex flex-wrap items-center justify-center gap-6 text-xs text-emerald-300 font-bold border-t border-emerald-800/40">
                    <span className="flex items-center gap-2 bg-emerald-900/40 px-4 py-2 rounded-xl border border-emerald-700/30">
                      <CheckCircle className="h-4 w-4 text-emerald-400" />
                      Soberanía Campesina
                    </span>
                    <span className="flex items-center gap-2 bg-emerald-900/40 px-4 py-2 rounded-xl border border-emerald-700/30">
                      <CheckCircle className="h-4 w-4 text-cyan-400" />
                      Democratización Agrícola
                    </span>
                    <span className="flex items-center gap-2 bg-emerald-900/40 px-4 py-2 rounded-xl border border-emerald-700/30">
                      <CheckCircle className="h-4 w-4 text-emerald-400" />
                      Agricultura Orgánica & Sustentable
                    </span>
                  </div>

                  <div className="pt-4 flex justify-center">
                    <button
                      onClick={() => setCurrentView('ABOUT')}
                      className="px-6 py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black rounded-2xl transition-all flex items-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95 text-sm"
                    >
                      <BookOpen className="w-4 h-4 text-slate-900" />
                      <span>{lang === 'es' ? "📖 Conoce Todo Sobre Nosotros (Presentación & Documento Completo)" : "📖 Learn All About Us (Pitch Deck & Full Document)"}</span>
                      <ArrowUpRight className="w-4 h-4 text-slate-900" />
                    </button>
                  </div>
                </div>
              </section>

              {/* Major Value Proposition Capabilities Card Grid */}
              <section className="grid grid-cols-1 md:grid-cols-3 gap-8" id="capabilities">
                {/* Cap 1: Tokenization */}
                <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-150 hover:shadow-lg hover:border-emerald-200 transition-all text-left">
                  <div className="w-14 h-14 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600 mb-6 border border-emerald-100">
                    <Coins className="h-7 w-7" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-3">{t("feature_token_title")}</h3>
                  <p className="text-slate-600 leading-relaxed text-sm">
                    {t("feature_token_desc")}
                  </p>
                </div>
                {/* Cap 2: Risk Management */}
                <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-150 hover:shadow-lg hover:border-emerald-200 transition-all text-left">
                  <div className="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 mb-6 border border-blue-100">
                    <Shield className="h-7 w-7" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-3">{t("feature_ai_title")}</h3>
                  <p className="text-slate-600 leading-relaxed text-sm">
                    {t("feature_ai_desc")}
                  </p>
                </div>
                {/* Cap 3: Sustainable Agriculture */}
                <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-150 hover:shadow-lg hover:border-emerald-200 transition-all text-left">
                  <div className="w-14 h-14 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-600 mb-6 border border-amber-100">
                    <Sprout className="h-7 w-7" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-3">{t("feature_regen_title")}</h3>
                  <p className="text-slate-600 leading-relaxed text-sm">
                    {t("feature_regen_desc")}
                  </p>
                </div>
              </section>

              {/* Dynamic Stats Grid Section */}
              <section className="bg-slate-900 text-white rounded-3xl p-12 text-center relative overflow-hidden shadow-xl" id="stats">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(16,185,129,0.1),transparent_50%)]"></div>
                <h2 className="text-2xl md:text-3xl font-black mb-12 tracking-tight">{t("impact_title")}</h2>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
                  <div>
                    <p className="text-4xl md:text-5xl font-extrabold text-green-400 mb-2">+2,500</p>
                    <p className="text-slate-400 text-xs uppercase font-bold tracking-wider">{t("impact_hectares")}</p>
                  </div>
                  <div>
                    <p className="text-4xl md:text-5xl font-extrabold text-green-400 mb-2">$5M</p>
                    <p className="text-slate-400 text-xs uppercase font-bold tracking-wider">{t("impact_investment")}</p>
                  </div>
                  <div>
                    <p className="text-4xl md:text-5xl font-extrabold text-green-400 mb-2">150+</p>
                    <p className="text-slate-400 text-xs uppercase font-bold tracking-wider">{t("impact_producers")}</p>
                  </div>
                  <div>
                    <p className="text-4xl md:text-5xl font-extrabold text-green-400 mb-2">100%</p>
                    <p className="text-slate-400 text-xs uppercase font-bold tracking-wider">{t("impact_blockchain")}</p>
                  </div>
                </div>
              </section>
            </div>
          )}

          {/* VIEW: ONBOARDING / REGISTER KYC */}
          {isRegistering && (
            <div className="max-w-4xl mx-auto bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-200 my-8 animate-fade-in" id="view-onboarding">
              <div className="bg-slate-900 text-white p-6 flex items-center justify-between">
                <div className="flex items-center gap-4 text-left">
                  <button onClick={() => setIsRegistering(false)} className="hover:bg-slate-800 p-2 rounded-full transition-colors">
                    <ArrowLeft className="h-5 w-5" />
                  </button>
                  <div>
                    <h2 className="text-xl md:text-2xl font-black tracking-tight">{t("onboarding_title")}</h2>
                    <p className="text-slate-400 text-xs font-semibold">{t("onboarding_subtitle")}</p>
                  </div>
                </div>
                <button onClick={() => setIsRegistering(false)} className="text-slate-400 hover:text-white">
                  <X className="h-6 w-6" />
                </button>
              </div>

              {/* Interactive Onboarding Form */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const form = e.target as HTMLFormElement;
                  const nameInput = form.elements.namedItem('name') as HTMLInputElement;
                  const roleSelected = form.elements.namedItem('role') as HTMLInputElement;
                  const signatureInput = form.elements.namedItem('digitalSignature') as HTMLInputElement;

                  const role = (roleSelected?.value || 'PRODUCER') as 'PRODUCER' | 'INVESTOR' | 'TRADER';
                  const assignedAddress = onboardingWalletAddress || ("0x" + Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join(""));
                  const user: UserProfile = {
                    id: `user-${Date.now()}`,
                    name: nameInput.value.trim(),
                    role: role,
                    balance: role === 'INVESTOR' ? 35000 : role === 'TRADER' ? 25000 : 10000,
                    avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(nameInput.value)}&background=047857&color=fff`,
                    walletAddress: assignedAddress,
                    tradingVolume: role === 'TRADER' ? 50000 : undefined
                  };

                  saveUser(user);
                  // Persist immediately in Firestore users collection
                  setDoc(doc(db, 'users', user.id), sanitizeForFirestore(user)).catch((err) => {
                    console.warn("Firestore user sync notice:", err);
                  });

                  setIsRegistering(false);
                  setCurrentView(role === 'PRODUCER' ? 'DASHBOARD' : 'MARKETPLACE');
                  showToast(lang === 'es' ? `¡Bienvenido a Milpa Tech, ${user.name}! Perfil registrado exitosamente.` : `Welcome to Milpa Tech, ${user.name}! Profile registered successfully.`);
                }}
                className="p-8 space-y-10 text-left"
              >
                {/* Step 1: Role Selection */}
                <section className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                  <h3 className="text-lg font-bold text-slate-800 mb-4">{t("sec1_title")}</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <label className="flex items-start gap-3 p-4 rounded-xl border-2 bg-white cursor-pointer hover:border-emerald-500 transition-all">
                      <input type="radio" name="role" value="PRODUCER" defaultChecked className="mt-1 w-5 h-5 text-emerald-600 focus:ring-emerald-500" />
                      <div>
                        <span className="font-extrabold block text-slate-800 text-sm">🌱 {t("sec1_producer")}</span>
                        <span className="text-xs text-slate-500">{t("sec1_producer_desc")}</span>
                      </div>
                    </label>
                    <label className="flex items-start gap-3 p-4 rounded-xl border-2 bg-white cursor-pointer hover:border-blue-500 transition-all">
                      <input type="radio" name="role" value="INVESTOR" className="mt-1 w-5 h-5 text-blue-600 focus:ring-blue-500" />
                      <div>
                        <span className="font-extrabold block text-slate-800 text-sm">💰 {t("sec1_investor")}</span>
                        <span className="text-xs text-slate-500">{t("sec1_investor_desc")}</span>
                      </div>
                    </label>
                    <label className="flex items-start gap-3 p-4 rounded-xl border-2 bg-white cursor-pointer hover:border-amber-500 transition-all">
                      <input type="radio" name="role" value="TRADER" className="mt-1 w-5 h-5 text-amber-600 focus:ring-amber-500" />
                      <div>
                        <span className="font-extrabold block text-slate-800 text-sm">🛒 {lang === 'es' ? "Comprador / Vendedor" : "Trader / Buyer"}</span>
                        <span className="text-xs text-slate-500">{lang === 'es' ? "Comercializa cosechas e intercambia tokens en Marketplace" : "Trade harvests and tokens directly on Marketplace"}</span>
                      </div>
                    </label>
                  </div>
                </section>

                {/* Step 2: Personal Information */}
                <section className="space-y-6">
                  <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2 border-b pb-2">
                    <User className="h-5 w-5 text-slate-600" />
                    <span>{t("sec2_title")}</span>
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="md:col-span-2">
                      <label className="block text-sm font-bold text-slate-700 mb-1">{t("field_fullname")}</label>
                      <input required name="name" type="text" className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="Ej. Agrícola Los Volcanes S.A." />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-1">{t("field_taxid")}</label>
                      <input required name="taxId" type="text" className="w-full px-4 py-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" placeholder="e.g. RFC / EIN" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-1">{t("field_dob")}</label>
                      <input required name="dob" type="date" className="w-full px-4 py-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-bold text-slate-700 mb-1">{t("field_address")}</label>
                      <input required name="address" type="text" className="w-full px-4 py-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" placeholder="123 Farm Road, Oaxaca, Mexico" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-1">{t("field_email")}</label>
                      <input required name="email" type="email" className="w-full px-4 py-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" placeholder="contacto@ejemplo.com" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-1">{t("field_phone")}</label>
                      <input required name="phone" type="tel" className="w-full px-4 py-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" placeholder="+52 (55) 1234-5678" />
                    </div>
                  </div>
                </section>

                {/* Step 3: Blockchain Digital Wallet */}
                <section className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                  <label className="block text-sm font-bold text-slate-700 mb-2">{t("field_wallet")}</label>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <input
                      name="walletAddress"
                      type="text"
                      readOnly
                      className="flex-1 px-4 py-3 bg-white border border-slate-300 rounded-xl text-xs font-mono text-slate-700"
                      value={onboardingWalletAddress ? onboardingWalletAddress : (lang === 'es' ? "🦊 MetaMask o Polygon Web3 (Opcional - Se auto-generará si no conectas)" : "🦊 MetaMask or Polygon Web3 (Optional - Auto-generated if omitted)")}
                    />
                    <button
                      type="button"
                      onClick={() => setIsWalletModalOpen(true)}
                      className="px-5 py-3 bg-slate-900 hover:bg-slate-800 text-amber-300 rounded-xl text-xs font-bold shrink-0 flex items-center justify-center gap-2 border border-slate-700 transition-all shadow-sm active:scale-95"
                    >
                      <Wallet className="w-4 h-4" />
                      <span>{onboardingWalletAddress ? (lang === 'es' ? "Billetera Vinculada ✓" : "Wallet Linked ✓") : (lang === 'es' ? "🦊 Conectar MetaMask" : "🦊 Connect MetaMask")}</span>
                    </button>
                  </div>
                </section>

                {/* Step 4: Compliance Consents & Electronic Digital Signature */}
                <section className="space-y-6">
                  <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2 border-b pb-2">
                    <FileText className="h-5 w-5 text-slate-600" />
                    <span>{t("sec5_title")}</span>
                  </h3>
                  <div className="space-y-3 bg-slate-50 p-6 rounded-2xl border border-slate-200">
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input required type="checkbox" className="mt-1 h-5 w-5 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500" />
                      <span className="text-sm text-slate-700 font-medium">{t("consent_kyc")}</span>
                    </label>
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input required type="checkbox" className="mt-1 h-5 w-5 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500" />
                      <span className="text-sm text-slate-700 font-medium">{t("consent_storage")}</span>
                    </label>
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input required type="checkbox" className="mt-1 h-5 w-5 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500" />
                      <span className="text-sm text-slate-700 font-medium">{t("consent_terms")}</span>
                    </label>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-1">{t("field_signature")}</label>
                      <div className="relative">
                        <input required name="digitalSignature" type="text" className="w-full pl-10 pr-4 py-3 border-b-2 border-slate-300 bg-transparent focus:border-emerald-600 outline-none font-serif italic text-lg" placeholder={t("signature_placeholder")} />
                        <PenTool className="absolute left-2 top-3.5 h-5 w-5 text-slate-400" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-1">{t("field_date")}</label>
                      <input type="text" disabled className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-500 text-sm font-semibold cursor-not-allowed" value={new Date().toLocaleDateString()} />
                    </div>
                  </div>
                </section>

                {/* Actions Panel */}
                <div className="flex gap-4 pt-4">
                  <button type="button" onClick={() => setIsRegistering(false)} className="flex-1 py-4 border border-slate-300 text-slate-700 font-bold rounded-xl hover:bg-slate-50 transition-colors">
                    {t("btn_cancel")}
                  </button>
                  <button type="submit" className="flex-1 py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition-all shadow-lg shadow-emerald-600/20">
                    {t("btn_submit_req")}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* VIEW: REGISTERED USERS DIRECTORY & VERIFIED SELLERS */}
          {currentView === 'COMMUNITY' && !isRegistering && (
            <CommunityDirectoryView
              users={users}
              crops={crops}
              marketplaceItems={marketplaceItems}
              reviews={reviews}
              currentUser={currentUser}
              lang={lang}
              onOpenDirectChat={(target) => {
                setDirectChatTargetUser(target);
                setIsDirectChatModalOpen(true);
              }}
              onOpenUserProfile={(user) => {
                setSelectedProfileUser(user);
                setIsProfileModalOpen(true);
              }}
              onOpenSellerRegistration={() => {
                setIsSellerModalOpen(true);
              }}
              onOpenMarketplaceItem={(item) => {
                setSelectedMarketplaceItem(item);
                setIsMarketplaceItemModalOpen(true);
              }}
              onInvestInProducer={(crop) => {
                setSelectedCropToBuy(crop);
                setBuyAmount(1);
                setIsBuyModalOpen(true);
              }}
              onCreateMarketplaceItem={handleCreateMarketplaceItem}
              onLoginRequired={(role) => {
                handleOpenRegister(role || 'TRADER');
              }}
            />
          )}

          {/* VIEW: CROPS MARKETPLACE */}
          {currentView === 'MARKETPLACE' && !isRegistering && (
            <div className="space-y-8 animate-fade-in" id="view-marketplace">
              {/* Category Filters */}
              <div className="flex flex-wrap gap-2 pb-2" id="marketplace-filters">
                {[
                  { id: "all", key: "filter_all" },
                  { id: "granos", key: "filter_grains" },
                  { id: "cafe", key: "filter_coffee" },
                  { id: "frutales", key: "filter_fruits" },
                  { id: "agave", key: "filter_agave" },
                  { id: "hortalizas", key: "filter_vegetables" }
                ].map((filter, index) => {
                  const isFirst = index === 0;
                  return (
                    <button
                      key={filter.id}
                      className={`px-5 py-2 text-xs font-bold rounded-full border transition-all ${
                        isFirst
                          ? "bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-600/10"
                          : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                      }`}
                    >
                      {t(filter.key)}
                    </button>
                  );
                })}
              </div>

              {/* Crops Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="crops-grid">
                {crops.map(crop => {
                  const progress = (crop.soldTokens / crop.totalTokens) * 100;
                  return (
                    <div key={crop.id} className="bg-white rounded-3xl shadow-sm border border-slate-200/80 overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col text-left">
                      {/* Image Area */}
                      <div className="relative h-52 group">
                        <img src={crop.imageUrl} alt={crop.name} className="w-full h-full object-cover" />
                        <div className="absolute top-4 left-4 bg-slate-900/90 text-sky-300 backdrop-blur-md px-3 py-1.5 rounded-full text-[10px] font-black flex items-center gap-1.5 border border-sky-500/30 shadow-md">
                          <Layers className="h-3 w-3 text-sky-400" />
                          <span>NFT OpenSea</span>
                        </div>
                        <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-full text-[10px] font-black text-emerald-800 flex items-center gap-1 shadow-sm">
                          <CheckCircle className="h-3 w-3 text-emerald-600" />
                          <span>{t("score")}: {crop.sustainabilityScore}/100</span>
                        </div>
                        {currentUser?.role === 'PRODUCER' && (
                          <button
                            type="button"
                            onClick={() => setCropToEditImage(crop)}
                            className="absolute bottom-3 right-3 px-2.5 py-1.5 bg-slate-900/80 hover:bg-slate-900 text-emerald-300 rounded-xl text-[11px] font-bold border border-emerald-500/40 backdrop-blur-sm shadow-md flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity"
                            title={lang === 'es' ? "Cambiar foto del cultivo" : "Change crop photo"}
                          >
                            <Camera className="w-3.5 h-3.5 text-emerald-400" />
                            <span>{lang === 'es' ? "Foto" : "Photo"}</span>
                          </button>
                        )}
                      </div>

                      {/* Content Details */}
                      <div className="p-6 flex-1 flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-start mb-3">
                            <div>
                              <h3 className="text-lg font-black text-slate-800 tracking-tight leading-snug">{crop.name}</h3>
                              <button
                                onClick={() => handleOpenUserProfile(crop.producerName)}
                                className="text-xs text-emerald-700 hover:text-emerald-600 font-bold mt-0.5 flex items-center gap-1 group hover:underline text-left"
                              >
                                <span>{crop.producerName}</span>
                                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 group-hover:scale-110 transition-transform shrink-0" />
                              </button>
                            </div>
                            <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold tracking-wide border uppercase ${
                              crop.riskLevel === 'BAJO' || crop.riskLevel === 'LOW'
                                ? 'bg-green-50 text-green-700 border-green-200'
                                : crop.riskLevel === 'MEDIO' || crop.riskLevel === 'MEDIUM'
                                ? 'bg-amber-50 text-amber-700 border-amber-200'
                                : 'bg-red-50 text-red-700 border-red-200'
                            }`}>
                              {t("risk")}: {t(`risk_${crop.riskLevel.toLowerCase() as 'low' | 'medium' | 'high'}`)}
                            </span>
                          </div>

                          <p className="text-slate-600 text-xs leading-relaxed mb-4 line-clamp-3">
                            {crop.description}
                          </p>

                          {/* OpenSea NFT Direct Link Area */}
                          <div className="bg-gradient-to-r from-sky-50 to-blue-50/80 p-3.5 rounded-2xl border border-sky-200/80 mb-5 flex items-center justify-between">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div className="w-8 h-8 rounded-xl bg-sky-500/10 flex items-center justify-center text-sky-600 shrink-0 border border-sky-200">
                                <Layers className="h-4 w-4" />
                              </div>
                              <div className="min-w-0">
                                <span className="block text-[10px] font-black uppercase text-sky-900 tracking-wider flex items-center gap-1">
                                  NFT OpenSea
                                  <span className="w-1.5 h-1.5 bg-sky-500 rounded-full animate-ping"></span>
                                </span>
                                <span className="block text-[11px] font-mono font-bold text-slate-600 truncate">
                                  {crop.nftTokenId ? `Token ID: ${crop.nftTokenId}` : "ERC-721 Token"}
                                </span>
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                onClick={() => setSelectedNftCrop(crop)}
                                className="p-2 bg-white hover:bg-sky-100 text-sky-700 rounded-xl text-xs font-bold border border-sky-200 transition-colors shadow-sm"
                                title={t("nft_modal_title")}
                              >
                                <FileText className="h-3.5 w-3.5" />
                              </button>
                              <button
                                onClick={() => setEditingNftCrop(crop)}
                                className="p-2 bg-white hover:bg-sky-100 text-sky-700 rounded-xl text-xs font-bold border border-sky-200 transition-colors shadow-sm"
                                title={t("nft_edit_btn")}
                              >
                                <PenTool className="h-3.5 w-3.5" />
                              </button>
                              <a
                                href={crop.openseaUrl || `https://opensea.io/assets/matic/0x2953399124f0cbb46d2cbacd8a89cf0599974963/${crop.id}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="px-3 py-1.5 bg-[#2081E2] hover:bg-[#1868b7] text-white rounded-xl text-xs font-black flex items-center gap-1 transition-all shadow-sm shadow-blue-500/20"
                              >
                                <span>OpenSea</span>
                                <ExternalLink className="h-3 w-3" />
                              </a>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-4 mb-6">
                            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
                              <span className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider">{t("est_return")}</span>
                              <span className="font-extrabold text-emerald-600 text-sm flex items-center gap-0.5 mt-0.5">
                                <ArrowUpRight className="h-4 w-4" />
                                {crop.yieldProjection}%
                              </span>
                            </div>
                            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
                              <span className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider">{t("harvest")}</span>
                              <span className="font-bold text-slate-700 text-xs mt-1 block">
                                {crop.harvestDate}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Buying Price & Progress */}
                        <div>
                          <div className="flex justify-between items-baseline mb-2">
                            <div>
                              <span className="text-2xl font-black text-slate-900">${crop.tokenPrice}</span>
                              <span className="text-slate-400 text-xs font-semibold ml-1">MXN / token</span>
                            </div>
                            <span className="text-xs text-slate-500 font-semibold">
                              {(crop.totalTokens - crop.soldTokens).toLocaleString()} {t("available")}
                            </span>
                          </div>

                          {/* Progress Line */}
                          <div className="w-full bg-slate-100 rounded-full h-2 mb-6 overflow-hidden border border-slate-200/40">
                            <div className="bg-emerald-500 h-full rounded-full transition-all duration-500" style={{ width: `${progress}%` }}></div>
                          </div>

                          {/* Invest Trigger Button */}
                          {currentUser ? (
                            currentUser.role === 'PRODUCER' ? (
                              <button disabled className="w-full py-3.5 bg-slate-100 text-slate-400 rounded-xl text-xs font-black uppercase tracking-wider cursor-not-allowed border border-slate-200">
                                {t("btn_producer_view")}
                              </button>
                            ) : (
                              <button
                                onClick={() => triggerBuy(crop)}
                                className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 shadow-md shadow-emerald-600/10"
                              >
                                {t("btn_invest_now")}
                              </button>
                            )
                          ) : (
                            <button
                              onClick={() => { handleDemoLogin('INVESTOR'); }}
                              className="w-full py-3.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200"
                            >
                              {t("btn_login_invest")}
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* VIEW: TRANSACTION LEDGER */}
          {currentView === 'LEDGER' && !isRegistering && (
            <div className="animate-fade-in space-y-6" id="view-ledger">
              <TransactionLedger
                transactions={transactions}
                lang={lang}
                onSimulateTransaction={handleSimulateTransaction}
              />
            </div>
          )}

          {/* VIEW: CONTROL PANEL (DASHBOARD) */}
          {currentView === 'DASHBOARD' && !isRegistering && currentUser && (
            <div className="space-y-8 animate-fade-in" id="view-dashboard">
              
              {/* ROLE: PRODUCER PANEL */}
              {currentUser.role === 'PRODUCER' ? (
                <>
                  {/* Title Bar Action */}
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-left">
                    <div>
                      <h3 className="text-xl font-bold text-slate-800">{t("producer_title")}</h3>
                      <p className="text-xs text-slate-400 font-semibold">Real-time agricultural monitoring and crop funding</p>
                    </div>
                    <button
                      onClick={() => setIsAddCropModalOpen(true)}
                      className="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center gap-2 text-sm shadow-md transition-colors"
                    >
                      <Plus className="h-5 w-5" />
                      <span>{t("btn_load_crop")}</span>
                    </button>
                  </div>

                  {/* Metrics Cards Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6" id="producer-metrics">
                    {/* Metric 1 */}
                    <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-4 text-left">
                      <div className="p-4 bg-blue-50 text-blue-600 rounded-2xl">
                        <Thermometer className="h-6 w-6" />
                      </div>
                      <div>
                        <span className="block text-xs text-slate-400 font-bold uppercase tracking-wider">{t("metrics_temp")}</span>
                        <span className="text-2xl font-black text-slate-800">24.5 °C</span>
                        <span className="block text-[10px] text-slate-500 mt-0.5">{t("metrics_temp_sub")}</span>
                      </div>
                    </div>
                    {/* Metric 2 */}
                    <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-4 text-left">
                      <div className="p-4 bg-emerald-50 text-emerald-600 rounded-2xl">
                        <Sprout className="h-6 w-6" />
                      </div>
                      <div>
                        <span className="block text-xs text-slate-400 font-bold uppercase tracking-wider">{t("metrics_moisture")}</span>
                        <span className="text-2xl font-black text-slate-800">42 %</span>
                        <span className="block text-[10px] text-emerald-600 font-bold mt-0.5">{t("metrics_moisture_sub")}</span>
                      </div>
                    </div>
                    {/* Metric 3 */}
                    <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-4 text-left">
                      <div className="p-4 bg-red-50 text-red-600 rounded-2xl">
                        <HeartPulse className="h-6 w-6" />
                      </div>
                      <div>
                        <span className="block text-xs text-slate-400 font-bold uppercase tracking-wider">{t("metrics_health")}</span>
                        <span className="text-2xl font-black text-slate-800">98 / 100</span>
                        <span className="block text-[10px] text-emerald-600 font-bold mt-0.5">{t("metrics_health_sub")}</span>
                      </div>
                    </div>
                  </div>

                  {/* Recharts IoT Graph */}
                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm text-left">
                    <h3 className="text-lg font-black text-slate-800 mb-6 tracking-tight">{t("iot_sensors_title")}</h3>
                    <div className="h-80 w-full" id="iot-chart-container">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={sensorData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                          <defs>
                            <linearGradient id="moistureGradient" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="tempGradient" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis dataKey="time" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                          <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} />
                          <Tooltip />
                          <Legend wrapperStyle={{ fontSize: 12, fontWeight: 'bold' }} />
                          <Area type="monotone" dataKey="soilMoisture" stroke="#10b981" fillOpacity={1} fill="url(#moistureGradient)" name={lang === 'es' ? "Humedad de Suelo (%)" : "Soil Moisture (%)"} strokeWidth={3} />
                          <Area type="monotone" dataKey="temperature" stroke="#f59e0b" fillOpacity={1} fill="url(#tempGradient)" name={lang === 'es' ? "Temperatura (°C)" : "Temperature (°C)"} strokeWidth={2} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Producer Crops List */}
                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm text-left">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                      <div>
                        <h3 className="text-lg font-black text-slate-800 tracking-tight">{t("active_crops_title")}</h3>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {lang === 'es' ? "Gestiona tus cosechas tokenizadas y personaliza las fotografías de cada cultivo." : "Manage tokenized crops and customize live crop photographs."}
                        </p>
                      </div>
                      <button
                        onClick={() => setIsAddCropModalOpen(true)}
                        className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black shadow-md shadow-emerald-900/10 transition-all self-start sm:self-auto"
                      >
                        <Plus className="w-4 h-4" />
                        <span>{lang === 'es' ? "Cargar Nuevo Cultivo" : "Add New Crop"}</span>
                      </button>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-slate-200 text-slate-400 text-xs font-bold uppercase tracking-wider">
                            <th className="pb-3">{t("tbl_name")}</th>
                            <th className="pb-3">{t("nft_badge")}</th>
                            <th className="pb-3">{t("tbl_sold_tokens")}</th>
                            <th className="pb-3">{t("tbl_progress")}</th>
                            <th className="pb-3">{t("tbl_status")}</th>
                            <th className="pb-3 text-right">{lang === 'es' ? "Fotografía / Acción" : "Image / Action"}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-sm">
                          {crops.filter(c => c.producerName.includes("San Miguel") || c.producerName.includes(currentUser.name)).map(c => {
                            const progress = Math.round((c.soldTokens / c.totalTokens) * 100);
                            return (
                              <tr key={c.id} className="hover:bg-slate-50/70 transition-colors">
                                <td className="py-4 font-bold text-slate-800 flex items-center gap-3">
                                  <div
                                    onClick={() => setCropToEditImage(c)}
                                    className="relative group cursor-pointer shrink-0"
                                    title={lang === 'es' ? "Clic para cambiar la foto del cultivo" : "Click to change crop image"}
                                  >
                                    <img
                                      src={c.imageUrl}
                                      className="w-12 h-12 rounded-xl object-cover border border-slate-200 shadow-sm group-hover:opacity-85 transition-opacity"
                                      alt={c.name}
                                    />
                                    <div className="absolute inset-0 bg-black/50 rounded-xl opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity">
                                      <Camera className="w-4 h-4 text-emerald-400" />
                                    </div>
                                  </div>
                                  <div>
                                    <span className="block font-black text-slate-800">{c.name}</span>
                                    <span className="text-xs text-slate-400 font-normal">{c.location}</span>
                                  </div>
                                </td>
                                <td className="py-4">
                                  <a
                                    href={c.openseaUrl || `https://opensea.io/assets/matic/0x2953399124f0cbb46d2cbacd8a89cf0599974963/${c.id}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center gap-1 px-2.5 py-1 bg-sky-50 hover:bg-sky-100 text-[#2081E2] rounded-lg text-xs font-bold border border-sky-200 transition-colors"
                                  >
                                    <span>OpenSea</span>
                                    <ExternalLink className="h-3 w-3" />
                                  </a>
                                </td>
                                <td className="py-4 font-mono font-bold text-slate-600">
                                  {c.soldTokens.toLocaleString()} / {c.totalTokens.toLocaleString()}
                                </td>
                                <td className="py-4">
                                  <div className="flex items-center gap-3">
                                    <div className="w-32 bg-slate-100 rounded-full h-2 overflow-hidden border">
                                      <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${progress}%` }}></div>
                                    </div>
                                    <span className="font-mono font-black text-emerald-600">{progress}%</span>
                                  </div>
                                </td>
                                <td className="py-4">
                                  <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 px-2.5 py-1 rounded-full text-xs font-bold">
                                    {t("tbl_growing")}
                                  </span>
                                </td>
                                <td className="py-4 text-right">
                                  <button
                                    onClick={() => setCropToEditImage(c)}
                                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 hover:text-emerald-950 rounded-xl text-xs font-black border border-emerald-200/80 transition-all shadow-sm active:scale-95"
                                  >
                                    <Camera className="w-3.5 h-3.5 text-emerald-600" />
                                    <span>{lang === 'es' ? "Cambiar Imagen" : "Edit Image"}</span>
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              ) : (
                
                /* ROLE: INVESTOR PANEL */
                <>
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8" id="investor-dashboard-grid">
                    
                    {/* Portfolio Asset Value Block */}
                    <div className="bg-gradient-to-br from-green-900 to-emerald-950 text-white p-8 rounded-3xl shadow-xl relative overflow-hidden flex flex-col justify-between text-left col-span-1 lg:col-span-1">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-800 rounded-full transform translate-x-10 -translate-y-10 opacity-30"></div>
                      <div>
                        <h4 className="text-green-300 text-xs font-extrabold uppercase tracking-wider mb-2">{t("total_assets")}</h4>
                        <p className="text-4xl font-black text-white tracking-tight">$34,250.00 MXN</p>
                      </div>
                      <div className="grid grid-cols-2 gap-4 mt-8 pt-6 border-t border-green-800">
                        <div>
                          <p className="text-[10px] text-green-300 font-bold uppercase tracking-wider">{t("accum_return")}</p>
                          <p className="text-xl font-black text-green-400 mt-1 flex items-center gap-0.5">
                            <ArrowUpRight className="h-5 w-5" />
                            +12.5%
                          </p>
                        </div>
                        <div>
                          <p className="text-[10px] text-green-300 font-bold uppercase tracking-wider">{t("total_tokens")}</p>
                          <p className="text-xl font-black text-white mt-1">450</p>
                        </div>
                      </div>
                    </div>

                    {/* Portfolio Chart Block */}
                    <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm text-left col-span-1 lg:col-span-2">
                      <h3 className="text-md font-bold text-slate-800 mb-4">{t("portfolio_dist")}</h3>
                      <div className="h-60 w-full" id="portfolio-chart-container">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={crops.slice(0, 4)} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                            <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#94a3b8' }} />
                            <YAxis tick={{ fontSize: 10, fill: '#94a3b8' }} />
                            <Tooltip />
                            <Bar dataKey="yieldProjection" fill="#10b981" radius={[8, 8, 0, 0]} name={lang === 'es' ? "Rendimiento Proyectado (%)" : "Projected Yield (%)"} />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>

                  {/* Active Investments Grid */}
                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm text-left">
                    <h3 className="text-lg font-black text-slate-800 mb-6 tracking-tight">{t("my_investments_title")}</h3>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-slate-200 text-slate-400 text-xs font-bold uppercase tracking-wider">
                            <th className="pb-3">{t("tbl_crop")}</th>
                            <th className="pb-3">{t("nft_badge")}</th>
                            <th className="pb-3">{t("tbl_qty")}</th>
                            <th className="pb-3">{t("tbl_entry_price")}</th>
                            <th className="pb-3">{t("tbl_current_val")}</th>
                            <th className="pb-3">{t("tbl_status")}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-sm">
                          {/* Dynamically simulated bought tokens if they purchased any */}
                          {transactions.filter(tx => tx.type === 'BUY').map(tx => {
                            const matchingCrop = crops.find(c => c.name === tx.cropName);
                            const nftLink = matchingCrop?.openseaUrl || `https://opensea.io/assets/matic/0x2953399124f0cbb46d2cbacd8a89cf0599974963/101`;
                            return (
                              <tr key={tx.id}>
                                <td className="py-4 font-bold text-slate-800 flex items-center gap-3">
                                  <span className="p-2 bg-emerald-50 rounded-xl text-emerald-600">
                                    <Sprout className="h-5 w-5" />
                                  </span>
                                  <span>{tx.cropName}</span>
                                </td>
                                <td className="py-4">
                                  <a
                                    href={nftLink}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center gap-1 px-2.5 py-1 bg-sky-50 hover:bg-sky-100 text-[#2081E2] rounded-lg text-xs font-bold border border-sky-200 transition-colors"
                                  >
                                    <span>OpenSea</span>
                                    <ExternalLink className="h-3 w-3" />
                                  </a>
                                </td>
                                <td className="py-4 font-mono font-bold text-slate-600">{tx.amount}</td>
                                <td className="py-4 font-mono text-slate-400">${tx.price} MXN</td>
                                <td className="py-4 font-mono font-extrabold text-emerald-600">${(tx.amount * tx.price * 1.05).toFixed(2)} MXN</td>
                                <td className="py-4">
                                  <span className="bg-green-50 text-green-700 px-2 py-0.5 rounded-full text-xs font-bold border border-green-200">
                                    {lang === 'es' ? "Confirmado" : "Confirmed"}
                                  </span>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {/* VIEW: ARTIFICIAL INTELLIGENCE & SATELLITE ANALYSIS */}
          {currentView === 'AI_RISK' && !isRegistering && currentUser && (
            <div className="space-y-8 animate-fade-in" id="view-ai-risk">
              {/* Top Banner Satellite card */}
              <div className="bg-slate-900 text-white p-8 rounded-3xl flex flex-col lg:flex-row gap-8 items-center text-left shadow-xl relative overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(59,130,246,0.1),transparent_50%)]"></div>
                <div className="flex-1 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-blue-500/10 text-blue-400 rounded-2xl border border-blue-500/20">
                      <Brain className="h-8 w-8 animate-pulse" />
                    </div>
                    <h2 className="text-2xl font-black tracking-tight">{t("ai_satellite_title")}</h2>
                  </div>
                  <p className="text-slate-300 text-sm leading-relaxed max-w-2xl">
                    {t("ai_satellite_desc")}
                  </p>
                  <div className="flex gap-4 pt-2">
                    <div className="bg-slate-800 px-4 py-2 rounded-xl border border-slate-700/60 shadow-inner">
                      <span className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider">{t("ai_last_scan")}</span>
                      <span className="font-mono text-sm font-bold">{t("ai_last_scan_val")}</span>
                    </div>
                    <div className="bg-slate-800 px-4 py-2 rounded-xl border border-slate-700/60 shadow-inner">
                      <span className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider">{t("ai_coverage")}</span>
                      <span className="font-mono text-sm font-bold text-green-400">{t("ai_coverage_val")}</span>
                    </div>
                  </div>
                </div>

                <div className="w-full lg:w-1/3 aspect-[4/3] bg-slate-800 rounded-2xl overflow-hidden relative border border-slate-700 shadow-2xl shrink-0">
                  <div className="absolute inset-0 bg-gradient-to-tr from-green-950 via-emerald-800/80 to-teal-900/60 opacity-90"></div>
                  <div className="absolute top-4 left-4 bg-slate-900/80 backdrop-blur px-2.5 py-1 rounded-lg text-[10px] text-green-400 font-mono border border-green-500/20 shadow-sm">
                    NDVI Score: 0.85 (Optimal)
                  </div>
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-4">
                    <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center border border-blue-500/40 animate-ping absolute"></div>
                    <Shield className="h-10 w-10 text-blue-400 z-10" />
                    <span className="text-slate-200 text-xs font-bold tracking-widest uppercase mt-3 z-10">{t("ai_visualization")}</span>
                  </div>
                </div>
              </div>

              {/* Climate Charts and detected Risk Matrix */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Weather Forecast Recharts Chart */}
                <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm text-left">
                  <h3 className="text-lg font-black text-slate-800 mb-6 tracking-tight">{t("ai_climate_title")}</h3>
                  <div className="h-64 w-full" id="climate-chart-container">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={[
                        { month: "Nov", rainChance: 30, moisture: 45 },
                        { month: "Dic", rainChance: 20, moisture: 40 },
                        { month: "Ene", rainChance: 15, moisture: 35 },
                        { month: "Feb", rainChance: 45, moisture: 50 },
                        { month: "Mar", rainChance: 60, moisture: 65 },
                        { month: "Abr", rainChance: 80, moisture: 75 }
                      ]} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                        <defs>
                          <linearGradient id="rainGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                        <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} />
                        <Tooltip />
                        <Legend wrapperStyle={{ fontSize: 11, fontWeight: 'bold' }} />
                        <Area type="monotone" dataKey="rainChance" stroke="#3b82f6" fillOpacity={1} fill="url(#rainGradient)" name={lang === 'es' ? "Probabilidad Lluvia %" : "Rain Probability %"} strokeWidth={3} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Risk Matrix Table list */}
                <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm text-left flex flex-col justify-between">
                  <div>
                    <h3 className="text-lg font-black text-slate-800 mb-6 tracking-tight">{t("ai_risk_matrix")}</h3>
                    <div className="space-y-4">
                      {/* Risk item 1 */}
                      <div className="flex items-center justify-between p-4 bg-green-50 border border-green-100 rounded-2xl">
                        <div className="flex items-center gap-3">
                          <Check className="h-5 w-5 text-green-600" />
                          <span className="font-bold text-slate-700 text-sm">{t("risk_drought")}</span>
                        </div>
                        <span className="px-3 py-1 bg-green-100 text-green-800 border border-green-200 rounded-full text-xs font-bold uppercase">
                          {lang === 'es' ? 'BAJO (12%)' : 'LOW (12%)'}
                        </span>
                      </div>
                      {/* Risk item 2 */}
                      <div className="flex items-center justify-between p-4 bg-amber-50 border border-amber-100 rounded-2xl">
                        <div className="flex items-center gap-3">
                          <AlertTriangle className="h-5 w-5 text-amber-600" />
                          <span className="font-bold text-slate-700 text-sm">{t("risk_volatility")}</span>
                        </div>
                        <span className="px-3 py-1 bg-amber-100 text-amber-800 border border-amber-200 rounded-full text-xs font-bold uppercase">
                          {lang === 'es' ? 'MEDIO (45%)' : 'MEDIUM (45%)'}
                        </span>
                      </div>
                      {/* Risk item 3 */}
                      <div className="flex items-center justify-between p-4 bg-green-50 border border-green-100 rounded-2xl">
                        <div className="flex items-center gap-3">
                          <Check className="h-5 w-5 text-green-600" />
                          <span className="font-bold text-slate-700 text-sm">{t("risk_soil")}</span>
                        </div>
                        <span className="px-3 py-1 bg-green-100 text-green-800 border border-green-200 rounded-full text-xs font-bold uppercase">
                          {t("risk_optimal")}
                        </span>
                      </div>
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-400 mt-6 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-100">
                    {t("ai_disclaimer")}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* VIEW: DIRECT MESSAGES CHAT */}
          {currentView === 'CHAT' && !isRegistering && currentUser && (
            <div className="flex h-[calc(100vh-210px)] bg-white rounded-3xl shadow-sm overflow-hidden border border-slate-200 animate-fade-in" id="view-chat">
              
              {/* Contact Sidebar List */}
              <div className="w-1/3 border-r border-slate-200 flex flex-col hidden md:flex text-left">
                <div className="p-4 border-b border-slate-200 bg-slate-50/50">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                    <input type="text" placeholder={t("chat_search")} className="w-full pl-9 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500" />
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
                  {initialContacts.filter(c => c.id !== currentUser.id).map(contact => (
                    <div
                      key={contact.id}
                      className="p-4 flex items-center gap-3 cursor-pointer hover:bg-slate-50 transition-colors bg-emerald-50/10 border-l-4 border-emerald-500"
                    >
                      <div className="relative">
                        <img src={contact.avatar} alt="" className="w-11 h-11 rounded-full object-cover border" />
                        {contact.online && (
                          <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></span>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center mb-0.5">
                          <h4 className="font-bold text-slate-800 text-sm truncate">{contact.name}</h4>
                          <span className="text-[10px] text-slate-400 font-semibold">10:30 AM</span>
                        </div>
                        <p className="text-xs text-slate-500 truncate">{contact.lastMessage}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Chat Conversation Pane */}
              <div className="flex-1 flex flex-col bg-slate-50/50 text-left">
                {/* Chat Top Info Header */}
                <div className="p-4 bg-white border-b border-slate-200 flex justify-between items-center shadow-sm">
                  <div className="flex items-center gap-3">
                    <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=150&auto=format&fit=crop" alt="" className="w-10 h-10 rounded-full border" />
                    <div>
                      <h3 className="font-bold text-slate-800 text-sm">Elena Global Investments</h3>
                      <p className="text-[10px] text-emerald-600 flex items-center gap-1 font-bold mt-0.5">
                        <span className="w-2 h-2 bg-emerald-500 rounded-full inline-block animate-pulse"></span>
                        {t("chat_online")}
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-1 text-slate-400">
                    <button className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                      <Phone className="h-4 w-4" />
                    </button>
                    <button className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                      <Video className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                {/* Messages Body */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map(msg => {
                    const isMe = msg.senderId === currentUser.id;
                    return (
                      <div key={msg.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                        <div className={`max-w-[70%] px-5 py-3 rounded-2xl shadow-sm ${
                          isMe
                            ? "bg-emerald-600 text-white rounded-tr-none"
                            : "bg-white text-slate-800 border border-slate-100 rounded-tl-none"
                        }`}>
                          <p className="text-sm font-medium leading-relaxed">{msg.text}</p>
                          <p className={`text-[9px] mt-1 text-right font-bold ${isMe ? "text-emerald-200" : "text-slate-400"}`}>{msg.timestamp}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Message Send Form */}
                <div className="p-4 bg-white border-t border-slate-200">
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const form = e.target as HTMLFormElement;
                      const input = form.elements.namedItem('msgInput') as HTMLInputElement;
                      if (!input.value.trim()) return;

                      const newMsg: Message = {
                        id: `msg-${Date.now()}`,
                        senderId: currentUser.id,
                        receiverId: currentUser.role === 'PRODUCER' ? 'u2' : 'u1',
                        text: input.value,
                        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                      };

                      setMessages([...messages, newMsg]);
                      input.value = '';
                    }}
                    className="flex gap-2"
                  >
                    <input name="msgInput" type="text" placeholder={t("chat_placeholder")} className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-full focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all text-sm" />
                    <button type="submit" className="p-3 bg-emerald-600 text-white rounded-full hover:bg-emerald-700 transition-colors shadow-md shadow-emerald-600/10 shrink-0">
                      <Send className="h-4 w-4" />
                    </button>
                  </form>
                </div>
              </div>
            </div>
          )}

          {/* VIEW: BLOCKCHAIN WALLET */}
          {currentView === 'WALLET' && !isRegistering && currentUser && (
            <div className="space-y-8 animate-fade-in text-left" id="view-wallet">
              
              {/* Wallet Card summary */}
              <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <h3 className="text-xl font-black text-slate-800 tracking-tight">{t("wallet_title")}</h3>
                    <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full">
                      Polygon (Matic) Network
                    </span>
                  </div>
                  <p className="text-slate-500 text-xs font-semibold leading-relaxed max-w-xl">{t("wallet_desc")}</p>
                  
                  {/* Address Badge & Action Buttons */}
                  <div className="pt-2 flex flex-wrap items-center gap-3">
                    <span className="text-[10px] uppercase font-bold text-slate-400">{t("wallet_address")}:</span>
                    <div className="bg-slate-100 border px-3 py-2 rounded-xl flex items-center gap-2 font-mono text-xs text-slate-700">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      <span>{currentUser.walletAddress || "0x3db5ae71bca21cf29871fa8d810ba2cde1297fb9"}</span>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(currentUser.walletAddress || "0x3db5ae71bca21cf29871fa8d810ba2cde1297fb9");
                          showToast(t("wallet_copied"));
                        }}
                        className="p-1 hover:bg-slate-200 rounded text-slate-500 hover:text-slate-800 cursor-pointer transition-colors"
                        title={t("wallet_copy")}
                      >
                        <Copy className="h-3.5 w-3.5" />
                      </button>
                    </div>

                    <button
                      onClick={() => setIsWalletModalOpen(true)}
                      className="px-4 py-2 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white rounded-xl text-xs font-black transition-all shadow-sm flex items-center gap-2 active:scale-95 cursor-pointer"
                    >
                      <Wallet className="w-3.5 h-3.5" />
                      <span>{lang === 'es' ? "🦊 Gestionar / Conectar MetaMask" : "🦊 Manage / Connect MetaMask"}</span>
                    </button>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200/80 rounded-3xl p-6 text-center md:text-right shrink-0 min-w-[220px] shadow-sm">
                  <span className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">{t("balance")}</span>
                  <span className="text-3xl font-black text-emerald-800 font-mono">${currentUser.balance.toLocaleString()} MXN</span>
                  <div className="mt-2 flex items-center justify-center md:justify-end gap-2">
                    <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-widest bg-emerald-200/60 px-2 py-0.5 rounded-full">
                      Polygon Net • Live
                    </span>
                  </div>
                </div>
              </div>

              {/* Transactions list Table */}
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
                <h3 className="text-lg font-black text-slate-800 mb-6 tracking-tight">{t("wallet_tx_history")}</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-400 text-xs font-bold uppercase tracking-wider">
                        <th className="pb-3">{t("wallet_tbl_tx")}</th>
                        <th className="pb-3">{t("wallet_tbl_type")}</th>
                        <th className="pb-3">{t("wallet_tbl_amount")}</th>
                        <th className="pb-3">{t("wallet_tbl_total")}</th>
                        <th className="pb-3">{t("wallet_tbl_date")}</th>
                        <th className="pb-3">{t("wallet_tbl_status")}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-sm font-medium">
                      {transactions.map(tx => (
                        <tr key={tx.id}>
                          <td className="py-4 font-mono text-xs text-slate-400 hover:text-slate-600 transition-colors">
                            {tx.txHash.substring(0, 10)}...{tx.txHash.substring(54)}
                          </td>
                          <td className="py-4 text-slate-700">
                            {tx.type === 'BUY' ? t("wallet_buy_crop", { crop: tx.cropName }) : t("wallet_add_crop", { crop: tx.cropName })}
                          </td>
                          <td className="py-4 font-mono font-bold text-slate-600">
                            {tx.amount.toLocaleString()}
                          </td>
                          <td className="py-4 font-mono font-extrabold text-slate-800">
                            ${tx.total.toLocaleString()} MXN
                          </td>
                          <td className="py-4 text-slate-500 font-semibold">{tx.date}</td>
                          <td className="py-4">
                            <span className="bg-green-50 text-green-700 border border-green-200 px-3 py-1 rounded-full text-xs font-bold">
                              {t("wallet_status_confirmed")}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* VIEW: ABOUT US / NOSOTROS */}
          {currentView === 'ABOUT' && (
            <div className="animate-fade-in" id="view-about-us">
              <AboutUsView
                lang={lang}
                onRegisterProducer={() => {
                  handleOpenRegister('PRODUCER');
                }}
                onRegisterInvestor={() => {
                  handleOpenRegister('INVESTOR');
                }}
                onRegisterTrader={() => {
                  handleOpenRegister('TRADER');
                }}
                onExploreMarketplace={() => {
                  setCurrentView('MARKETPLACE');
                }}
                onOpenAiBot={() => {
                  setCurrentView('AI_BOT');
                }}
              />
            </div>
          )}

          {/* VIEW: AI BOT CHAT */}
          {currentView === 'AI_BOT' && (
            <div className="max-w-4xl mx-auto animate-fade-in" id="view-ai-bot">
              <AIChatBot
                lang={lang}
                crops={crops}
                currentUser={currentUser}
              />
            </div>
          )}

        </div>
      </main>

      {/* MODAL: INVEST IN TOKENS DIALOG WITH CARDS & WALLET */}
      <InvestInCropModal
        isOpen={isBuyModalOpen}
        onClose={() => setIsBuyModalOpen(false)}
        crop={selectedCropToBuy}
        currentUser={currentUser}
        lang={lang}
        onInvestSuccess={(cropId, amount, totalPrice, tx) => {
          setCrops(prev => prev.map(c => c.id === cropId ? { ...c, soldTokens: c.soldTokens + amount } : c));
          setTransactions(prev => [tx, ...prev]);
          if (tx.paymentMethod === 'WALLET_BALANCE' && currentUser) {
            const newBal = Math.max(0, currentUser.balance - totalPrice);
            saveUser({ ...currentUser, balance: newBal });
          }
          setIsBuyModalOpen(false);
          showToast(t("invest_success", { amount, name: tx.cropName, total: totalPrice.toLocaleString() }));
        }}
      />

      {/* MODAL: PRODUCER LOAD CROP DIALOG */}
      {isAddCropModalOpen && currentUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto" id="add-crop-modal">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden border border-slate-100 text-left">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <div>
                <h3 className="font-extrabold text-slate-800 text-lg leading-none">{t("add_crop_title")}</h3>
                <p className="text-slate-400 text-xs font-semibold mt-1.5">{t("add_crop_sub")}</p>
              </div>
              <button onClick={() => setIsAddCropModalOpen(false)} className="p-2 hover:bg-slate-200 rounded-full text-slate-500 transition-colors">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Modal Form Submission */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = e.target as HTMLFormElement;
                const nameVal = (form.elements.namedItem('cropName') as HTMLInputElement).value;
                const typeVal = (form.elements.namedItem('cropType') as HTMLSelectElement).value;
                const priceVal = Number((form.elements.namedItem('cropPrice') as HTMLInputElement).value);
                const tokensVal = Number((form.elements.namedItem('cropTokens') as HTMLInputElement).value);
                const yieldVal = Number((form.elements.namedItem('cropYield') as HTMLInputElement).value);
                const dateVal = (form.elements.namedItem('cropHarvest') as HTMLInputElement).value;
                const scoreVal = Number((form.elements.namedItem('cropScore') as HTMLInputElement).value);
                const descVal = (form.elements.namedItem('cropDesc') as HTMLTextAreaElement).value;
                const openseaUrlVal = (form.elements.namedItem('cropOpenseaUrl') as HTMLInputElement).value;
                const contractVal = (form.elements.namedItem('cropContract') as HTMLInputElement).value;
                const tokenIdVal = (form.elements.namedItem('cropTokenId') as HTMLInputElement).value;

                const cropIdGenerated = `crop-${Date.now()}`;
                const newCrop: Crop = {
                  id: cropIdGenerated,
                  name: nameVal,
                  producerName: currentUser.name,
                  location: "Oaxaca, México",
                  type: typeVal,
                  imageUrl: "https://images.unsplash.com/photo-1530595467537-0b5996c41f2d?q=80&w=800&auto=format&fit=crop",
                  description: descVal,
                  riskLevel: 'BAJO',
                  tokenPrice: priceVal,
                  totalTokens: tokensVal,
                  soldTokens: 0,
                  yieldProjection: yieldVal,
                  harvestDate: dateVal,
                  sustainabilityScore: scoreVal,
                  openseaUrl: openseaUrlVal || `https://opensea.io/assets/matic/0x2953399124f0cbb46d2cbacd8a89cf0599974963/${cropIdGenerated}`,
                  nftContract: contractVal || "0x2953399124f0cbb46d2cbacd8a89cf0599974963",
                  nftTokenId: tokenIdVal || `#${cropIdGenerated}`,
                  nftStandard: "ERC-721"
                };

                setCrops([newCrop, ...crops]);

                // Register Blockchain Tx for issuing tokens
                const newTx: Transaction = {
                  id: `tx-issue-${Date.now()}`,
                  cropName: nameVal,
                  amount: tokensVal,
                  price: priceVal,
                  total: priceVal * tokensVal,
                  date: new Date().toLocaleDateString(),
                  type: 'FUND',
                  txHash: "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("")
                };
                setTransactions([newTx, ...transactions]);

                // Persist new crop and transaction to Firestore
                setDoc(doc(db, 'crops', newCrop.id), newCrop).catch((err) => {
                  console.warn("Firestore crop sync notice:", err);
                });
                setDoc(doc(db, 'transactions', newTx.id), newTx).catch((err) => {
                  console.warn("Firestore transaction sync notice:", err);
                });

                setIsAddCropModalOpen(false);
                showToast(t("crop_added_success"));
              }}
              className="p-6 space-y-6 max-h-[75vh] overflow-y-auto"
            >
              {/* Sec A: General Info */}
              <div className="space-y-4">
                <h4 className="font-extrabold text-emerald-800 border-b border-emerald-50 pb-1.5 text-sm uppercase tracking-wider">{t("form_general")}</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Nombre del Cultivo</label>
                    <input required name="cropName" type="text" className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-sm" placeholder={t("crop_name_placeholder")} />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Ubicación</label>
                    <input required name="cropLocation" type="text" className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-sm" placeholder={t("crop_location_placeholder")} />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Tipo de Cultivo</label>
                    <select name="cropType" className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-sm bg-white font-semibold">
                      <option value="Granos">Granos / Grains</option>
                      <option value="Café">Café / Coffee</option>
                      <option value="Frutales">Frutales / Fruits</option>
                      <option value="Agave">Agave</option>
                      <option value="Hortalizas">Hortalizas / Vegetables</option>
                    </select>
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">{t("form_desc")}</label>
                    <textarea required name="cropDesc" rows={3} className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-sm" placeholder="e.g. Cultivo orgánico libre de pesticidas con certificación de suelo..."></textarea>
                  </div>
                </div>
              </div>

              {/* Sec B: Tokenization details */}
              <div className="space-y-4">
                <h4 className="font-extrabold text-blue-800 border-b border-blue-50 pb-1.5 text-sm uppercase tracking-wider">{t("form_economics")}</h4>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">{t("form_price")}</label>
                    <input required name="cropPrice" type="number" className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-sm font-mono" placeholder="50" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">{t("form_total_tokens")}</label>
                    <input required name="cropTokens" type="number" className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-sm font-mono" placeholder="5000" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">{t("form_yield")}</label>
                    <input required name="cropYield" type="number" step="0.1" className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-sm font-mono" placeholder="12.5" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">{t("form_harvest")}</label>
                    <input required name="cropHarvest" type="date" className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-sm font-semibold" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">{t("form_score")}</label>
                    <input required name="cropScore" type="number" min="0" max="100" className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-sm font-mono" defaultValue="90" />
                  </div>
                </div>
              </div>

              {/* Sec C: NFT OpenSea Linkage */}
              <div className="space-y-4">
                <h4 className="font-extrabold text-sky-800 border-b border-sky-50 pb-1.5 text-sm uppercase tracking-wider flex items-center gap-2">
                  <Layers className="h-4 w-4 text-sky-600" />
                  <span>{t("nft_sec_title")}</span>
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-sky-50/50 p-4 rounded-2xl border border-sky-100">
                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">{t("nft_field_opensea_url")}</label>
                    <input name="cropOpenseaUrl" type="url" className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-sky-500 text-sm font-mono" placeholder="https://opensea.io/assets/matic/0x..." />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">{t("nft_field_contract")}</label>
                    <input name="cropContract" type="text" className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-sky-500 text-sm font-mono text-xs" placeholder="0x2953399124f0cbb46d2cbacd8a89cf059..." />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">{t("nft_field_token_id")}</label>
                    <input name="cropTokenId" type="text" className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-sky-500 text-sm font-mono" placeholder="#1001" />
                  </div>
                </div>
              </div>

              {/* Sec D: Document Upload representation */}
              <div className="space-y-4">
                <h4 className="font-extrabold text-slate-800 border-b border-slate-100 pb-1.5 text-sm uppercase tracking-wider">{t("form_legal_doc")}</h4>
                <div className="border-2 border-dashed border-slate-300 rounded-2xl p-6 text-center cursor-pointer hover:bg-slate-50 transition-all flex flex-col items-center justify-center">
                  <UploadCloud className="h-8 w-8 text-slate-400 mb-2" />
                  <span className="text-sm font-bold text-slate-700">{t("legal_upload_text")}</span>
                  <span className="text-xs text-slate-400 mt-1">{t("legal_upload_sub")}</span>
                </div>
              </div>

              {/* Modal Actions */}
              <div className="flex gap-3 pt-4 border-t border-slate-100">
                <button type="button" onClick={() => setIsAddCropModalOpen(false)} className="flex-1 py-3 border border-slate-300 rounded-xl font-bold text-slate-700 hover:bg-slate-50 transition-colors">
                  {t("btn_cancel")}
                </button>
                <button type="submit" className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-md shadow-emerald-600/10">
                  {t("btn_load_crop")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: NFT OPENSEA CERTIFICATE & TRACEABILITY */}
      {selectedNftCrop && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto animate-fade-in" id="nft-certificate-modal">
          <div className="bg-slate-900 text-white rounded-3xl shadow-2xl w-full max-w-3xl my-8 overflow-hidden border border-sky-500/30 text-left max-h-[90vh] flex flex-col">
            {/* Header */}
            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-950/80 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-[#2081E2]/20 flex items-center justify-center text-[#2081E2] border border-[#2081E2]/40">
                  <Layers className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-black text-white text-base leading-none">{t("nft_modal_title")}</h3>
                  <p className="text-sky-400 text-xs font-semibold mt-1 flex items-center gap-1">
                    <CheckCircle className="h-3.5 w-3.5 text-sky-400" />
                    <span>{t("nft_verified_opensea")}</span>
                  </p>
                </div>
              </div>
              <button onClick={() => setSelectedNftCrop(null)} className="p-2 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white transition-colors">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 space-y-6 overflow-y-auto flex-1">
              {/* Crop Identity Summary */}
              <div className="flex items-center gap-4 bg-slate-800/80 p-4 rounded-2xl border border-slate-700/80">
                <img src={selectedNftCrop.imageUrl} alt={selectedNftCrop.name} className="w-16 h-16 rounded-xl object-cover border border-slate-600 shrink-0" />
                <div className="min-w-0 flex-1">
                  <h4 className="font-extrabold text-white text-lg">{selectedNftCrop.name}</h4>
                  <p className="text-xs text-slate-400 font-medium">{selectedNftCrop.producerName} • {selectedNftCrop.location}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="inline-block px-2.5 py-0.5 bg-emerald-500/20 text-emerald-400 text-[10px] font-black rounded-full border border-emerald-500/30 uppercase">
                      {selectedNftCrop.type}
                    </span>
                    {selectedNftCrop.priceChange24h !== undefined && (
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        selectedNftCrop.priceChange24h >= 0 ? "bg-emerald-500/20 text-emerald-300" : "bg-rose-500/20 text-rose-300"
                      }`}>
                        {selectedNftCrop.priceChange24h >= 0 ? "+" : ""}{selectedNftCrop.priceChange24h.toFixed(2)}% (24h)
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Real Time IoT Weather Telemetry Widget */}
              {selectedNftCrop.weather && (
                <CropWeatherWidget
                  weather={selectedNftCrop.weather}
                  location={selectedNftCrop.location}
                  lang={lang}
                  onSimulateWeatherChange={handleSimulateWeatherChange}
                />
              )}

              {/* Real Time Agronomic Crop Development Tracker */}
              {selectedNftCrop.development && (
                <CropDevelopmentTracker
                  development={selectedNftCrop.development}
                  cropName={selectedNftCrop.name}
                  isProducer={currentUser?.role === 'PRODUCER'}
                  lang={lang}
                  onAddLogEvent={(log, newProg) => handleAddLogEvent(selectedNftCrop.id, log, newProg)}
                />
              )}

              {/* NFT Details Grid */}
              <div className="space-y-3 bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800">
                  <span className="text-slate-400 font-bold">{t("nft_network")}</span>
                  <span className="font-mono font-extrabold text-sky-400 flex items-center gap-1">
                    <Globe className="h-3.5 w-3.5" /> Polygon POS / Ethereum
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800">
                  <span className="text-slate-400 font-bold">{t("nft_standard")}</span>
                  <span className="font-mono font-bold text-white">{selectedNftCrop.nftStandard || "ERC-721"}</span>
                </div>
                <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800">
                  <span className="text-slate-400 font-bold">{t("nft_token_id")}</span>
                  <span className="font-mono font-bold text-emerald-400">{selectedNftCrop.nftTokenId || `#${selectedNftCrop.id}`}</span>
                </div>
                <div className="flex flex-col text-xs pt-1">
                  <span className="text-slate-400 font-bold mb-1">{t("nft_contract_address")}</span>
                  <span className="font-mono text-[11px] text-sky-300 bg-slate-900 p-2 rounded-xl border border-slate-800 break-all select-all">
                    {selectedNftCrop.nftContract || "0x2953399124f0cbb46d2cbacd8a89cf0599974963"}
                  </span>
                </div>
              </div>

              {/* Direct Link Action */}
              <div className="pt-2">
                <a
                  href={selectedNftCrop.openseaUrl || `https://opensea.io/assets/matic/0x2953399124f0cbb46d2cbacd8a89cf0599974963/${selectedNftCrop.id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-4 bg-[#2081E2] hover:bg-[#1868b7] text-white rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-500/20"
                >
                  <ExternalLink className="h-4 w-4" />
                  <span>{t("nft_open_opensea")}</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: INSERT / EDIT NFT FOR A CROP */}
      {editingNftCrop && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto animate-fade-in" id="edit-nft-modal">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-100 text-left">
            <div className="p-6 bg-slate-900 text-white flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-sky-500/20 flex items-center justify-center text-sky-400 border border-sky-500/30">
                  <Link2 className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-base">{t("nft_edit_title")}</h3>
                  <p className="text-xs text-sky-300 truncate max-w-xs">{editingNftCrop.name}</p>
                </div>
              </div>
              <button onClick={() => setEditingNftCrop(null)} className="p-2 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white transition-colors">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = e.currentTarget;
                const url = (form.elements.namedItem('nftUrl') as HTMLInputElement).value;
                const contract = (form.elements.namedItem('nftContract') as HTMLInputElement).value;
                const tokenId = (form.elements.namedItem('nftTokenId') as HTMLInputElement).value;
                const standard = (form.elements.namedItem('nftStandard') as HTMLSelectElement).value;

                const updatedCrops = crops.map(c => {
                  if (c.id === editingNftCrop.id) {
                    return {
                      ...c,
                      openseaUrl: url,
                      nftContract: contract,
                      nftTokenId: tokenId,
                      nftStandard: standard
                    };
                  }
                  return c;
                });

                setCrops(updatedCrops);
                localStorage.setItem('milpa_crops', JSON.stringify(updatedCrops));
                setEditingNftCrop(null);
              }}
              className="p-6 space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">{t("nft_field_opensea_url")}</label>
                <input
                  name="nftUrl"
                  type="url"
                  required
                  defaultValue={editingNftCrop.openseaUrl || ""}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 text-xs font-mono"
                  placeholder="https://opensea.io/item/polygon/0x88485aad41e74e69321e848d8e78e892c5a5315d/1"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">{t("nft_field_contract")}</label>
                  <input
                    name="nftContract"
                    type="text"
                    defaultValue={editingNftCrop.nftContract || ""}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 text-xs font-mono"
                    placeholder="0x88485aad41e74e69321e848d8e78e892c5a5315d"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">{t("nft_field_token_id")}</label>
                  <input
                    name="nftTokenId"
                    type="text"
                    defaultValue={editingNftCrop.nftTokenId || ""}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 text-xs font-mono"
                    placeholder="#1"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">{t("nft_standard")}</label>
                <select
                  name="nftStandard"
                  defaultValue={editingNftCrop.nftStandard || "ERC-721"}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 text-xs font-bold"
                >
                  <option value="ERC-721">ERC-721 (Único)</option>
                  <option value="ERC-1155">ERC-1155 (Multi-token)</option>
                </select>
              </div>

              {/* Quick Preset Suggestion for Agave */}
              <div className="bg-sky-50 p-3 rounded-xl border border-sky-200 text-xs text-sky-800 flex items-center justify-between">
                <span className="font-medium">Preset Agave Polygon OpenSea</span>
                <button
                  type="button"
                  onClick={(e) => {
                    const form = e.currentTarget.closest('form');
                    if (form) {
                      (form.elements.namedItem('nftUrl') as HTMLInputElement).value = "https://opensea.io/item/polygon/0x88485aad41e74e69321e848d8e78e892c5a5315d/1";
                      (form.elements.namedItem('nftContract') as HTMLInputElement).value = "0x88485aad41e74e69321e848d8e78e892c5a5315d";
                      (form.elements.namedItem('nftTokenId') as HTMLInputElement).value = "#1";
                      (form.elements.namedItem('nftStandard') as HTMLSelectElement).value = "ERC-721";
                    }
                  }}
                  className="px-2.5 py-1 bg-sky-600 text-white rounded-lg text-[10px] font-bold hover:bg-sky-700 transition-colors shrink-0"
                >
                  Cargar Agave #1
                </button>
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setEditingNftCrop(null)}
                  className="flex-1 py-2.5 border border-slate-300 rounded-xl font-bold text-slate-700 hover:bg-slate-50 transition-colors text-xs"
                >
                  {t("btn_cancel")}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl font-bold text-xs shadow-md shadow-sky-600/20"
                >
                  {t("nft_save_btn")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Public User Profile Modal */}
      {selectedProfileUser && (
        <UserProfileModal
          user={selectedProfileUser}
          currentUser={currentUser}
          lang={lang}
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
          onUpdateProfile={handleUpdateProfile}
          reviews={reviews}
          onAddReview={handleAddReview}
        />
      )}

      {/* Web3 / MetaMask Wallet Connection Modal */}
      <Web3WalletModal
        isOpen={isWalletModalOpen}
        onClose={() => setIsWalletModalOpen(false)}
        lang={lang}
        currentUser={currentUser}
        onWalletConnected={handleWalletConnected}
        onUpdateBalance={handleUpdateBalance}
      />

      {/* Universal Auth & Role Registration Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        lang={lang}
        initialMode={authModalMode}
        initialRole={authModalInitialRole}
        onLoginSuccess={(user) => {
          saveUser(user);
          showToast(lang === 'es' ? `¡Bienvenido a Milpa Tech, ${user.name}!` : `Welcome to Milpa Tech, ${user.name}!`);
          if (user.role === 'PRODUCER') {
            setCurrentView('DASHBOARD');
          } else {
            setCurrentView('MARKETPLACE');
          }
        }}
        onAuthSuccess={(user) => {
          saveUser(user);
          showToast(lang === 'es' ? `¡Bienvenido a Milpa Tech, ${user.name}!` : `Welcome to Milpa Tech, ${user.name}!`);
          if (user.role === 'PRODUCER') {
            setCurrentView('DASHBOARD');
          } else {
            setCurrentView('MARKETPLACE');
          }
        }}
      />

      {/* Production & Real Pilot Launch Modal */}
      <ProductionLaunchModal
        isOpen={isProductionModalOpen}
        onClose={() => setIsProductionModalOpen(false)}
        lang={lang}
        currentUser={currentUser}
        onSwitchUser={(user) => {
          saveUser(user);
          showToast(lang === 'es' ? `Sesión cambiada a ${user.name}` : `Switched session to ${user.name}`);
          if (user.role === 'PRODUCER') {
            setCurrentView('DASHBOARD');
          } else {
            setCurrentView('MARKETPLACE');
          }
        }}
        onUserCreated={(newUser) => {
          saveUser(newUser);
          showToast(lang === 'es' ? `¡Usuario ${newUser.name} creado y conectado!` : `User ${newUser.name} created and connected!`);
          if (newUser.role === 'PRODUCER') {
            setCurrentView('DASHBOARD');
          } else {
            setCurrentView('MARKETPLACE');
          }
        }}
        onShowToast={(msg) => showToast(msg)}
      />

      {/* Anti-Fraud Seller Registration & KYC Modal */}
      <SellerRegistrationModal
        isOpen={isSellerModalOpen}
        onClose={() => setIsSellerModalOpen(false)}
        currentUser={currentUser}
        lang={lang}
        onSellerRegistered={handleSellerRegistrationComplete}
      />

      {/* Direct Inter-User Messaging & Trade Negotiation Modal */}
      {directChatTargetUser && (
        <DirectUserChatModal
          isOpen={isDirectChatModalOpen}
          onClose={() => setIsDirectChatModalOpen(false)}
          currentUser={currentUser}
          targetUser={directChatTargetUser}
          lang={lang}
          onSendMessage={handleDirectChatMessage}
          crops={crops}
          marketplaceItems={marketplaceItems}
        />
      )}

      {/* Marketplace Product/Service Detail & Smart Escrow Purchase Modal */}
      <MarketplaceItemDetailModal
        isOpen={isMarketplaceItemModalOpen}
        onClose={() => setIsMarketplaceItemModalOpen(false)}
        item={selectedMarketplaceItem}
        currentUser={currentUser}
        lang={lang}
        onBuyItem={(item, quantity, total) => {
          handleMarketplacePurchase(item, quantity, true);
        }}
        onContactSeller={(seller) => {
          setDirectChatTargetUser(seller);
          setIsMarketplaceItemModalOpen(false);
          setIsDirectChatModalOpen(true);
        }}
      />

      {/* Crop Image Manager Modal */}
      <CropImageModal
        crop={cropToEditImage}
        isOpen={cropToEditImage !== null}
        onClose={() => setCropToEditImage(null)}
        onSaveImage={handleUpdateCropImage}
        lang={lang}
      />

      {/* Floating AI Chatbot Widget Button & Drawer */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
        {isFloatingChatOpen ? (
          <div className="mb-4 shadow-2xl animate-fade-in w-full max-w-lg">
            <AIChatBot
              lang={lang}
              crops={crops}
              currentUser={currentUser}
              isFloating={true}
              onClose={() => setIsFloatingChatOpen(false)}
            />
          </div>
        ) : (
          <button
            onClick={() => setIsFloatingChatOpen(true)}
            className="px-5 py-3.5 bg-gradient-to-r from-emerald-600 via-green-600 to-emerald-800 hover:from-emerald-500 hover:to-green-500 text-white rounded-full shadow-2xl shadow-emerald-900/50 flex items-center gap-3 font-extrabold text-sm border-2 border-emerald-400/40 transform hover:-translate-y-1 transition-all group"
          >
            <div className="relative">
              <Bot className="h-5 w-5 text-emerald-100 group-hover:scale-110 transition-transform" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping"></span>
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full"></span>
            </div>
            <span>{lang === 'es' ? "Preguntas AI" : "AI Assistant"}</span>
            <Sparkles className="h-4 w-4 text-emerald-200" />
          </button>
        )}
      </div>

    </div>
  );
}
