import { GoogleGenAI } from "@google/genai";

// In-Memory Response Cache for high-performance external server deployments
interface CacheEntry {
  reply: string;
  groundingChunks: Array<{ title: string; uri: string }>;
  timestamp: number;
}

const responseCache = new Map<string, CacheEntry>();
const CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes cache TTL
const MAX_CACHE_ENTRIES = 200;

export interface ChatRequestPayload {
  message: string;
  history?: Array<{ role: 'user' | 'model'; text: string }>;
  lang?: 'es' | 'en';
  cropsContext?: any[];
  userContext?: any;
}

export interface ChatResponseResult {
  reply: string;
  groundingChunks: Array<{ title: string; uri: string }>;
  source: 'gemini-live' | 'cache' | 'fallback';
}

/**
 * Domain-specific agro-finance knowledge fallback generator
 * Guarantees a rich, accurate reply even if internet or API quota fails on external servers.
 */
export function generateDomainFallbackReply(query: string, lang: string = 'es', cropsContext?: any[]): string {
  const isEs = lang === 'es';
  const q = (query || '').toLowerCase();

  if (q.includes('agave') || q.includes('espadin') || q.includes('espadín') || q.includes('oaxaca') || q.includes('mezcal')) {
    return isEs
      ? `**Agave Angustifolia-Espadín de Oaxaca**\n\n` +
        `• **Rendimiento Proyectado:** 25.0% Anual Estimado\n` +
        `• **Precio por Token:** $85.00 MXN\n` +
        `• **Ubicación:** Matatlán & San Dionisio, Oaxaca (Región Mezcalera)\n` +
        `• **Nivel de Riesgo:** ALTO (Ciclo de maduración prolongado 6-8 años con alta demanda en la industria del mezcal artesanal).\n` +
        `• **Trazabilidad NFT:** Vinculado al Smart Contract ERC-721 en Polygon \`0x88485aad41e74e69321e848d8e78e892c5a5315d\` (Token ID: #1).\n` +
        `• **Enlace en OpenSea:** [Ver Certificado NFT en OpenSea](https://opensea.io/item/polygon/0x88485aad41e74e69321e848d8e78e892c5a5315d/1)\n` +
        `• **Prácticas Agroecológicas:** Cultivo sin herbicidas químicos, deshierbe manual tradicional y monitoreo de grados Brix para acumulación de azúcares en piña.`
      : `**Agave Angustifolia-Espadin from Oaxaca**\n\n` +
        `• **Projected Yield:** 25.0% Annual Return\n` +
        `• **Token Price:** $85.00 MXN\n` +
        `• **Location:** Matatlán & San Dionisio, Oaxaca\n` +
        `• **Risk Level:** HIGH (Long maturation cycle 6-8 years with surging artisan mezcal demand).\n` +
        `• **NFT Traceability:** Linked to ERC-721 Smart Contract on Polygon \`0x88485aad41e74e69321e848d8e78e892c5a5315d\` (Token ID: #1).\n` +
        `• **OpenSea Certificate:** [View NFT Certificate on OpenSea](https://opensea.io/item/polygon/0x88485aad41e74e69321e848d8e78e892c5a5315d/1)\n` +
        `• **Agroecological Practices:** Zero chemical herbicides, traditional manual weeding, and Brix sugar accumulation tracking.`;
  }

  if (q.includes('café') || q.includes('cafe') || q.includes('coffee') || q.includes('chiapas')) {
    return isEs
      ? `**Café de Altura Sostenible (Chiapas)**\n\n` +
        `• **Rendimiento Proyectado:** 18.2% Anual\n` +
        `• **Precio por Token:** $120.00 MXN\n` +
        `• **Ubicación:** Soconusco / Finca La Niebla, Chiapas\n` +
        `• **Nivel de Riesgo:** MEDIO\n` +
        `• **Score de Sostenibilidad:** 88/100 (Certificación de Comercio Justo y Café bajo sombra nativa)\n` +
        `• **Trazabilidad NFT:** Smart Contract ERC-721 en Polygon \`0x495f947276749ce646f68ac8c248420045cb7b5e\` (Token ID: #88392104).\n` +
        `• **Enlace en OpenSea:** [Ver NFT de Café en OpenSea](https://opensea.io/assets/matic/0x495f947276749ce646f68ac8c248420045cb7b5e/883921049281)`
      : `**Sustainable High-Altitude Coffee (Chiapas)**\n\n` +
        `• **Projected Yield:** 18.2% Annual\n` +
        `• **Token Price:** $120.00 MXN\n` +
        `• **Location:** Soconusco / Finca La Niebla, Chiapas\n` +
        `• **Risk Level:** MEDIUM\n` +
        `• **Sustainability Score:** 88/100 (Fair Trade & Native Canopy Shade Grown)\n` +
        `• **NFT Traceability:** ERC-721 Smart Contract on Polygon \`0x495f947276749ce646f68ac8c248420045cb7b5e\` (Token ID: #88392104).\n` +
        `• **OpenSea Certificate:** [View Coffee NFT on OpenSea](https://opensea.io/assets/matic/0x495f947276749ce646f68ac8c248420045cb7b5e/883921049281)`;
  }

  if (q.includes('maiz') || q.includes('maíz') || q.includes('corn') || q.includes('san miguel')) {
    return isEs
      ? `**Maíz Criollo Orgánico Ancestral**\n\n` +
        `• **Rendimiento Proyectado:** 12.5% Anual\n` +
        `• **Precio por Token:** $50.00 MXN (Accesible para microinversores)\n` +
        `• **Ubicación:** Ejido San Miguel, Oaxaca / Puebla\n` +
        `• **Nivel de Riesgo:** BAJO (Alta resiliencia climática y ciclos rápidos de cosecha)\n` +
        `• **Score de Sostenibilidad:** 95/100\n` +
        `• **Trazabilidad NFT:** Smart Contract ERC-1155 \`0x2953399124f0cbb46d2cbacd8a89cf0599974963\` (Token ID: #10293848).\n` +
        `• **Monitoreo:** Telemetría por satélite y dron NDVI con salud foliar de 0.89 y humedad de suelo regulada.`
      : `**Native Organic Corn (Maíz Criollo)**\n\n` +
        `• **Projected Yield:** 12.5% Annual\n` +
        `• **Token Price:** $50.00 MXN\n` +
        `• **Location:** Ejido San Miguel, Oaxaca / Puebla\n` +
        `• **Risk Level:** LOW (High climate resilience and fast harvest cycles)\n` +
        `• **Sustainability Score:** 95/100\n` +
        `• **NFT Traceability:** ERC-1155 Smart Contract \`0x2953399124f0cbb46d2cbacd8a89cf0599974963\` (Token ID: #10293848).\n` +
        `• **Monitoring:** Satellite & NDVI drone telemetry with 0.89 foliar health score.`;
  }

  if (q.includes('aguacate') || q.includes('avocado') || q.includes('michoacan') || q.includes('michoacán')) {
    return isEs
      ? `**Aguacate Hass Regenerativo (Michoacán)**\n\n` +
        `• **Rendimiento Proyectado:** 10.5% Anual\n` +
        `• **Precio por Token:** $200.00 MXN\n` +
        `• **Ubicación:** Huertos del Valle, Michoacán\n` +
        `• **Nivel de Riesgo:** BAJO\n` +
        `• **Sostenibilidad:** Certificación GlobalG.A.P. y cero huella de deforestación mediante riego por microgoteo inteligente.\n` +
        `• **Trazabilidad NFT:** Smart Contract ERC-721 \`0x71c7656ec7ab88b098defb751b7401b5f6d8976f\` (Token ID: #55021).\n` +
        `• **Enlace en OpenSea:** [Ver Certificado NFT en OpenSea](https://opensea.io/assets/ethereum/0x71c7656ec7ab88b098defb751b7401b5f6d8976f/55021)`
      : `**Regenerative Hass Avocado (Michoacán)**\n\n` +
        `• **Projected Yield:** 10.5% Annual\n` +
        `• **Token Price:** $200.00 MXN\n` +
        `• **Location:** Huertos del Valle, Michoacán\n` +
        `• **Risk Level:** LOW\n` +
        `• **Sustainability:** GlobalG.A.P. certified with zero deforestation footprint via smart micro-drip irrigation.\n` +
        `• **NFT Traceability:** ERC-721 Smart Contract \`0x71c7656ec7ab88b098defb751b7401b5f6d8976f\` (Token ID: #55021).\n` +
        `• **OpenSea Certificate:** [View NFT on OpenSea](https://opensea.io/assets/ethereum/0x71c7656ec7ab88b098defb751b7401b5f6d8976f/55021)`;
  }

  if (q.includes('nft') || q.includes('opensea') || q.includes('blockchain') || q.includes('trazabilidad') || q.includes('contrato') || q.includes('smart contract')) {
    return isEs
      ? `**Trazabilidad Blockchain y NFTs en Milpa Tech**\n\n` +
        `1. **Contratos Inteligentes en Polygon:** Cada cultivo está respaldado por un NFT único (ERC-721 o ERC-1155) en la red Polygon (Matic), reduciendo tarifas de gas a centavos.\n` +
        `2. **Certificación Verificable en OpenSea:** Puedes consultar la ficha de cada cultivo y abrir su enlace oficial a OpenSea para verificar los metadatos de geolocalización, volumen de tokens emitidos y lote productivo.\n` +
        `3. **Inmutabilidad:** Las transacciones y retornos de cosecha quedan registrados en el Ledger distribuido, permitiendo auditoría pública sin intermediarios.\n` +
        `4. **Billeteras Compatibles:** Puedes vincular MetaMask o activar la Billetera Demo Web3 directamente desde la barra superior.`
      : `**Blockchain Traceability & NFTs on Milpa Tech**\n\n` +
        `1. **Smart Contracts on Polygon:** Every crop listing is backed by a unique NFT (ERC-721 or ERC-1155) deployed on Polygon (Matic) with near-zero gas fees.\n` +
        `2. **Verifiable on OpenSea:** Each crop card includes direct links to OpenSea to inspect geolocation metadata, token issuance volume, and harvest batch records.\n` +
        `3. **Immutability:** All transactions and yield payouts are permanently logged on the distributed ledger for transparent public auditing.\n` +
        `4. **Supported Wallets:** Connect via MetaMask or initialize the instant Web3 Demo Wallet from the top navigation bar.`;
  }

  if (q.includes('precio') || q.includes('mercado') || q.includes('market') || q.includes('cotización') || q.includes('commodities')) {
    return isEs
      ? `**Cotizaciones y Tendencias de Mercado Agrícola (2026)**\n\n` +
        `• **Maíz Criollo / Grano:** $50.00 MXN / token (+3.09% 24h) | Fuerte demanda de harinas orgánicas certificadas.\n` +
        `• **Café Arábica de Sombra:** $120.00 MXN / token (-2.04% 24h) | Estabilidad de precios en mercados de exportación europea.\n` +
        `• **Aguacate Hass de Exportación:** $200.00 MXN / token (+4.17% 24h) | Incremento estacional por demanda internacional.\n` +
        `• **Agave Tequilana / Espadín:** $85.00 MXN / token (+4.94% 24h) | Alta valorización impulsada por denominación de origen en mezcal y destilados.\n\n` +
        `*Puedes simular cambios de mercado en tiempo real pulsando el botón "Simular Mercado" en la barra de cotizaciones.*`
      : `**Agricultural Market Prices & Trends (2026)**\n\n` +
        `• **Native Organic Corn:** $50.00 MXN / token (+3.09% 24h) | Strong demand for certified organic flours.\n` +
        `• **Shade Arabica Coffee:** $120.00 MXN / token (-2.04% 24h) | Stable export pricing across European specialty markets.\n` +
        `• **Hass Avocado:** $200.00 MXN / token (+4.17% 24h) | Seasonal uptick driven by international consumption.\n` +
        `• **Agave Angustifolia-Espadin:** $85.00 MXN / token (+4.94% 24h) | High valuation supported by artisan mezcal appellation of origin.\n\n` +
        `*You can simulate real-time market updates by clicking "Simulate Market" in the ticker bar.*`;
  }

  if (q.includes('invertir') || q.includes('invest') || q.includes('funciona') || q.includes('cómo') || q.includes('comprar')) {
    return isEs
      ? `**Guía Paso a Paso: Cómo Invertir en Milpa Tech**\n\n` +
        `1. **Explora el Marketplace:** Filtra cultivos por tipo de grano, nivel de riesgo (Bajo, Medio, Alto) o score ESG.\n` +
        `2. **Selecciona tu Fracción:** Ingresa la cantidad de tokens deseada (desde $50 MXN) y confirma la transacción.\n` +
        `3. **Firma en Blockchain:** Se emite una orden de compra vinculada a tu billetera Web3 (MetaMask o Demo).\n` +
        `4. **Seguimiento Agronómico en Vivo:** Revisa en tu panel el clima, la salud foliar (NDVI) y los reportes de desarrollo.\n` +
        `5. **Liquidación de Cosecha:** Al concluir la zafra o cosecha, los dividendos calculados con base en el rendimiento se abonan a tu saldo.`
      : `**Step-by-Step Guide: How to Invest on Milpa Tech**\n\n` +
        `1. **Explore the Marketplace:** Filter crops by category, risk rating (Low, Medium, High), or ESG sustainability score.\n` +
        `2. **Select Fraction:** Choose the number of tokens you wish to purchase (starting at $50 MXN) and confirm.\n` +
        `3. **Blockchain Signing:** A purchase order is issued and linked to your Web3 wallet (MetaMask or Demo).\n` +
        `4. **Live Agronomic Tracking:** Monitor real-time weather, NDVI vegetation health, and soil sensor logs in your dashboard.\n` +
        `5. **Harvest Liquidation:** Once the harvest cycle completes, sale yields are credited directly to your balance.`;
  }

  return isEs
    ? `**Asistente Inteligente Milpa AI**\n\n` +
      `Te ayudo a resolver consultas sobre la plataforma **Milpa Tech**:\n\n` +
      `• **Cultivos Disponibles:** Agave Espadín (25% retorno), Café de Altura (18.2%), Maíz Criollo (12.5%) y Aguacate Hass (10.5%).\n` +
      `• **Trazabilidad NFT:** Cada cultivo cuenta con smart contracts en Polygon verificables en **OpenSea**.\n` +
      `• **Monitoreo IoT y Satelital:** Sensores de humedad, temperatura, índice UV y salud vegetal NDVI.\n` +
      `• **Inversión Mínima:** Desde $50 MXN con liquidación directa al recolectar la cosecha.\n\n` +
      `*¿Te gustaría consultar detalles sobre algún cultivo en específico, los certificados NFT o cómo conectar tu billetera?*`
    : `**Milpa AI Smart Assistant**\n\n` +
      `I can assist you with all aspects of **Milpa Tech**:\n\n` +
      `• **Available Crops:** Agave Espadin (25% yield), High-Altitude Coffee (18.2%), Native Corn (12.5%), and Hass Avocado (10.5%).\n` +
      `• **NFT Traceability:** Every crop is backed by Polygon smart contracts verifiable on **OpenSea**.\n` +
      `• **IoT & Satellite Monitoring:** Soil moisture, temperature, UV index, and NDVI vegetation health.\n` +
      `• **Minimum Ticket:** Starting at $50 MXN with direct liquidation upon harvest.\n\n` +
      `*Would you like more details on a specific crop, NFT certificates, or how to connect your wallet?*`;
}

/**
 * Clean up expired cache items
 */
function cleanExpiredCache() {
  const now = Date.now();
  for (const [key, entry] of responseCache.entries()) {
    if (now - entry.timestamp > CACHE_TTL_MS) {
      responseCache.delete(key);
    }
  }
}

/**
 * Returns active Gemini API key from environment
 */
export function getGeminiApiKey(): string | undefined {
  return process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
}

/**
 * Creates or retrieves a cached Gemini SDK instance
 */
let cachedGenAI: GoogleGenAI | null = null;
let lastUsedApiKey: string | null = null;

export function getGeminiClient(): GoogleGenAI | null {
  const key = getGeminiApiKey();
  if (!key) return null;

  if (!cachedGenAI || lastUsedApiKey !== key) {
    cachedGenAI = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
    lastUsedApiKey = key;
  }

  return cachedGenAI;
}

/**
 * Builds the comprehensive agricultural prompt for Milpa Tech
 */
export function buildSystemPrompt(lang: string = 'es', cropsContext?: any[], userContext?: any): string {
  const isEs = lang === 'es';
  return `
You are 'Milpa AI Assistant' (Asistente Agrícola Milpa), an expert AI consultant for the Milpa Tech platform.
Milpa Tech is a bilingual (Spanish/English) agricultural tokenization and regenerative farming platform in Mexico.

Platform Capabilities & Context:
- Allows investors to buy fractionated tokens of real agricultural crops in Mexico (Agave Angustifolia-Espadín, Maíz Criollo, Café de Altura, Aguacate Hass).
- Each crop is backed by verified OpenSea NFTs on Polygon/Ethereum for traceability and proof of ownership.
  Example: Agave Angustifolia-Espadin de Oaxaca is linked to OpenSea NFT: https://opensea.io/item/polygon/0x88485aad41e74e69321e848d8e78e892c5a5315d/1 (Contract: 0x88485aad41e74e69321e848d8e78e892c5a5315d, Token ID: #1).
- Investors receive returns upon harvest based on agricultural yield and ESG sustainability scores.
- Producers get direct fair financing, satellite NDVI monitoring, and AI risk assessment.
- Current language: ${isEs ? 'Spanish (Español)' : 'English'}.
- Active crops in marketplace: ${JSON.stringify(cropsContext || [])}.
- Current user profile: ${JSON.stringify(userContext || {})}.

Your Directives:
1. Answer questions clearly about crops, token prices, returns, OpenSea NFT verification, regenerative agro-practices, and how to invest.
2. Use Google Search grounding when available for real-time agricultural commodities pricing, weather forecasts in Mexican farming hubs (Oaxaca, Chiapas, Michoacán, Puebla), and agro-tech news.
3. Keep responses structured with clear markdown bullet points, bold key terms, and scannable paragraphs.
4. Respond strictly in the user's requested language (${isEs ? 'Spanish' : 'English'}).
`;
}

/**
 * Cache key generation for query and history
 */
function computeCacheKey(message: string, lang: string = 'es'): string {
  return `${lang}:${message.trim().toLowerCase()}`;
}

/**
 * Execute chat generation with full caching and multi-tier fallbacks
 */
export async function executeGeminiChat(payload: ChatRequestPayload): Promise<ChatResponseResult> {
  const { message, history = [], lang = 'es', cropsContext = [], userContext = null } = payload;
  const isEs = lang === 'es';

  // 1. Check cache for quick return
  const cacheKey = computeCacheKey(message, lang);
  cleanExpiredCache();
  const cached = responseCache.get(cacheKey);
  if (cached && (Date.now() - cached.timestamp < CACHE_TTL_MS)) {
    return {
      reply: cached.reply,
      groundingChunks: cached.groundingChunks,
      source: 'cache'
    };
  }

  const ai = getGeminiClient();

  if (ai) {
    const systemPrompt = buildSystemPrompt(lang, cropsContext, userContext);
    const contents: any[] = [];

    // Append history
    if (Array.isArray(history) && history.length > 0) {
      history.slice(-8).forEach((h) => {
        if (h.role && h.text) {
          contents.push({
            role: h.role === 'user' ? 'user' : 'model',
            parts: [{ text: h.text }]
          });
        }
      });
    }
    contents.push({ role: 'user', parts: [{ text: message }] });

    // Primary Attempt: gemini-3.7-flash with Google Search Grounding
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: contents,
        config: {
          systemInstruction: systemPrompt,
          temperature: 0.7,
          tools: [{ googleSearch: {} }]
        }
      });

      const text = response.text || "";
      if (text) {
        const rawChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
        const groundingChunks = rawChunks
          .map((chunk: any) => ({
            title: chunk.web?.title || (isEs ? "Fuente Web" : "Web Source"),
            uri: chunk.web?.uri || ""
          }))
          .filter((c: any) => c.uri);

        // Store in cache
        if (responseCache.size >= MAX_CACHE_ENTRIES) {
          const firstKey = responseCache.keys().next().value;
          if (firstKey) responseCache.delete(firstKey);
        }
        responseCache.set(cacheKey, {
          reply: text,
          groundingChunks,
          timestamp: Date.now()
        });

        return {
          reply: text,
          groundingChunks,
          source: 'gemini-live'
        };
      }
    } catch (primaryErr: any) {
      console.warn("Primary Gemini Grounded call noticed error, falling back to direct fast inference:", primaryErr?.message || primaryErr);
      
      // Secondary Attempt: gemini-3.7-flash standard without search grounding
      try {
        const fallbackResponse = await ai.models.generateContent({
          model: "gemini-3.7-flash",
          contents: contents,
          config: {
            systemInstruction: systemPrompt,
            temperature: 0.7
          }
        });

        const text = fallbackResponse.text || "";
        if (text) {
          responseCache.set(cacheKey, {
            reply: text,
            groundingChunks: [],
            timestamp: Date.now()
          });

          return {
            reply: text,
            groundingChunks: [],
            source: 'gemini-live'
          };
        }
      } catch (secondaryErr: any) {
        console.warn("Secondary Gemini call failed, using domain agro-knowledge base:", secondaryErr?.message || secondaryErr);
      }
    }
  }

  // Tier 3: High quality Domain Fallback
  const fallbackText = generateDomainFallbackReply(message, lang, cropsContext);
  return {
    reply: fallbackText,
    groundingChunks: [],
    source: 'fallback'
  };
}

/**
 * Diagnostics & Health status for external server monitoring
 */
export function getGeminiDiagnostics() {
  const key = getGeminiApiKey();
  return {
    status: key ? "configured" : "fallback_only",
    hasApiKey: !!key,
    apiKeyMasked: key ? `${key.substring(0, 6)}...${key.substring(key.length - 4)}` : null,
    model: "gemini-3.7-flash",
    cachedEntriesCount: responseCache.size,
    groundingSupported: true,
    timestamp: new Date().toISOString()
  };
}
