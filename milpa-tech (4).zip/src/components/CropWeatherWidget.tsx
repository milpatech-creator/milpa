import React, { useState } from 'react';
import {
  Sun, CloudRain, Wind, Droplets, Thermometer, Sparkles, RefreshCw, AlertCircle, ShieldAlert
} from 'lucide-react';
import { WeatherCondition, Language } from '../types';

interface CropWeatherWidgetProps {
  weather?: WeatherCondition;
  location: string;
  lang: Language;
  onSimulateWeatherChange?: () => void;
  compact?: boolean;
}

export const CropWeatherWidget: React.FC<CropWeatherWidgetProps> = ({
  weather,
  location,
  lang,
  onSimulateWeatherChange,
  compact = false
}) => {
  // Default mock weather if not provided
  const currentWeather: WeatherCondition = weather || {
    tempC: 24.5,
    humidityPct: 62,
    rainfallMm: 2.4,
    soilMoisturePct: 48,
    condition: "Soleado con Microclima Ideal",
    conditionEn: "Sunny with Ideal Microclimate",
    uvIndex: 6
  };

  if (compact) {
    return (
      <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between text-xs gap-2">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/30">
            <Sun className="w-4 h-4" />
          </div>
          <div>
            <span className="font-extrabold text-white text-xs block">{currentWeather.tempC}°C</span>
            <span className="text-[10px] text-slate-400 font-medium">{location}</span>
          </div>
        </div>

        <div className="flex items-center gap-3 text-[11px]">
          <div className="flex items-center gap-1 text-cyan-300 font-bold" title="Humedad Relativa">
            <Droplets className="w-3.5 h-3.5 text-cyan-400" />
            <span>{currentWeather.humidityPct}%</span>
          </div>
          <div className="flex items-center gap-1 text-emerald-300 font-bold" title="Humedad del Suelo IoT">
            <Thermometer className="w-3.5 h-3.5 text-emerald-400" />
            <span>{currentWeather.soilMoisturePct}% Suelo</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950/60 p-5 rounded-2xl border border-emerald-500/30 shadow-xl space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40">
            <Sun className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-black uppercase tracking-widest text-emerald-400 flex items-center gap-1.5">
              <span>{lang === 'es' ? "Estación Meteorológica & Telemetría IoT" : "Weather Station & IoT Telemetry"}</span>
            </h4>
            <p className="text-xs font-bold text-white mt-0.5">{location}</p>
          </div>
        </div>

        {onSimulateWeatherChange && (
          <button
            onClick={onSimulateWeatherChange}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-emerald-300 border border-slate-700 transition-all text-xs flex items-center gap-1 font-bold"
            title={lang === 'es' ? "Simular fluctuación clima IoT" : "Simulate IoT weather update"}
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{lang === 'es' ? "Actualizar" : "Refresh"}</span>
          </button>
        )}
      </div>

      {/* Main Condition Banner */}
      <div className="flex items-center justify-between p-3.5 bg-slate-950/80 rounded-xl border border-slate-800">
        <div>
          <span className="text-2xl font-black text-white">{currentWeather.tempC}°C</span>
          <span className="text-xs text-slate-400 ml-2 font-mono">({((currentWeather.tempC * 9/5) + 32).toFixed(1)}°F)</span>
          <p className="text-xs font-bold text-emerald-300 mt-0.5">
            {lang === 'es' ? currentWeather.condition : currentWeather.conditionEn}
          </p>
        </div>

        <div className="text-right">
          <span className="px-2.5 py-1 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-[10px] font-black uppercase">
            {lang === 'es' ? "Microclima Óptimo" : "Optimal Microclimate"}
          </span>
          <span className="block text-[10px] text-slate-400 font-mono mt-1">
            UV Index: {currentWeather.uvIndex} / 12
          </span>
        </div>
      </div>

      {/* Telemetry Sensor Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
        {/* Humidity */}
        <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800 flex items-center gap-3">
          <div className="p-2 rounded-lg bg-cyan-950 text-cyan-400 border border-cyan-500/30">
            <Droplets className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase">{lang === 'es' ? "Humedad Aire" : "Air Humidity"}</span>
            <p className="font-extrabold text-white">{currentWeather.humidityPct}%</p>
          </div>
        </div>

        {/* Soil Moisture */}
        <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800 flex items-center gap-3">
          <div className="p-2 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-500/30">
            <Thermometer className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase">{lang === 'es' ? "Humedad Suelo" : "Soil Moisture"}</span>
            <p className="font-extrabold text-emerald-300">{currentWeather.soilMoisturePct}% (Ideal)</p>
          </div>
        </div>

        {/* Rainfall */}
        <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800 flex items-center gap-3 col-span-2 sm:col-span-1">
          <div className="p-2 rounded-lg bg-teal-950 text-teal-400 border border-teal-500/30">
            <CloudRain className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase">{lang === 'es' ? "Lluvia Acum." : "Rainfall"}</span>
            <p className="font-extrabold text-white">{currentWeather.rainfallMm} mm/24h</p>
          </div>
        </div>
      </div>

      {/* Insurance Parametric Status */}
      <div className="p-3 bg-emerald-950/40 rounded-xl border border-emerald-500/30 flex items-center gap-2.5 text-xs text-emerald-200">
        <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
        <p className="text-[11px] font-medium leading-tight">
          {lang === 'es'
            ? "Seguro Paramétrico Satelital Activo: El microclima actual está dentro de los umbrales normales de producción."
            : "Satellite Parametric Insurance Active: Current microclimate is within standard production bounds."}
        </p>
      </div>
    </div>
  );
};
