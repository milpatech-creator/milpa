import React, { useState, useRef, useEffect } from 'react';
import {
  Send, Bot, User, Sparkles, Loader2, Globe, ExternalLink,
  RefreshCw, X, Zap, CheckCircle2, Server
} from 'lucide-react';

interface Crop {
  id: string;
  name: string;
  producerName: string;
  location: string;
  type: string;
  imageUrl: string;
  description: string;
  riskLevel: string;
  tokenPrice: number;
  totalTokens: number;
  soldTokens: number;
  yieldProjection: number;
  harvestDate: string;
  sustainabilityScore: number;
  openseaUrl?: string;
  nftContract?: string;
  nftTokenId?: string;
  nftStandard?: string;
}

interface UserProfile {
  id: string;
  name: string;
  role: string;
  balance: number;
}

interface GroundingChunk {
  title: string;
  uri: string;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  groundingChunks?: GroundingChunk[];
  isError?: boolean;
  isStreaming?: boolean;
  source?: string;
}

interface AIChatBotProps {
  lang: 'es' | 'en';
  crops: Crop[];
  currentUser: UserProfile | null;
  isFloating?: boolean;
  onClose?: () => void;
}

const API_BASE = (import.meta as any).env?.VITE_API_URL || '';

export const AIChatBot: React.FC<AIChatBotProps> = ({
  lang,
  crops,
  currentUser,
  isFloating = false,
  onClose
}) => {
  const isEs = lang === 'es';

  const initialGreeting: ChatMessage = {
    id: 'init-1',
    sender: 'bot',
    text: isEs
      ? `¡Hola${currentUser ? ' ' + currentUser.name : ''}! 👋 Soy el **Asistente AI de Milpa Tech** con Gemini 3.7 optimizado para servidores de producción. Puedo responder tus dudas sobre cultivos tokenizados (como el Agave Angustifolia y sus NFTs en OpenSea), estimaciones de rendimiento, agricultura regenerativa o consultar precios agrícolas en tiempo real.`
      : `Hello${currentUser ? ' ' + currentUser.name : ''}! 👋 I am the **Milpa Tech AI Assistant** powered by Gemini 3.7 optimized for production servers. I can answer questions about our tokenized crops (like Agave Angustifolia and its OpenSea NFTs), yield projections, regenerative agriculture, or check live market prices & agricultural data.`,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  };

  const [messages, setMessages] = useState<ChatMessage[]>([initialGreeting]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [streamActive, setStreamActive] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickPrompts = isEs ? [
    "¿Cuál es el rendimiento proyectado del Agave Angustifolia y su NFT?",
    "Consultar precio actual del maíz y café en el mercado agrícola",
    "¿Qué cultivos tienen menor riesgo agrícola para invertir?",
    "Explicar cómo funciona la trazabilidad NFT en OpenSea de Milpa"
  ] : [
    "What is the projected yield of Agave Angustifolia and its NFT?",
    "Check current corn and coffee prices in the agricultural market",
    "Which crops have the lowest risk level for investment?",
    "Explain how Milpa NFT traceability works on OpenSea"
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading, streamActive]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const botMessageId = `bot-${Date.now()}`;
    const placeholderBotMsg: ChatMessage = {
      id: botMessageId,
      sender: 'bot',
      text: '',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isStreaming: true
    };

    setMessages(prev => [...prev, userMsg, placeholderBotMsg]);
    if (!textToSend) setInputText('');
    setIsLoading(true);
    setStreamActive(true);

    const historyPayload = messages
      .filter(m => !m.isError && m.text)
      .slice(-8)
      .map(m => ({
        role: m.sender === 'user' ? 'user' : 'model',
        text: m.text
      }));

    const payload = {
      message: query,
      history: historyPayload,
      lang,
      cropsContext: crops.map(c => ({
        name: c.name,
        type: c.type,
        location: c.location,
        tokenPrice: c.tokenPrice,
        yieldProjection: c.yieldProjection,
        riskLevel: c.riskLevel,
        openseaUrl: c.openseaUrl,
        nftContract: c.nftContract,
        nftTokenId: c.nftTokenId
      })),
      userContext: currentUser ? {
        name: currentUser.name,
        role: currentUser.role,
        balance: currentUser.balance
      } : null
    };

    let accumulatedText = '';
    let streamSuccess = false;

    // 1. Try High-Performance Real-Time SSE Stream Endpoint
    try {
      const response = await fetch(`${API_BASE}/api/ai/chat/stream`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (response.ok && response.body) {
        const reader = response.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let buffer = '';

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n\n');
          buffer = lines.pop() || '';

          for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.startsWith('data: ')) {
              try {
                const parsed = JSON.parse(trimmed.slice(6));
                if (parsed.chunk) {
                  accumulatedText += parsed.chunk;
                  setMessages(prev =>
                    prev.map(m =>
                      m.id === botMessageId
                        ? { ...m, text: accumulatedText, isStreaming: !parsed.done }
                        : m
                    )
                  );
                }
                if (parsed.done) {
                  streamSuccess = true;
                  setMessages(prev =>
                    prev.map(m =>
                      m.id === botMessageId
                        ? { ...m, text: accumulatedText || m.text, isStreaming: false, source: parsed.source }
                        : m
                    )
                  );
                }
              } catch (parseErr) {
                // Ignore parse errors on partial chunks
              }
            }
          }
        }
      }
    } catch (streamErr) {
      console.warn("Stream connection interrupted, switching to fallback JSON endpoint:", streamErr);
    }

    // 2. Fallback to standard JSON endpoint if stream was not fulfilled
    if (!streamSuccess || !accumulatedText.trim()) {
      try {
        const res = await fetch(`${API_BASE}/api/ai/chat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        if (res.ok) {
          const data = await res.json();
          setMessages(prev =>
            prev.map(m =>
              m.id === botMessageId
                ? {
                    ...m,
                    text: data.reply || (isEs ? "Respuesta completada." : "Response completed."),
                    groundingChunks: data.groundingChunks || [],
                    isStreaming: false,
                    source: data.source
                  }
                : m
            )
          );
        } else {
          throw new Error(`Server returned status ${res.status}`);
        }
      } catch (err: any) {
        console.error("Chat API error:", err);
        setMessages(prev =>
          prev.map(m =>
            m.id === botMessageId
              ? {
                  ...m,
                  text: isEs
                    ? "⚠️ No fue posible conectar con el servidor de IA. Se activó el respaldo local."
                    : "⚠️ Could not connect to the AI server. Local fallback was activated.",
                  isError: true,
                  isStreaming: false
                }
              : m
          )
        );
      }
    }

    setIsLoading(false);
    setStreamActive(false);
  };

  const renderFormattedText = (text: string) => {
    const paragraphs = (text || '').split('\n\n');
    return paragraphs.map((paragraph, idx) => {
      const parts = paragraph.split(/(\*\*.*?\*\*)/g);
      return (
        <p key={idx} className="mb-2 last:mb-0 leading-relaxed">
          {parts.map((part, pIdx) => {
            if (part.startsWith('**') && part.endsWith('**')) {
              return <strong key={pIdx} className="font-extrabold text-slate-900 dark:text-white">{part.slice(2, -2)}</strong>;
            }
            return part;
          })}
        </p>
      );
    });
  };

  return (
    <div className={`flex flex-col bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden ${
      isFloating ? 'h-[600px] w-full max-w-lg' : 'h-[680px] w-full'
    }`}>
      {/* Header Bar */}
      <div className="bg-gradient-to-r from-emerald-900 via-green-900 to-slate-900 text-white p-4 sm:p-5 flex items-center justify-between shadow-md shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shadow-inner">
            <Bot className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-sm sm:text-base tracking-tight text-white">
                {isEs ? "Asistente Agrícola Milpa AI" : "Milpa AI Assistant"}
              </h3>
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                <Zap className="h-3 w-3 text-amber-300" /> Gemini 3.7 Turbo
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-emerald-200/80 mt-0.5">
              <span className="flex items-center gap-1">
                <Globe className="h-3 w-3 text-emerald-400" />
                {isEs ? "Google Search Grounding" : "Google Search Grounding"}
              </span>
              <span className="text-emerald-400/50">•</span>
              <span className="flex items-center gap-1 text-[11px] text-emerald-300 font-mono">
                <Server className="h-3 w-3 text-emerald-400" />
                {isEs ? "Servidor Optimizado" : "Optimized Server"}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setMessages([initialGreeting])}
            className="p-2 hover:bg-white/10 rounded-xl text-emerald-200 hover:text-white transition-colors"
            title={isEs ? "Reiniciar Conversación" : "Reset Conversation"}
          >
            <RefreshCw className="h-4 w-4" />
          </button>
          {isFloating && onClose && (
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-xl text-slate-300 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          )}
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-slate-50/50">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-3 max-w-[88%] ${msg.sender === 'user' ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${
              msg.sender === 'user'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-900 text-emerald-400 border border-emerald-500/30'
            }`}>
              {msg.sender === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
            </div>

            <div className={`space-y-2 text-xs sm:text-sm ${msg.sender === 'user' ? 'text-right' : 'text-left'}`}>
              <div className={`p-4 rounded-2xl shadow-sm leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-emerald-600 text-white rounded-tr-none font-medium'
                  : msg.isError
                    ? 'bg-red-50 text-red-800 border border-red-200 rounded-tl-none'
                    : 'bg-white text-slate-800 border border-slate-200/80 rounded-tl-none shadow-slate-100'
              }`}>
                {msg.text ? (
                  <>
                    {renderFormattedText(msg.text)}
                    {msg.isStreaming && (
                      <span className="inline-block w-2 h-4 ml-1 bg-emerald-600 animate-pulse align-middle" />
                    )}
                  </>
                ) : (
                  <div className="flex items-center gap-2 text-slate-400 py-1">
                    <Loader2 className="h-4 w-4 animate-spin text-emerald-600" />
                    <span>{isEs ? "Generando respuesta en tiempo real..." : "Streaming real-time response..."}</span>
                  </div>
                )}
              </div>

              {/* Grounding Web Sources Chunks */}
              {msg.groundingChunks && msg.groundingChunks.length > 0 && (
                <div className="bg-emerald-50/80 border border-emerald-200/80 rounded-xl p-3 text-left space-y-1.5 animate-fade-in">
                  <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-800 uppercase tracking-wider">
                    <Globe className="h-3.5 w-3.5 text-emerald-600" />
                    <span>{isEs ? "Fuentes verificadas en Google:" : "Verified Google Sources:"}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {msg.groundingChunks.map((chunk, cIdx) => (
                      <a
                        key={cIdx}
                        href={chunk.uri}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-emerald-100/80 text-emerald-900 border border-emerald-200 rounded-lg text-[11px] font-semibold transition-colors shadow-xs"
                      >
                        <span className="truncate max-w-[180px]">{chunk.title}</span>
                        <ExternalLink className="h-3 w-3 shrink-0 text-emerald-600" />
                      </a>
                    ))}
                  </div>
                </div>
              )}

              <span className="block text-[10px] text-slate-400 font-mono px-1">
                {msg.timestamp}
              </span>
            </div>
          </div>
        ))}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Prompts */}
      <div className="p-3 bg-slate-100/80 border-t border-slate-200 shrink-0">
        <p className="text-[10px] uppercase font-extrabold text-slate-500 tracking-wider mb-2 px-1">
          {isEs ? "Preguntas Frecuentes Sugeridas:" : "Suggested Questions:"}
        </p>
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
          {quickPrompts.map((promptText, pIdx) => (
            <button
              key={pIdx}
              onClick={() => handleSendMessage(promptText)}
              disabled={isLoading}
              className="px-3 py-1.5 bg-white hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 border border-slate-200 hover:border-emerald-300 rounded-xl text-xs font-medium whitespace-nowrap transition-all shadow-xs shrink-0 disabled:opacity-50"
            >
              {promptText}
            </button>
          ))}
        </div>
      </div>

      {/* Input Control Box */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="p-3 sm:p-4 bg-white border-t border-slate-200 flex gap-2 items-center shrink-0"
      >
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={isEs ? "Pregunta sobre cultivos, NFTs o mercado..." : "Ask about crops, NFTs, or markets..."}
          disabled={isLoading}
          className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:bg-white transition-all text-slate-800"
        />
        <button
          type="submit"
          disabled={!inputText.trim() || isLoading}
          className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-300 text-white font-bold rounded-2xl transition-all shadow-md shadow-emerald-600/20 flex items-center justify-center shrink-0"
        >
          {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </button>
      </form>
    </div>
  );
};

