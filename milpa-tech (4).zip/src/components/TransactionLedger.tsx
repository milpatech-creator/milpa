import React, { useState } from 'react';
import {
  Coins, ArrowUpRight, ArrowDownLeft, ShieldCheck, Search, Filter,
  ExternalLink, Copy, Check, RefreshCw, Zap, Download, Layers,
  CheckCircle2, FileText, Lock
} from 'lucide-react';
import { Transaction, Language } from '../types';

interface TransactionLedgerProps {
  transactions?: Transaction[];
  lang: Language;
  onSimulateTransaction?: () => void;
  isOpenModal?: boolean;
  onCloseModal?: () => void;
}

export const TransactionLedger: React.FC<TransactionLedgerProps> = ({
  transactions = [],
  lang,
  onSimulateTransaction,
  isOpenModal = false,
  onCloseModal
}) => {
  const [filterType, setFilterType] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedHash, setCopiedHash] = useState<string | null>(null);

  const safeTransactions = transactions || [];

  const handleCopyHash = (hash: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedHash(hash);
    setTimeout(() => setCopiedHash(null), 2000);
  };

  const filteredTransactions = safeTransactions.filter((tx) => {
    if (!tx) return false;
    const matchesType = filterType === 'ALL' || tx.type === filterType;
    const matchesSearch =
      (tx.cropName || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (tx.txHash || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (tx.userName && tx.userName.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesType && matchesSearch;
  });

  const totalVolume = safeTransactions.reduce((acc, t) => acc + (t?.total || 0), 0);

  const content = (
    <div className="space-y-6">
      
      {/* Top Banner Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 p-4 rounded-2xl border border-emerald-500/30 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              {lang === 'es' ? "Volumen Total en Red" : "Total Network Volume"}
            </span>
            <p className="text-xl font-black text-emerald-400 font-mono mt-0.5">
              ${totalVolume.toLocaleString('en-US', { minimumFractionDigits: 2 })} USD
            </p>
          </div>
          <div className="p-3 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-500/30">
            <Coins className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900 p-4 rounded-2xl border border-emerald-500/30 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              {lang === 'es' ? "Transacciones Registradas" : "Recorded Transactions"}
            </span>
            <p className="text-xl font-black text-white font-mono mt-0.5">
              {transactions.length} {lang === 'es' ? "Bloques" : "Blocks"}
            </p>
          </div>
          <div className="p-3 rounded-xl bg-cyan-950 text-cyan-400 border border-cyan-500/30">
            <Layers className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900 p-4 rounded-2xl border border-emerald-500/30 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              {lang === 'es' ? "Estado de Consenso" : "Consensus Status"}
            </span>
            <p className="text-sm font-extrabold text-emerald-300 mt-1 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>{lang === 'es' ? "Trazabilidad Inmutable" : "Immutable Ledger"}</span>
            </p>
          </div>
          <div className="p-3 rounded-xl bg-teal-950 text-teal-400 border border-teal-500/30">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
        
        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder={lang === 'es' ? "Buscar por cultivo, usuario o hash..." : "Search crop, user or tx hash..."}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
          {['ALL', 'BUY', 'SELL', 'FUND', 'MINT'].map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase transition-all whitespace-nowrap ${
                filterType === type
                  ? 'bg-emerald-600 text-white shadow-lg'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {type === 'ALL'
                ? (lang === 'es' ? 'Todas' : 'All')
                : type === 'BUY'
                ? (lang === 'es' ? 'Compra' : 'Buy')
                : type === 'SELL'
                ? (lang === 'es' ? 'Venta' : 'Sell')
                : type === 'FUND'
                ? (lang === 'es' ? 'Fondo' : 'Fund')
                : 'Mint NFT'}
            </button>
          ))}
        </div>

        {/* Action Button */}
        {onSimulateTransaction && (
          <button
            onClick={onSimulateTransaction}
            className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black rounded-xl flex items-center justify-center gap-2 transition-all shadow-md active:scale-95 shrink-0"
          >
            <Zap className="w-3.5 h-3.5 text-amber-300" />
            <span>{lang === 'es' ? "Simular Compra en Vivo" : "Simulate Live Purchase"}</span>
          </button>
        )}
      </div>

      {/* Transactions Table / List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase font-extrabold border-b border-slate-800 text-[10px] tracking-wider">
              <tr>
                <th className="px-4 py-3">{lang === 'es' ? "Operación / Tipo" : "Operation / Type"}</th>
                <th className="px-4 py-3">{lang === 'es' ? "Cultivo / Insumo" : "Crop / Item"}</th>
                <th className="px-4 py-3">{lang === 'es' ? "Método de Pago" : "Payment Method"}</th>
                <th className="px-4 py-3 text-right">{lang === 'es' ? "Tokens/Cant" : "Qty"}</th>
                <th className="px-4 py-3 text-right">{lang === 'es' ? "Monto Total" : "Total Amount"}</th>
                <th className="px-4 py-3">{lang === 'es' ? "Fecha" : "Date"}</th>
                <th className="px-4 py-3 text-center">{lang === 'es' ? "Hash Bloque" : "Tx Hash"}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {filteredTransactions.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-8 text-center text-slate-500 text-xs">
                    {lang === 'es' ? "No hay transacciones registradas con este filtro." : "No transactions match this filter."}
                  </td>
                </tr>
              ) : (
                filteredTransactions.map((tx) => {
                  const isBuy = tx.type === 'BUY' || tx.type === 'MARKETPLACE_BUY';
                  const isFund = tx.type === 'FUND' || tx.type === 'WALLET_RECHARGE';
                  const isMint = tx.type === 'MINT';

                  return (
                    <tr key={tx.id} className="hover:bg-slate-950/60 transition-colors">
                      {/* Operation Type */}
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black uppercase border ${
                          isBuy
                            ? 'bg-emerald-950 text-emerald-300 border-emerald-500/40'
                            : isFund
                            ? 'bg-cyan-950 text-cyan-300 border-cyan-500/40'
                            : isMint
                            ? 'bg-amber-950 text-amber-300 border-amber-500/40'
                            : 'bg-rose-950 text-rose-300 border-rose-500/40'
                        }`}>
                          {isBuy ? <ArrowDownLeft className="w-3 h-3 text-emerald-400" /> : <ArrowUpRight className="w-3 h-3 text-cyan-400" />}
                          {tx.type}
                        </span>
                      </td>

                      {/* Crop Name */}
                      <td className="px-4 py-3 whitespace-nowrap font-extrabold text-white">
                        {tx.cropName}
                        {tx.userName && (
                          <span className="block text-[10px] text-slate-400 font-normal">
                            {lang === 'es' ? "Por:" : "By:"} {tx.userName}
                          </span>
                        )}
                      </td>

                      {/* Payment Method Badge */}
                      <td className="px-4 py-3 whitespace-nowrap">
                        {tx.cardBrand ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-800 text-slate-200 text-[10px] font-bold border border-slate-700">
                            {tx.cardBrand === 'VISA' && <span className="text-blue-400 font-black italic">VISA</span>}
                            {tx.cardBrand === 'MASTERCARD' && <span className="text-red-400 font-black">MC</span>}
                            {tx.cardBrand === 'AMEX' && <span className="text-cyan-400 font-black">AMEX</span>}
                            <span>•••• {tx.cardLast4 || '8821'}</span>
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400 font-medium flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                            <span>{lang === 'es' ? 'Saldo Milpa' : 'Milpa Wallet'}</span>
                          </span>
                        )}
                      </td>

                      {/* Amount */}
                      <td className="px-4 py-3 text-right font-mono font-bold text-slate-200 whitespace-nowrap">
                        {tx.amount?.toLocaleString() || 1}
                      </td>

                      {/* Total */}
                      <td className="px-4 py-3 text-right font-mono font-black text-emerald-400 whitespace-nowrap">
                        ${tx.total?.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </td>

                      {/* Date */}
                      <td className="px-4 py-3 whitespace-nowrap text-slate-400 text-[11px]">
                        {tx.date}
                      </td>

                      {/* Tx Hash */}
                      <td className="px-4 py-3 text-center whitespace-nowrap">
                        <button
                          onClick={() => handleCopyHash(tx.txHash)}
                          className="px-2 py-1 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-700 text-emerald-400 font-mono text-[10px] flex items-center justify-center gap-1.5 mx-auto transition-all"
                          title={lang === 'es' ? "Copiar Tx Hash" : "Copy Tx Hash"}
                        >
                          {copiedHash === tx.txHash ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" />
                              <span className="text-emerald-300">¡Copiado!</span>
                            </>
                          ) : (
                            <>
                              <span>{tx.txHash?.slice(0, 6)}...{tx.txHash?.slice(-4)}</span>
                              <Copy className="w-3 h-3 text-slate-500" />
                            </>
                          )}
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );

  if (isOpenModal) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-fade-in">
        <div className="relative w-full max-w-5xl bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 max-h-[85vh] overflow-y-auto">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-emerald-950 text-emerald-400 border border-emerald-500/40">
                <Coins className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-black text-white">{lang === 'es' ? "Registro General de Transacciones Blockchain" : "General Blockchain Transaction Ledger"}</h2>
                <p className="text-xs text-slate-400">{lang === 'es' ? "Trazabilidad financiera inmutable de tokens y financiamiento agrícola" : "Immutable financial audit log for tokens & agricultural funding"}</p>
              </div>
            </div>

            {onCloseModal && (
              <button
                onClick={onCloseModal}
                className="p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                ✕
              </button>
            )}
          </div>

          {content}
        </div>
      </div>
    );
  }

  return content;
};
