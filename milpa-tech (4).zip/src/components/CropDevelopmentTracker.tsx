import React, { useState } from 'react';
import {
  Sprout, CheckCircle2, ShieldCheck, Calendar, Activity, FileText,
  Plus, Plane, Radio, AlertTriangle, Layers, Send
} from 'lucide-react';
import { CropDevelopment, DevelopmentLog, Language } from '../types';

interface CropDevelopmentTrackerProps {
  development?: CropDevelopment;
  cropName: string;
  isProducer?: boolean;
  lang: Language;
  onAddLogEvent?: (log: DevelopmentLog, newProgressPct?: number) => void;
}

const PHENOLOGICAL_STAGES = [
  { id: 1, name: "Siembra y Germinación", nameEn: "Sowing & Germination", minPct: 0, maxPct: 20 },
  { id: 2, name: "Crecimiento Vegetativo", nameEn: "Vegetative Growth", minPct: 21, maxPct: 50 },
  { id: 3, name: "Floración y Llenado", nameEn: "Flowering & Filling", minPct: 51, maxPct: 80 },
  { id: 4, name: "Maduración y Secado", nameEn: "Maturation & Drying", minPct: 81, maxPct: 95 },
  { id: 5, name: "Listo para Cosecha", nameEn: "Harvest Ready", minPct: 96, maxPct: 100 }
];

export const CropDevelopmentTracker: React.FC<CropDevelopmentTrackerProps> = ({
  development,
  cropName,
  isProducer = false,
  lang,
  onAddLogEvent
}) => {
  const currentDev: CropDevelopment = development || {
    stage: "Crecimiento Vegetativo & Llenado de Grano",
    stageEn: "Vegetative Growth & Grain Filling",
    progressPct: 65,
    daysToHarvest: 85,
    healthScore: 96,
    lastUpdateDate: "Hoy, 10:30 AM",
    updateNote: "Desarrollo radicular óptimo. Monitoreo por dron confirma follaje vigoroso y cero plagas.",
    updateNoteEn: "Optimal root development. Drone monitoring confirms vigorous foliage and zero pests.",
    logEvents: [
      {
        date: "15 Ago 2026",
        title: "Escaneo con Dron Multiespectral",
        description: "Índice NDVI de vegetación en 0.88. Salud foliar máxima.",
        type: "DRONE"
      },
      {
        date: "01 Ago 2026",
        title: "Inspección Agronómica de Suelo",
        description: "Aplicación de compost de biochar y microorganismos benéficos.",
        type: "INSPECTION"
      },
      {
        date: "10 Jul 2026",
        title: "Registro de Germinación 100%",
        description: "Tasa de brote exitosa en el 100% de la parcela sin incidentes.",
        type: "BIODYNAMICS"
      }
    ]
  };

  // State for Producer new log submission
  const [showAddLog, setShowAddLog] = useState(false);
  const [logTitle, setLogTitle] = useState('');
  const [logDesc, setLogDesc] = useState('');
  const [logType, setLogType] = useState<'IOT' | 'INSPECTION' | 'WEATHER' | 'DRONE' | 'BIODYNAMICS'>('INSPECTION');
  const [newProgress, setNewProgress] = useState(currentDev.progressPct);

  const getCurrentStageObj = () => {
    return PHENOLOGICAL_STAGES.find(s => currentDev.progressPct >= s.minPct && currentDev.progressPct <= s.maxPct) || PHENOLOGICAL_STAGES[2];
  };

  const handleLogSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!logTitle.trim() || !logDesc.trim()) return;

    const newLog: DevelopmentLog = {
      date: new Date().toLocaleDateString(lang === 'es' ? 'es-MX' : 'en-US', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      }),
      title: logTitle.trim(),
      description: logDesc.trim(),
      type: logType
    };

    if (onAddLogEvent) {
      onAddLogEvent(newLog, newProgress);
    }

    setLogTitle('');
    setLogDesc('');
    setShowAddLog(false);
  };

  return (
    <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-5 sm:p-6 shadow-2xl space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-500/40">
              <Sprout className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-base font-black text-white">{lang === 'es' ? "Desarrollo del Cultivo & Fenología" : "Crop Development & Phenology"}</h3>
              <p className="text-xs text-slate-400 font-bold">{cropName}</p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-black flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-emerald-400" />
            <span>{lang === 'es' ? "Índice Salud:" : "Health Score:"}</span>
            <span className="text-amber-400 font-mono text-sm">{currentDev.healthScore}%</span>
          </div>

          <div className="px-3 py-1.5 rounded-xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-black flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-cyan-400" />
            <span>{currentDev.daysToHarvest} {lang === 'es' ? "días p/ cosechar" : "days to harvest"}</span>
          </div>
        </div>
      </div>

      {/* Main Phenological Progress Bar */}
      <div className="space-y-3 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div className="flex items-center justify-between text-xs">
          <span className="font-extrabold text-emerald-300 uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            {lang === 'es' ? "Etapa Actual:" : "Current Stage:"} {lang === 'es' ? currentDev.stage : currentDev.stageEn}
          </span>
          <span className="font-mono text-amber-400 font-black text-sm">{currentDev.progressPct}%</span>
        </div>

        {/* Progress Bar Container */}
        <div className="w-full h-4 bg-slate-900 rounded-full overflow-hidden border border-slate-700 p-0.5 relative">
          <div
            className="h-full bg-gradient-to-r from-emerald-600 via-green-500 to-teal-400 rounded-full transition-all duration-700 shadow-lg relative"
            style={{ width: `${currentDev.progressPct}%` }}
          >
            <div className="absolute right-0 top-0 bottom-0 w-2 bg-white/60 animate-pulse rounded-full"></div>
          </div>
        </div>

        {/* Phenological Steps */}
        <div className="grid grid-cols-5 gap-1 pt-2">
          {PHENOLOGICAL_STAGES.map((s) => {
            const isPassed = currentDev.progressPct >= s.maxPct;
            const isCurrent = currentDev.progressPct >= s.minPct && currentDev.progressPct <= s.maxPct;

            return (
              <div key={s.id} className="text-center space-y-1">
                <div className={`mx-auto w-3 h-3 rounded-full border-2 transition-all ${
                  isPassed
                    ? 'bg-emerald-500 border-emerald-400'
                    : isCurrent
                    ? 'bg-amber-400 border-white ring-2 ring-amber-500/50 scale-125'
                    : 'bg-slate-800 border-slate-700'
                }`} />
                <span className={`text-[10px] block font-bold leading-tight ${
                  isCurrent ? 'text-amber-400 font-black' : isPassed ? 'text-emerald-300' : 'text-slate-500'
                }`}>
                  {lang === 'es' ? s.name : s.nameEn}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Producer Latest Field Note */}
      <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 text-xs space-y-1.5">
        <div className="flex items-center justify-between">
          <span className="font-bold text-slate-400 flex items-center gap-1">
            <FileText className="w-3.5 h-3.5 text-emerald-400" />
            {lang === 'es' ? "Último Reportización de Campo:" : "Latest Field Report:"}
          </span>
          <span className="text-[10px] font-mono text-slate-500">{currentDev.lastUpdateDate}</span>
        </div>
        <p className="text-slate-200 italic leading-relaxed">
          "{lang === 'es' ? currentDev.updateNote : currentDev.updateNoteEn}"
        </p>
      </div>

      {/* Log Events History */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-black uppercase text-emerald-400 tracking-wider">
            {lang === 'es' ? "Bitácora Agronómica & Trazabilidad" : "Agronomic Log & Traceability"}
          </h4>

          {isProducer && (
            <button
              onClick={() => setShowAddLog(!showAddLog)}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black flex items-center gap-1.5 transition-all shadow-md"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{lang === 'es' ? "Agregar Evento" : "Add Event"}</span>
            </button>
          )}
        </div>

        {/* Add Log Form */}
        {showAddLog && (
          <form onSubmit={handleLogSubmit} className="bg-slate-950 p-4 rounded-xl border border-emerald-500/40 space-y-3 animate-fade-in text-xs">
            <h5 className="font-bold text-emerald-300">{lang === 'es' ? "Registrar Nuevo Avance de Campo" : "Log Field Update"}</h5>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <input
                type="text"
                required
                placeholder={lang === 'es' ? "Título del evento (p. ej. Aplicación de compost)" : "Event title"}
                value={logTitle}
                onChange={(e) => setLogTitle(e.target.value)}
                className="bg-slate-900 border border-slate-700 rounded-lg p-2 text-white focus:outline-none focus:border-emerald-500"
              />

              <select
                value={logType}
                onChange={(e) => setLogType(e.target.value as any)}
                className="bg-slate-900 border border-slate-700 rounded-lg p-2 text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="INSPECTION">Inspección Agronómica</option>
                <option value="DRONE">Monitoreo con Dron</option>
                <option value="IOT">Sensor Telemetría IoT</option>
                <option value="WEATHER">Evento Climático</option>
                <option value="BIODYNAMICS">Práctica Biodinámica</option>
              </select>
            </div>

            <textarea
              required
              rows={2}
              placeholder={lang === 'es' ? "Detalles del hallazgo, salud foliar o actividades realizadas..." : "Details of findings..."}
              value={logDesc}
              onChange={(e) => setLogDesc(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white focus:outline-none focus:border-emerald-500"
            />

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-slate-400 font-bold">{lang === 'es' ? "Progreso (%)" : "Progress (%):"}</span>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={newProgress}
                  onChange={(e) => setNewProgress(Number(e.target.value))}
                  className="w-20 bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-white font-mono"
                />
              </div>

              <button
                type="submit"
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-lg text-xs"
              >
                {lang === 'es' ? "Publicar en Bitácora" : "Post Log Entry"}
              </button>
            </div>
          </form>
        )}

        {/* Timeline Log List */}
        <div className="space-y-2.5">
          {currentDev.logEvents.map((log, index) => (
            <div key={index} className="p-3 bg-slate-950/70 rounded-xl border border-slate-800 flex items-start gap-3">
              <div className="p-2 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-500/30 shrink-0 mt-0.5">
                {log.type === 'DRONE' && <Plane className="w-4 h-4 text-cyan-400" />}
                {log.type === 'IOT' && <Radio className="w-4 h-4 text-amber-400" />}
                {log.type === 'INSPECTION' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                {log.type === 'WEATHER' && <AlertTriangle className="w-4 h-4 text-teal-400" />}
                {log.type === 'BIODYNAMICS' && <Sprout className="w-4 h-4 text-green-400" />}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-white truncate">{log.title}</span>
                  <span className="text-[10px] text-slate-500 font-mono">{log.date}</span>
                </div>
                <p className="text-xs text-slate-300 mt-0.5 leading-snug">{log.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
