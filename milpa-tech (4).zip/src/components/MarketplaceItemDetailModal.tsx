import React, { useState } from 'react';
import {
  X, ShieldCheck, CheckCircle2, ShoppingBag, MapPin, DollarSign,
  Package, Truck, Award, Lock, MessageSquare, AlertCircle,
  Sparkles, Check, Phone, Mail, FileText, CreditCard, Coins, Zap
} from 'lucide-react';
import { MarketplaceItem, UserProfile, Language, Transaction, PaymentReceipt } from '../types';
import { db, sanitizeForFirestore } from '../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { CardPaymentForm } from './CardPaymentForm';
import { PaymentReceiptModal } from './PaymentReceiptModal';

interface MarketplaceItemDetailModalProps {
  item: MarketplaceItem | null;
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  lang: Language;
  onBuyItem: (item: MarketplaceItem, quantity: number, total: number) => void;
  onContactSeller: (sellerUser: UserProfile) => void;
}

export const MarketplaceItemDetailModal: React.FC<MarketplaceItemDetailModalProps> = ({
  item,
  isOpen,
  onClose,
  currentUser,
  lang,
  onBuyItem,
  onContactSeller
}) => {
  if (!isOpen || !item) return null;

  const isEs = lang === 'es';
  const [quantity, setQuantity] = useState<number>(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [purchaseSuccess, setPurchaseSuccess] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'CARD' | 'WALLET' | 'CRYPTO'>('CARD');
  const [receiptData, setReceiptData] = useState<PaymentReceipt | null>(null);
  const [showReceipt, setShowReceipt] = useState(false);

  const totalPrice = quantity * item.priceMxn;

  // Handle Card Payment Completion
  const handleCardPaymentSuccess = async (cardData: {
    cardBrand: 'VISA' | 'MASTERCARD' | 'AMEX';
    cardType: 'CREDIT' | 'DEBIT';
    last4: string;
    cardholder: string;
    authCode: string;
    installments: number;
  }) => {
    setIsProcessing(true);
    try {
      const txId = `tx-mkt-card-${Date.now()}`;
      const txHash = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
      const timestamp = new Date().toLocaleString(isEs ? 'es-MX' : 'en-US');

      const tx: Transaction = {
        id: txId,
        cropName: `${item.title} (${quantity} ${item.unit})`,
        userName: currentUser?.name || cardData.cardholder,
        userRole: currentUser?.role || 'TRADER',
        amount: quantity,
        price: item.priceMxn,
        total: totalPrice,
        date: timestamp,
        type: 'MARKETPLACE_BUY',
        txHash,
        paymentMethod: cardData.cardBrand === 'VISA' ? 'CARD_VISA' : cardData.cardBrand === 'MASTERCARD' ? 'CARD_MASTERCARD' : 'CARD_AMEX',
        cardBrand: cardData.cardBrand,
        cardLast4: cardData.last4,
        authCode: cardData.authCode,
        installments: cardData.installments
      };

      try {
        await setDoc(doc(db, 'transactions', txId), sanitizeForFirestore(tx));
      } catch (e) {
        console.warn("Firestore marketplace purchase sync notice:", e);
      }

      onBuyItem(item, quantity, totalPrice);

      const receipt: PaymentReceipt = {
        transactionId: txId,
        authCode: cardData.authCode,
        amountMxn: totalPrice,
        itemDescription: `${item.title} (x${quantity} ${item.unit}) - ${item.category}`,
        paymentMethod: cardData.cardBrand === 'VISA' ? 'CARD_VISA' : cardData.cardBrand === 'MASTERCARD' ? 'CARD_MASTERCARD' : 'CARD_AMEX',
        cardLast4: cardData.last4,
        cardBrand: cardData.cardBrand,
        installments: cardData.installments,
        timestamp,
        txHash
      };

      setReceiptData(receipt);
      setShowReceipt(true);
    } catch (err) {
      console.error(err);
      alert(isEs ? "Error al procesar el pago con tarjeta." : "Error processing card payment.");
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle Wallet / Escrow Direct Purchase
  const handleWalletPurchase = async () => {
    if (currentUser && currentUser.balance < totalPrice) {
      alert(isEs ? `Saldo insuficiente en tu Billetera Milpa ($${currentUser.balance.toLocaleString()} MXN). Puedes pagar con Tarjeta VISA / Mastercard / AMEX.` : "Insufficient wallet balance. Please use a credit or debit card.");
      setPaymentMethod('CARD');
      return;
    }

    setIsProcessing(true);
    try {
      const txId = `tx-mkt-wallet-${Date.now()}`;
      const txHash = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
      const timestamp = new Date().toLocaleString(isEs ? 'es-MX' : 'en-US');

      const tx: Transaction = {
        id: txId,
        cropName: `${item.title} (${quantity} ${item.unit})`,
        userName: currentUser?.name || (isEs ? "Comprador Marketplace" : "Marketplace Buyer"),
        userRole: currentUser?.role || 'TRADER',
        amount: quantity,
        price: item.priceMxn,
        total: totalPrice,
        date: timestamp,
        type: 'MARKETPLACE_BUY',
        txHash,
        paymentMethod: 'WALLET_BALANCE'
      };

      try {
        await setDoc(doc(db, 'transactions', txId), sanitizeForFirestore(tx));
      } catch (e) {
        console.warn("Firestore marketplace purchase sync notice:", e);
      }

      onBuyItem(item, quantity, totalPrice);

      const receipt: PaymentReceipt = {
        transactionId: txId,
        authCode: `WALLET-AUTH-${Math.floor(100000 + Math.random() * 900000)}`,
        amountMxn: totalPrice,
        itemDescription: `${item.title} (x${quantity} ${item.unit})`,
        paymentMethod: 'WALLET_BALANCE',
        timestamp,
        txHash
      };

      setReceiptData(receipt);
      setShowReceipt(true);
    } catch (err) {
      console.error(err);
      alert(isEs ? "Error al procesar la compra." : "Error processing purchase.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
        <div className="bg-white border border-slate-200 rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden my-6">
          
          {/* Item Image & Header Banner */}
          <div className="relative h-56 w-full bg-slate-900 overflow-hidden">
            <img
              src={item.imageUrl}
              alt={item.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
            
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-white bg-slate-950/60 hover:bg-slate-950 p-2 rounded-full transition-colors backdrop-blur-sm"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="absolute bottom-4 left-4 right-4 text-white">
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <span className="bg-emerald-500 text-slate-950 font-bold text-[10px] uppercase px-2.5 py-0.5 rounded-full">
                  {item.category}
                </span>
                <span className="bg-slate-900/80 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-400/40 flex items-center gap-1">
                  <ShieldCheck className="h-3 w-3 text-emerald-400" />
                  {item.fraudScore || 98}% {isEs ? "Confiabilidad Anti-Fraude" : "Anti-Fraud Score"}
                </span>
                <span className="bg-blue-900/80 text-blue-200 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-blue-400/40 flex items-center gap-1">
                  <CreditCard className="h-3 w-3 text-blue-300" />
                  <span>VISA · Mastercard · AMEX</span>
                </span>
              </div>
              <h2 className="text-xl font-bold leading-tight">{item.title}</h2>
            </div>
          </div>

          {/* Content */}
          <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
            
            {/* Seller Card */}
            <div className="bg-slate-50 border border-slate-200/80 p-3.5 rounded-2xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-bold text-sm">
                  {item.sellerName.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="text-sm font-bold text-slate-900">{item.sellerName}</h4>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded">
                      {isEs ? "Vendedor Verificado" : "Verified Seller"}
                    </span>
                  </div>
                  {item.sellerLocation && (
                    <p className="text-xs text-slate-500 flex items-center gap-1">
                      <MapPin className="h-3 w-3 text-slate-400" />
                      <span>{item.sellerLocation}</span>
                    </p>
                  )}
                </div>
              </div>

              <button
                onClick={() => {
                  onContactSeller({
                    id: item.sellerId,
                    name: item.sellerName,
                    role: item.sellerRole,
                    balance: 10000,
                    avatar: item.sellerAvatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(item.sellerName)}`,
                    location: item.sellerLocation,
                    isVerifiedSeller: true
                  });
                  onClose();
                }}
                className="px-3 py-1.5 bg-white hover:bg-slate-100 text-emerald-700 border border-emerald-300 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
              >
                <MessageSquare className="h-3.5 w-3.5" />
                <span>{isEs ? "Negociar / Cotizar" : "Inquire"}</span>
              </button>
            </div>

            {/* Quantity Selector & Summary */}
            <div className="bg-slate-900 text-white p-4 rounded-2xl flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                  {isEs ? "Cantidad a Comprar:" : "Order Quantity:"}
                </span>
                <span className="text-xl font-black font-mono text-emerald-400">
                  ${totalPrice.toLocaleString()} MXN
                </span>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  (${item.priceMxn.toLocaleString()} MXN / {item.unit})
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold flex items-center justify-center border border-slate-700"
                >
                  -
                </button>
                <span className="w-12 text-center font-mono font-bold text-lg">{quantity}</span>
                <button
                  type="button"
                  onClick={() => setQuantity(Math.min(item.availableStock, quantity + 1))}
                  className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold flex items-center justify-center border border-slate-700"
                >
                  +
                </button>
              </div>
            </div>

            {/* Smart Escrow Protection Notice */}
            <div className="bg-emerald-50 border border-emerald-200/80 p-3.5 rounded-2xl flex items-start gap-3">
              <Lock className="h-5 w-5 text-emerald-700 shrink-0 mt-0.5" />
              <div className="text-xs text-emerald-950">
                <h5 className="font-bold mb-0.5">
                  {isEs ? "Custodia Smart Escrow Garantizada" : "Guaranteed Smart Escrow Protection"}
                </h5>
                <p className="text-emerald-800/90 text-[11px] leading-relaxed">
                  {isEs
                    ? "Ya sea pagando con tarjeta o saldo de billetera, tus fondos quedan bloqueados en custodia de contrato inteligente hasta que confirmas la entrega y calidad de tu insumo o servicio."
                    : "Whether paying by credit/debit card or balance, your funds are secured in smart escrow until delivery is verified."}
                </p>
              </div>
            </div>

            {/* Payment Method Selector Tabs */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                {isEs ? "Selecciona Método de Pago:" : "Select Payment Method:"}
              </label>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('CARD')}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    paymentMethod === 'CARD'
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-sm ring-2 ring-emerald-500/20'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-1 text-slate-800">
                    <CreditCard className="w-4 h-4 text-emerald-600" />
                    <span className="text-xs font-bold">{isEs ? "Tarjetas" : "Cards"}</span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-semibold">
                    VISA · MC · AMEX
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('WALLET')}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    paymentMethod === 'WALLET'
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-sm ring-2 ring-emerald-500/20'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-1 text-slate-800">
                    <Coins className="w-4 h-4 text-amber-500" />
                    <span className="text-xs font-bold">{isEs ? "Saldo Milpa" : "Milpa Balance"}</span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-semibold font-mono">
                    ${currentUser?.balance ? currentUser.balance.toLocaleString() : '0'} MXN
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('CRYPTO')}
                  className={`p-3 rounded-2xl border text-left transition-all col-span-2 sm:col-span-1 ${
                    paymentMethod === 'CRYPTO'
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-sm ring-2 ring-emerald-500/20'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-1 text-slate-800">
                    <Zap className="w-4 h-4 text-purple-600" />
                    <span className="text-xs font-bold">Polygon Web3</span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-semibold">
                    USDC / POL
                  </p>
                </button>
              </div>
            </div>

            {/* TAB 1: CARD PAYMENT FORM */}
            {paymentMethod === 'CARD' && (
              <div className="pt-2 border-t border-slate-100">
                <CardPaymentForm
                  amountMxn={totalPrice}
                  itemName={`${item.title} (x${quantity} ${item.unit})`}
                  itemCategory={item.category}
                  lang={lang}
                  onPaymentSuccess={handleCardPaymentSuccess}
                  isProcessing={isProcessing}
                />
              </div>
            )}

            {/* TAB 2: WALLET BALANCE PAYMENT */}
            {paymentMethod === 'WALLET' && (
              <div className="bg-slate-50 border border-slate-200 p-5 rounded-3xl space-y-4">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-slate-600 font-medium">{isEs ? "Tu Saldo Disponible:" : "Available Balance:"}</span>
                  <span className="font-mono font-bold text-slate-900">${currentUser?.balance ? currentUser.balance.toLocaleString() : '0'} MXN</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-slate-600 font-medium">{isEs ? "Monto a Deducir:" : "Amount to Deduct:"}</span>
                  <span className="font-mono font-bold text-emerald-700">-${totalPrice.toLocaleString()} MXN</span>
                </div>
                <div className="flex justify-between items-center text-sm border-t border-slate-200 pt-3">
                  <span className="text-slate-700 font-bold">{isEs ? "Saldo Restante:" : "Remaining Balance:"}</span>
                  <span className={`font-mono font-black ${currentUser && currentUser.balance < totalPrice ? 'text-red-500' : 'text-slate-900'}`}>
                    ${currentUser ? (currentUser.balance - totalPrice).toLocaleString() : '0'} MXN
                  </span>
                </div>

                <button
                  type="button"
                  onClick={handleWalletPurchase}
                  disabled={isProcessing || (currentUser ? currentUser.balance < totalPrice : true)}
                  className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-2xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 text-sm"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>{isEs ? `Confirmar con Saldo ($${totalPrice.toLocaleString()} MXN)` : `Confirm with Balance ($${totalPrice.toLocaleString()} MXN)`}</span>
                </button>
              </div>
            )}

            {/* TAB 3: POLYGON WEB3 */}
            {paymentMethod === 'CRYPTO' && (
              <div className="bg-purple-50 border border-purple-200 p-5 rounded-3xl space-y-4 text-center">
                <div className="w-12 h-12 rounded-2xl bg-purple-600 text-white flex items-center justify-center mx-auto shadow-md">
                  <Zap className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-purple-950">{isEs ? "Pago Cripto en Red Polygon" : "Crypto Payment on Polygon"}</h4>
                  <p className="text-xs text-purple-800 mt-1 max-w-sm mx-auto">
                    {isEs
                      ? `Equivalente aproximado: ${(totalPrice / 20).toFixed(2)} USDC. Conecta tu MetaMask o Billetera Polygon para liquidar de inmediato.`
                      : `Approximate equivalent: ${(totalPrice / 20).toFixed(2)} USDC.`}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleWalletPurchase}
                  className="w-full py-3.5 bg-purple-700 hover:bg-purple-800 text-white font-black rounded-2xl transition-all shadow-md flex items-center justify-center gap-2 text-sm"
                >
                  <span>{isEs ? "Pagar con Smart Contract Polygon" : "Pay with Polygon Smart Contract"}</span>
                </button>
              </div>
            )}

          </div>
        </div>
      </div>

      {/* Payment Receipt Voucher Modal */}
      <PaymentReceiptModal
        receipt={receiptData}
        isOpen={showReceipt}
        onClose={() => {
          setShowReceipt(false);
          onClose();
        }}
        lang={lang}
      />
    </>
  );
};
