import React, { useState, useEffect } from 'react';
import {
  Wallet, Shield, CheckCircle2, AlertCircle, ExternalLink, Copy, Check,
  RefreshCw, X, Zap, Layers, Sparkles, Lock, ArrowRight, Globe, Key,
  CreditCard, Coins
} from 'lucide-react';
import { Language, UserProfile, PaymentReceipt, Transaction } from '../types';
import { CardPaymentForm } from './CardPaymentForm';
import { PaymentReceiptModal } from './PaymentReceiptModal';
import { db, sanitizeForFirestore } from '../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';

interface Web3WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  currentUser: UserProfile | null;
  onWalletConnected: (address: string, providerName: string) => void;
  onUpdateBalance?: (newBalance: number) => void;
}

export const Web3WalletModal: React.FC<Web3WalletModalProps> = ({
  isOpen,
  onClose,
  lang,
  currentUser,
  onWalletConnected,
  onUpdateBalance
}) => {
  const [isConnecting, setIsConnecting] = useState(false);
  const [customAddress, setCustomAddress] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [metaMaskAvailable, setMetaMaskAvailable] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'METAMASK' | 'CARD_RECHARGE' | 'DEMO' | 'MANUAL'>('CARD_RECHARGE');

  // Recharge State
  const [rechargeAmount, setRechargeAmount] = useState<number>(5000);
  const [customRechargeInput, setCustomRechargeInput] = useState<string>('5000');
  const [receiptData, setReceiptData] = useState<PaymentReceipt | null>(null);
  const [showReceipt, setShowReceipt] = useState(false);
  const [isProcessingCard, setIsProcessingCard] = useState(false);


  useEffect(() => {
    if (typeof window !== 'undefined' && (window as any).ethereum) {
      setMetaMaskAvailable(true);
    } else {
      setMetaMaskAvailable(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Real MetaMask Connection with full error handling and polygon network detection
  const handleConnectMetaMask = async () => {
    setIsConnecting(true);
    setErrorMessage(null);

    try {
      if (typeof window === 'undefined' || !(window as any).ethereum) {
        setErrorMessage(
          lang === 'es'
            ? 'No se detectó la extensión MetaMask en este navegador. Puedes conectar una Billetera Demo Web3 o ingresar tu dirección manualmente.'
            : 'MetaMask extension was not detected in this browser. You can connect a Demo Web3 Wallet or enter your address manually.'
        );
        setActiveTab('DEMO');
        setIsConnecting(false);
        return;
      }

      const ethereum = (window as any).ethereum;
      
      // Request account access
      const accounts: string[] = await ethereum.request({
        method: 'eth_requestAccounts'
      });

      if (accounts && accounts.length > 0) {
        const address = accounts[0];
        
        // Try to switch to Polygon Mainnet (or inform gracefully)
        try {
          await ethereum.request({
            method: 'wallet_switchEthereumChain',
            params: [{ chainId: '0x89' }] // Polygon Mainnet ChainId 137
          });
        } catch (switchError: any) {
          // 4902 error indicates that the chain has not been added to MetaMask
          if (switchError.code === 4902) {
            try {
              await ethereum.request({
                method: 'wallet_addEthereumChain',
                params: [
                  {
                    chainId: '0x89',
                    chainName: 'Polygon Mainnet',
                    nativeCurrency: { name: 'POL', symbol: 'POL', decimals: 18 },
                    rpcUrls: ['https://polygon-rpc.com/'],
                    blockExplorerUrls: ['https://polygonscan.com/']
                  }
                ]
              });
            } catch (addError) {
              console.warn("Polygon network addition rejected or failed:", addError);
            }
          }
        }

        onWalletConnected(address, 'MetaMask (Polygon)');
        onClose();
      } else {
        throw new Error(lang === 'es' ? 'No se seleccionó ninguna cuenta en MetaMask.' : 'No account was selected in MetaMask.');
      }
    } catch (err: any) {
      console.warn("MetaMask connection notice:", err);
      let userFriendlyMsg = lang === 'es'
        ? 'No se pudo conectar a MetaMask. Si rechazaste la solicitud o estás en un entorno de vista previa, utiliza la Billetera Demo de Polygon.'
        : 'Could not connect to MetaMask. If you rejected the request or are in a preview sandbox, please use the Polygon Demo Wallet.';

      if (err.code === 4001) {
        userFriendlyMsg = lang === 'es'
          ? 'Conexión cancelada por el usuario en MetaMask.'
          : 'Connection request was cancelled by the user in MetaMask.';
      } else if (err.message) {
        userFriendlyMsg += ` (${err.message})`;
      }

      setErrorMessage(userFriendlyMsg);
    } finally {
      setIsConnecting(false);
    }
  };

  // Instant Polygon Demo Web3 Wallet
  const handleConnectDemoWallet = () => {
    const randomHex = Array.from({ length: 40 }, () =>
      Math.floor(Math.random() * 16).toString(16)
    ).join('');
    const demoAddress = `0x${randomHex}`;
    onWalletConnected(demoAddress, 'Polygon Web3 Demo');
    if (onUpdateBalance && currentUser && currentUser.balance < 20000) {
      onUpdateBalance(50000);
    }
    onClose();
  };

  // Custom manual address connection
  const handleConnectManual = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customAddress.trim() || !customAddress.startsWith('0x') || customAddress.length < 10) {
      setErrorMessage(
        lang === 'es'
          ? 'Por favor ingresa una dirección de billetera válida que comience con 0x.'
          : 'Please enter a valid wallet address starting with 0x.'
      );
      return;
    }
    onWalletConnected(customAddress.trim(), 'Web3 Manual');
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto animate-fade-in"
      id="web3-wallet-modal"
    >
      <div className="bg-slate-900 text-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden border border-emerald-500/40 text-left">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-950/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 flex items-center justify-center text-emerald-400 border border-emerald-500/40">
              <Wallet className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-white text-lg leading-none">
                {lang === 'es' ? "Conectar Billetera Web3" : "Connect Web3 Wallet"}
              </h3>
              <p className="text-xs text-slate-400 font-medium mt-1">
                {lang === 'es' ? "Red Polygon (Matic) • Trazabilidad Inmutable" : "Polygon (Matic) Network • Immutable Traceability"}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Current Active Status if already connected */}
        {currentUser?.walletAddress && (
          <div className="bg-emerald-950/60 border-b border-emerald-800/40 p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping"></span>
              <span className="text-xs font-bold text-emerald-300">
                {lang === 'es' ? "Billetera Activa:" : "Active Wallet:"}
              </span>
              <span className="font-mono text-xs text-white bg-slate-900/80 px-2 py-0.5 rounded border border-emerald-500/30">
                {currentUser.walletAddress.slice(0, 6)}...{currentUser.walletAddress.slice(-4)}
              </span>
            </div>
            <button
              onClick={() => handleCopy(currentUser.walletAddress!)}
              className="p-1.5 hover:bg-emerald-900/80 rounded-lg text-emerald-300 transition-colors flex items-center gap-1 text-[11px]"
              title="Copy"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? (lang === 'es' ? "Copiado" : "Copied") : (lang === 'es' ? "Copiar" : "Copy")}</span>
            </button>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 p-2 gap-2 overflow-x-auto">
          <button
            onClick={() => { setActiveTab('CARD_RECHARGE'); setErrorMessage(null); }}
            className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'CARD_RECHARGE'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <CreditCard className="w-4 h-4 text-emerald-400" />
            <span>{lang === 'es' ? "Tarjetas VISA/MC/AMEX" : "Cards VISA/MC/AMEX"}</span>
          </button>

          <button
            onClick={() => { setActiveTab('METAMASK'); setErrorMessage(null); }}
            className={`flex-1 min-w-[100px] py-2.5 px-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'METAMASK'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            {/* MetaMask Fox Icon SVG */}
            <svg className="w-4 h-4" viewBox="0 0 32 32" fill="none">
              <path d="M28.45 3L17.7 10.95l1.97-4.66L28.45 3z" fill="#E2761B" stroke="#E2761B" strokeWidth="0.5"/>
              <path d="M3.55 3l10.63 8.03-1.85-4.74L3.55 3z" fill="#E4761B" stroke="#E4761B" strokeWidth="0.5"/>
              <path d="M24.47 21.72l-2.8 4.28 6.05 1.66 1.73-5.9-4.98-.04z" fill="#E4761B" stroke="#E4761B" strokeWidth="0.5"/>
              <path d="M2.55 21.76l1.72 5.9 6.05-1.66-2.8-4.28-4.97.04z" fill="#E4761B" stroke="#E4761B" strokeWidth="0.5"/>
              <path d="M10.12 14.1l-1.68 2.52 6.03.27-.23-6.52-4.12 3.73z" fill="#E4761B" stroke="#E4761B" strokeWidth="0.5"/>
              <path d="M21.88 14.1l-4.17-3.81-.17 6.6 6.02-.27-1.68-2.52z" fill="#E4761B" stroke="#E4761B" strokeWidth="0.5"/>
              <path d="M10.32 25.99l3.58-1.74-3.08-2.4-0.5 4.14z" fill="#E4761B" stroke="#E4761B" strokeWidth="0.5"/>
              <path d="M18.1 24.25l3.58 1.74-.5-4.14-3.08 2.4z" fill="#E4761B" stroke="#E4761B" strokeWidth="0.5"/>
              <path d="M21.68 26l-3.58-1.74.29 2.38.03.11 3.26-.75z" fill="#D7C1B3" stroke="#D7C1B3" strokeWidth="0.5"/>
              <path d="M10.32 26l3.26.75.03-.11.29-2.38-3.58 1.74z" fill="#D7C1B3" stroke="#D7C1B3" strokeWidth="0.5"/>
              <path d="M14.07 19.38l-5.83-.24 2.56 3.75 3.27-3.51z" fill="#233238" stroke="#233238" strokeWidth="0.5"/>
              <path d="M17.93 19.38l3.27 3.51 2.56-3.75-5.83.24z" fill="#233238" stroke="#233238" strokeWidth="0.5"/>
              <path d="M8.44 16.62l1.68 2.76 5.83.24.16-5.8-7.67 2.8z" fill="#CD6116" stroke="#CD6116" strokeWidth="0.5"/>
              <path d="M21.88 19.38l1.68-2.76-7.67-2.8.16 5.8 5.83-.24z" fill="#CD6116" stroke="#CD6116" strokeWidth="0.5"/>
              <path d="M17.7 10.95l-1.7-4.66-1.7 4.66 1.7 2.87 1.7-2.87z" fill="#E4751F" stroke="#E4751F" strokeWidth="0.5"/>
            </svg>
            <span>MetaMask</span>
          </button>

          <button
            onClick={() => { setActiveTab('DEMO'); setErrorMessage(null); }}
            className={`flex-1 min-w-[90px] py-2.5 px-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'DEMO'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <Zap className="w-4 h-4 text-emerald-400" />
            <span>{lang === 'es' ? "Demo" : "Demo"}</span>
          </button>

          <button
            onClick={() => { setActiveTab('MANUAL'); setErrorMessage(null); }}
            className={`flex-1 min-w-[90px] py-2.5 px-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'MANUAL'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <Key className="w-4 h-4 text-cyan-400" />
            <span>{lang === 'es' ? "Manual" : "Manual"}</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">

          {/* TAB 0: CARD RECHARGE */}
          {activeTab === 'CARD_RECHARGE' && (
            <div className="space-y-5">
              {/* Recharge Amount Selector */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                    {lang === 'es' ? "Monto a Fondear / Recargar:" : "Amount to Fund:"}
                  </span>
                  <span className="text-xl font-black font-mono text-emerald-400">
                    ${rechargeAmount.toLocaleString()} MXN
                  </span>
                </div>

                {/* Presets */}
                <div className="grid grid-cols-4 gap-2">
                  {[2500, 5000, 10000, 25000].map((amt) => (
                    <button
                      type="button"
                      key={amt}
                      onClick={() => {
                        setRechargeAmount(amt);
                        setCustomRechargeInput(amt.toString());
                      }}
                      className={`py-2 rounded-xl text-xs font-mono font-bold transition-all ${
                        rechargeAmount === amt
                          ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                          : 'bg-slate-900 text-slate-300 border border-slate-700 hover:border-slate-500'
                      }`}
                    >
                      ${amt.toLocaleString()}
                    </button>
                  ))}
                </div>

                {/* Custom Input */}
                <div className="flex items-center gap-2 pt-1">
                  <span className="text-xs text-slate-400 font-bold">$</span>
                  <input
                    type="number"
                    min="100"
                    step="100"
                    value={customRechargeInput}
                    onChange={(e) => {
                      setCustomRechargeInput(e.target.value);
                      const num = Number(e.target.value);
                      if (num > 0) setRechargeAmount(num);
                    }}
                    placeholder="Otro monto..."
                    className="flex-1 px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-emerald-500"
                  />
                  <span className="text-xs text-slate-400 font-bold">MXN</span>
                </div>
              </div>

              {/* Card Payment Form (Themed for light container or wrapped) */}
              <div className="bg-slate-900 p-5 rounded-3xl border border-slate-800">
                <CardPaymentForm
                  amountMxn={rechargeAmount}
                  itemName={`Fondeo de Billetera MilpaTech ($${rechargeAmount.toLocaleString()} MXN)`}
                  itemCategory="Fondeo de Capital"
                  lang={lang}
                  onPaymentSuccess={async (cardData) => {
                    setIsProcessingCard(true);
                    try {
                      const newBal = (currentUser?.balance || 0) + rechargeAmount;
                      const txId = `tx-recharge-${Date.now()}`;
                      const txHash = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
                      const timestamp = new Date().toLocaleString(lang === 'es' ? 'es-MX' : 'en-US');

                      const tx: Transaction = {
                        id: txId,
                        cropName: `Fondeo de Billetera · ${cardData.cardBrand}`,
                        userName: currentUser?.name || cardData.cardholder,
                        userRole: currentUser?.role || 'INVESTOR',
                        amount: 1,
                        price: rechargeAmount,
                        total: rechargeAmount,
                        date: timestamp,
                        type: 'WALLET_RECHARGE',
                        txHash,
                        paymentMethod: cardData.cardBrand === 'VISA' ? 'CARD_VISA' : cardData.cardBrand === 'MASTERCARD' ? 'CARD_MASTERCARD' : 'CARD_AMEX',
                        cardBrand: cardData.cardBrand,
                        cardLast4: cardData.last4,
                        authCode: cardData.authCode,
                        installments: cardData.installments
                      };

                      try {
                        await setDoc(doc(db, 'transactions', txId), sanitizeForFirestore(tx));
                        if (currentUser) {
                          await setDoc(doc(db, 'users', currentUser.id), { balance: newBal }, { merge: true });
                        }
                      } catch (e) {
                        console.warn("Firestore sync recharge notice:", e);
                      }

                      if (onUpdateBalance) {
                        onUpdateBalance(newBal);
                      }

                      const receipt: PaymentReceipt = {
                        transactionId: txId,
                        authCode: cardData.authCode,
                        amountMxn: rechargeAmount,
                        itemDescription: `Fondeo de Saldo MilpaTech con ${cardData.cardBrand}`,
                        paymentMethod: cardData.cardBrand === 'VISA' ? 'CARD_VISA' : cardData.cardBrand === 'MASTERCARD' ? 'CARD_MASTERCARD' : 'CARD_AMEX',
                        cardLast4: cardData.last4,
                        cardBrand: cardData.cardBrand,
                        installments: cardData.installments,
                        timestamp,
                        txHash
                      };

                      setReceiptData(receipt);
                      setShowReceipt(true);
                    } catch (err) {
                      console.error(err);
                      alert(lang === 'es' ? "Error al procesar recarga con tarjeta." : "Error processing recharge.");
                    } finally {
                      setIsProcessingCard(false);
                    }
                  }}
                  isProcessing={isProcessingCard}
                />
              </div>
            </div>
          )}

          {/* Error / Fallback Alert Banner */}
          {errorMessage && (
            <div className="bg-amber-950/80 border border-amber-600/50 p-4 rounded-2xl flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div className="text-xs text-amber-200 leading-relaxed">
                <p className="font-bold">{lang === 'es' ? "Aviso de Conexión:" : "Connection Notice:"}</p>
                <p className="mt-1">{errorMessage}</p>
              </div>
            </div>
          )}

          {/* TAB 1: METAMASK */}
          {activeTab === 'METAMASK' && (
            <div className="space-y-5">
              <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-white flex items-center gap-2">
                    <Layers className="w-4 h-4 text-amber-400" />
                    <span>MetaMask Browser Extension</span>
                  </span>
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                    metaMaskAvailable ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40" : "bg-slate-800 text-slate-400"
                  }`}>
                    {metaMaskAvailable ? (lang === 'es' ? "Detectado" : "Detected") : (lang === 'es' ? "No Detectado" : "Not Found")}
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {lang === 'es'
                    ? "Conecta tu billetera MetaMask para firmar transacciones de inversión en cultivos y recibir tokens agrícolas ERC-20 / NFT ERC-721 en la red Polygon."
                    : "Connect your MetaMask wallet to sign crop investment transactions and receive ERC-20 / NFT ERC-721 agricultural tokens on Polygon."}
                </p>
              </div>

              <div className="space-y-3">
                <button
                  type="button"
                  onClick={handleConnectMetaMask}
                  disabled={isConnecting}
                  className="w-full py-4 px-6 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white font-black rounded-2xl transition-all shadow-lg flex items-center justify-center gap-3 active:scale-98 disabled:opacity-50 text-sm"
                >
                  {isConnecting ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      <span>{lang === 'es' ? "Conectando con MetaMask..." : "Connecting to MetaMask..."}</span>
                    </>
                  ) : (
                    <>
                      <Wallet className="w-5 h-5" />
                      <span>{lang === 'es' ? "Conectar con MetaMask" : "Connect with MetaMask"}</span>
                    </>
                  )}
                </button>

                {!metaMaskAvailable && (
                  <div className="pt-2 text-center">
                    <p className="text-[11px] text-slate-400 mb-2">
                      {lang === 'es' ? "¿No tienes la extensión instalada o estás en móvil?" : "Don't have the extension installed or on mobile?"}
                    </p>
                    <button
                      type="button"
                      onClick={() => setActiveTab('DEMO')}
                      className="text-xs font-bold text-emerald-400 hover:text-emerald-300 underline underline-offset-4 inline-flex items-center gap-1"
                    >
                      <span>{lang === 'es' ? "Usar Billetera Demo Web3 sin extensión" : "Use Web3 Demo Wallet without extension"}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: INSTANT POLYGON DEMO WALLET */}
          {activeTab === 'DEMO' && (
            <div className="space-y-5">
              <div className="bg-emerald-950/40 p-5 rounded-2xl border border-emerald-500/30 space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 font-extrabold text-xs uppercase tracking-wider">
                  <Sparkles className="w-4 h-4" />
                  <span>{lang === 'es' ? "Billetera Instantánea Polygon" : "Instant Polygon Wallet"}</span>
                </div>
                <p className="text-xs text-emerald-100 leading-relaxed">
                  {lang === 'es'
                    ? "Genera una billetera Web3 compatible con la red Polygon al instante. Perfecta para probar la plataforma, comprar tokens de prueba y auditar transacciones sin necesidad de extensiones externas."
                    : "Generate an instant Web3 wallet compatible with Polygon. Perfect for testing token purchases and auditing ledger blocks without requiring external extensions."}
                </p>
              </div>

              <button
                type="button"
                onClick={handleConnectDemoWallet}
                className="w-full py-4 px-6 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black rounded-2xl transition-all shadow-lg flex items-center justify-center gap-3 active:scale-98 text-sm"
              >
                <Zap className="w-5 h-5 text-amber-300" />
                <span>{lang === 'es' ? "Activar Billetera Web3 Demo ($50,000 MXN)" : "Activate Web3 Demo Wallet ($50,000 MXN)"}</span>
              </button>
            </div>
          )}

          {/* TAB 3: MANUAL WALLET ADDRESS */}
          {activeTab === 'MANUAL' && (
            <form onSubmit={handleConnectManual} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  {lang === 'es' ? "Dirección Pública de Billetera (0x...)" : "Public Wallet Address (0x...)"}
                </label>
                <input
                  type="text"
                  required
                  placeholder="0x3db5ae71bca21cf29871fa8d810ba2cde1297fb9"
                  value={customAddress}
                  onChange={(e) => setCustomAddress(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
                />
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-[11px] text-slate-400 space-y-1">
                <p className="font-bold text-slate-300">
                  {lang === 'es' ? "🔒 Seguridad Garantizada:" : "🔒 Guaranteed Security:"}
                </p>
                <p>
                  {lang === 'es'
                    ? "Solo solicitamos tu dirección pública. Nunca pediremos tu frase semilla o clave privada."
                    : "We only request your public address. We will never ask for your seed phrase or private key."}
                </p>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 px-6 bg-cyan-600 hover:bg-cyan-500 text-white font-black rounded-2xl transition-all shadow-md flex items-center justify-center gap-2 active:scale-98 text-xs uppercase tracking-wider"
              >
                <Check className="w-4 h-4" />
                <span>{lang === 'es' ? "Guardar y Vincular Billetera" : "Save and Link Wallet"}</span>
              </button>
            </form>
          )}

          {/* Security & Network Info Footer */}
          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
            <span className="flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>Smart Contract Verified on Polygon</span>
            </span>
            <a
              href="https://polygonscan.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white flex items-center gap-1 text-slate-400 transition-colors"
            >
              <span>PolygonScan</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

        </div>
      </div>

      {/* Payment Receipt Voucher */}
      <PaymentReceiptModal
        receipt={receiptData}
        isOpen={showReceipt}
        onClose={() => {
          setShowReceipt(false);
          onClose();
        }}
        lang={lang}
      />
    </div>
  );
};
