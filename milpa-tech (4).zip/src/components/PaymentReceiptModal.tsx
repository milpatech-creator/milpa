import React from 'react';
import {
  CheckCircle2, ShieldCheck, Download, Printer, ExternalLink,
  Copy, Check, X, CreditCard, Coins, ShoppingBag, ArrowRight
} from 'lucide-react';
import { PaymentReceipt, Language } from '../types';

interface PaymentReceiptModalProps {
  receipt: PaymentReceipt | null;
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const PaymentReceiptModal: React.FC<PaymentReceiptModalProps> = ({
  receipt,
  isOpen,
  onClose,
  lang
}) => {
  const [copied, setCopied] = React.useState(false);
  if (!isOpen || !receipt) return null;

  const isEs = lang === 'es';

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-md w-full shadow-2xl overflow-hidden text-slate-800 my-6 animate-scale-up">
        
        {/* Header Ribbon */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white p-6 text-center relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-emerald-100 hover:text-white bg-black/20 p-1.5 rounded-full transition-colors"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="w-14 h-14 rounded-full bg-white/20 backdrop-blur-sm border-2 border-white/40 flex items-center justify-center mx-auto mb-3 text-white shadow-lg">
            <CheckCircle2 className="w-8 h-8 text-white" />
          </div>

          <span className="text-[11px] font-black uppercase tracking-widest bg-emerald-950/30 px-3 py-1 rounded-full border border-emerald-300/30 inline-block mb-1">
            {isEs ? "Comprobante de Pago Exitoso" : "Payment Receipt Successful"}
          </span>
          <h3 className="text-2xl font-black">{isEs ? "¡Transacción Aprobada!" : "Transaction Approved!"}</h3>
          <p className="text-xs text-emerald-100 mt-1">
            {isEs ? "Registro validado en Smart Contract & Pasarela Bancaria" : "Validated in Smart Contract & Banking Gateway"}
          </p>
        </div>

        {/* Receipt Voucher Body */}
        <div className="p-6 space-y-5">
          
          {/* Amount Badge */}
          <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl text-center space-y-1">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
              {isEs ? "Monto Total Procesado" : "Total Amount Charged"}
            </span>
            <div className="text-3xl font-black font-mono text-slate-900">
              ${receipt.amountMxn.toLocaleString()} <span className="text-sm font-sans font-bold text-slate-500">MXN</span>
            </div>
            {receipt.installments && receipt.installments > 1 && (
              <span className="inline-block bg-amber-100 text-amber-900 text-xs font-bold px-2.5 py-0.5 rounded-full mt-1">
                {receipt.installments} {isEs ? "Meses Sin Intereses" : "Months 0% APR"}
              </span>
            )}
          </div>

          {/* Details Grid */}
          <div className="divide-y divide-slate-100 text-xs font-medium space-y-2.5">
            <div className="flex justify-between items-center pt-2">
              <span className="text-slate-500">{isEs ? "Concepto / Activo:" : "Item / Asset:"}</span>
              <span className="font-bold text-slate-800 text-right max-w-[200px] truncate">{receipt.itemDescription}</span>
            </div>

            <div className="flex justify-between items-center pt-2">
              <span className="text-slate-500">{isEs ? "Método de Pago:" : "Payment Method:"}</span>
              <span className="font-bold text-slate-800 flex items-center gap-1.5">
                {receipt.cardBrand === 'VISA' && <span className="font-black text-blue-700 italic">VISA</span>}
                {receipt.cardBrand === 'MASTERCARD' && <span className="font-bold text-red-600">Mastercard</span>}
                {receipt.cardBrand === 'AMEX' && <span className="font-bold text-cyan-700">AMEX</span>}
                {receipt.cardLast4 ? `•••• ${receipt.cardLast4}` : (isEs ? 'Billetera Milpa' : 'Milpa Wallet')}
              </span>
            </div>

            <div className="flex justify-between items-center pt-2">
              <span className="text-slate-500">{isEs ? "Código de Autorización:" : "Auth Code:"}</span>
              <span className="font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                {receipt.authCode}
              </span>
            </div>

            <div className="flex justify-between items-center pt-2">
              <span className="text-slate-500">{isEs ? "Fecha y Hora:" : "Date & Time:"}</span>
              <span className="font-semibold text-slate-700">{receipt.timestamp}</span>
            </div>

            {receipt.txHash && (
              <div className="pt-2">
                <span className="text-slate-500 block mb-1">{isEs ? "Hash Polygon (Blockchain):" : "Polygon Tx Hash:"}</span>
                <div className="flex items-center gap-2 bg-slate-100 p-2 rounded-xl border border-slate-200 font-mono text-[10px] text-slate-700">
                  <span className="truncate">{receipt.txHash}</span>
                  <button
                    onClick={() => handleCopy(receipt.txHash!)}
                    className="p-1 hover:bg-slate-200 rounded text-slate-600 shrink-0"
                    title="Copiar Hash"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Security stamp */}
          <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl flex items-center gap-2.5 text-[11px] text-emerald-900">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>
              {isEs
                ? "Pago auditado y respaldado bajo el protocolo PCI-DSS y Smart Contracts MilpaTech."
                : "Audited payment backed by PCI-DSS protocol and MilpaTech Smart Contracts."}
            </span>
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-2">
            <button
              onClick={handlePrint}
              className="flex-1 py-3 border border-slate-200 text-slate-700 rounded-xl font-bold text-xs hover:bg-slate-50 transition-colors flex items-center justify-center gap-1.5"
            >
              <Printer className="w-4 h-4" />
              <span>{isEs ? "Imprimir" : "Print"}</span>
            </button>
            <button
              onClick={onClose}
              className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs transition-all shadow-md flex items-center justify-center gap-1.5"
            >
              <span>{isEs ? "Listo / Continuar" : "Done / Continue"}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
