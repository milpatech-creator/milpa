import React from 'react';

interface MilpaLogoProps {
  variant?: 'full' | 'icon' | 'light' | 'hero';
  className?: string;
  size?: number;
  showText?: boolean;
}

export const MilpaLogo: React.FC<MilpaLogoProps> = ({
  variant = 'full',
  className = '',
  size,
  showText = true
}) => {
  const isLight = variant === 'light';
  const logoSrc = isLight 
    ? "/milpa_tech_logo_transparent.svg" 
    : "/milpa_tech_logo.svg";

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* 1:1 Original Logo Image from Uploaded File */}
      <img
        src={logoSrc}
        alt="Milpa Tech Official Logo"
        referrerPolicy="no-referrer"
        style={{
          width: size ? `${size}px` : undefined,
          height: size ? `${size}px` : undefined,
        }}
        className={size ? 'object-contain' : 'h-10 w-auto object-contain shrink-0'}
      />

      {showText && !logoSrc.includes("milpa_tech_logo.svg") && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5 font-black tracking-tight leading-none text-xl sm:text-2xl">
            <span className={isLight ? 'text-emerald-900' : 'text-emerald-400 font-extrabold'}>MILPA</span>
            <span className={isLight ? 'text-teal-700' : 'text-cyan-400 font-extrabold'}>TECH</span>
          </div>
          <span className={`text-[9px] uppercase tracking-widest font-extrabold mt-0.5 ${
            isLight ? 'text-emerald-700' : 'text-emerald-300'
          }`}>
            Soberanía & Tokenización
          </span>
        </div>
      )}
    </div>
  );
};
