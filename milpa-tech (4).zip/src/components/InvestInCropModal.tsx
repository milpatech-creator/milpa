import React, { useState } from 'react';
import {
  X, Coins, CreditCard, ShieldCheck, Sparkles, Zap,
  TrendingUp, Calendar, AlertCircle, Award, CheckCircle2, Lock
} from 'lucide-react';
import { Crop, UserProfile, Language, Transaction, PaymentReceipt } from '../types';
import { db, sanitizeForFirestore } from '../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { CardPaymentForm } from './CardPaymentForm';
import { PaymentReceiptModal } from './PaymentReceiptModal';

interface InvestInCropModalProps {
  isOpen: boolean;
  onClose: () => void;
  crop: Crop | null;
  currentUser: UserProfile | null;
  lang: Language;
  onInvestSuccess: (cropId: string, amount: number, totalPrice: number, tx: Transaction) => void;
}

export const InvestInCropModal: React.FC<InvestInCropModalProps> = ({
  isOpen,
  onClose,
  crop,
  currentUser,
  lang,
  onInvestSuccess
}) => {
  if (!isOpen || !crop) return null;

  const isEs = lang === 'es';
  const availableTokens = Math.max(1, crop.totalTokens - crop.soldTokens);
  const [buyAmount, setBuyAmount] = useState<number>(Math.min(10, availableTokens));
  const [paymentMethod, setPaymentMethod] = useState<'CARD' | 'WALLET' | 'CRYPTO'>('CARD');
  const [isProcessing, setIsProcessing] = useState(false);
  const [receiptData, setReceiptData] = useState<PaymentReceipt | null>(null);
  const [showReceipt, setShowReceipt] = useState(false);

  const totalPrice = buyAmount * crop.tokenPrice;
  const estimatedReturn = totalPrice * (1 + (crop.yieldProjection || 18) / 100);
  const estimatedProfit = estimatedReturn - totalPrice;

  // Handle Card Payment Success
  const handleCardPaymentSuccess = async (cardData: {
    cardBrand: 'VISA' | 'MASTERCARD' | 'AMEX';
    cardType: 'CREDIT' | 'DEBIT';
    last4: string;
    cardholder: string;
    authCode: string;
    installments: number;
  }) => {
    setIsProcessing(true);
    try {
      const txId = `tx-crop-card-${Date.now()}`;
      const txHash = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
      const timestamp = new Date().toLocaleString(isEs ? 'es-MX' : 'en-US');

      const tx: Transaction = {
        id: txId,
        cropName: crop.name,
        cropId: crop.id,
        userName: currentUser?.name || cardData.cardholder,
        userRole: currentUser?.role || 'INVESTOR',
        amount: buyAmount,
        price: crop.tokenPrice,
        total: totalPrice,
        date: timestamp,
        type: 'BUY',
        txHash,
        blockNumber: 18492000 + Math.floor(Math.random() * 5000),
        paymentMethod: cardData.cardBrand === 'VISA' ? 'CARD_VISA' : cardData.cardBrand === 'MASTERCARD' ? 'CARD_MASTERCARD' : 'CARD_AMEX',
        cardBrand: cardData.cardBrand,
        cardLast4: cardData.last4,
        authCode: cardData.authCode,
        installments: cardData.installments
      };

      try {
        await setDoc(doc(db, 'transactions', txId), sanitizeForFirestore(tx));
        await setDoc(doc(db, 'crops', crop.id), { soldTokens: crop.soldTokens + buyAmount }, { merge: true });
      } catch (e) {
        console.warn("Firestore invest sync notice:", e);
      }

      onInvestSuccess(crop.id, buyAmount, totalPrice, tx);

      const receipt: PaymentReceipt = {
        transactionId: txId,
        authCode: cardData.authCode,
        amountMxn: totalPrice,
        itemDescription: `${buyAmount} Tokens de Cultivo · ${crop.name} (${crop.producerName})`,
        paymentMethod: cardData.cardBrand === 'VISA' ? 'CARD_VISA' : cardData.cardBrand === 'MASTERCARD' ? 'CARD_MASTERCARD' : 'CARD_AMEX',
        cardLast4: cardData.last4,
        cardBrand: cardData.cardBrand,
        installments: cardData.installments,
        timestamp,
        txHash
      };

      setReceiptData(receipt);
      setShowReceipt(true);
    } catch (err) {
      console.error(err);
      alert(isEs ? "Error al procesar la inversión con tarjeta." : "Error processing card investment.");
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle Wallet Balance Direct Investment
  const handleWalletInvestment = async () => {
    if (currentUser && currentUser.balance < totalPrice) {
      alert(isEs ? `Saldo insuficiente en Billetera ($${currentUser.balance.toLocaleString()} MXN). Puedes usar tarjeta VISA, Mastercard o AMEX.` : "Insufficient wallet balance.");
      setPaymentMethod('CARD');
      return;
    }

    setIsProcessing(true);
    try {
      const txId = `tx-crop-wallet-${Date.now()}`;
      const txHash = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
      const timestamp = new Date().toLocaleString(isEs ? 'es-MX' : 'en-US');

      const tx: Transaction = {
        id: txId,
        cropName: crop.name,
        cropId: crop.id,
        userName: currentUser?.name || "Inversionista Milpa",
        userRole: currentUser?.role || 'INVESTOR',
        amount: buyAmount,
        price: crop.tokenPrice,
        total: totalPrice,
        date: timestamp,
        type: 'BUY',
        txHash,
        blockNumber: 18492000 + Math.floor(Math.random() * 5000),
        paymentMethod: 'WALLET_BALANCE'
      };

      try {
        await setDoc(doc(db, 'transactions', txId), sanitizeForFirestore(tx));
        await setDoc(doc(db, 'crops', crop.id), { soldTokens: crop.soldTokens + buyAmount }, { merge: true });
        if (currentUser) {
          await setDoc(doc(db, 'users', currentUser.id), { balance: currentUser.balance - totalPrice }, { merge: true });
        }
      } catch (e) {
        console.warn("Firestore invest sync notice:", e);
      }

      onInvestSuccess(crop.id, buyAmount, totalPrice, tx);

      const receipt: PaymentReceipt = {
        transactionId: txId,
        authCode: `WALLET-AUTH-${Math.floor(100000 + Math.random() * 900000)}`,
        amountMxn: totalPrice,
        itemDescription: `${buyAmount} Tokens de Cultivo · ${crop.name} (${crop.producerName})`,
        paymentMethod: 'WALLET_BALANCE',
        timestamp,
        txHash
      };

      setReceiptData(receipt);
      setShowReceipt(true);
    } catch (err) {
      console.error(err);
      alert(isEs ? "Error al procesar la inversión." : "Error processing investment.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
        <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden border border-slate-100 text-left my-6">
          
          {/* Header */}
          <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-md">
                <Coins className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-slate-800 text-lg leading-none">
                  {isEs ? "Inversión en Tokens de Cosecha" : "Invest in Crop Tokens"}
                </h3>
                <p className="text-xs text-slate-400 font-semibold mt-1">
                  {crop.name} · {crop.producerName} ({crop.location})
                </p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full text-slate-500 transition-colors">
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="p-6 space-y-6 max-h-[78vh] overflow-y-auto">
            
            {/* Crop Card Mini Info */}
            <div className="flex gap-4 items-center bg-slate-50 p-4 rounded-2xl border border-slate-200/80">
              <img src={crop.imageUrl} className="w-16 h-16 rounded-2xl object-cover border border-slate-200" alt="" />
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-slate-800 text-base">{crop.name}</h4>
                  <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-100/70 px-2.5 py-0.5 rounded-full">
                    ${crop.tokenPrice} MXN / token
                  </span>
                </div>
                <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-500 font-medium">
                  <span className="flex items-center gap-1 text-emerald-600 font-bold">
                    <TrendingUp className="w-3.5 h-3.5" />
                    +{crop.yieldProjection || 18}% ROI Estimado
                  </span>
                  <span>·</span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    {crop.harvestDate}
                  </span>
                </div>
              </div>
            </div>

            {/* Token Amount Selector */}
            <div className="space-y-3 bg-slate-900 text-white p-5 rounded-3xl">
              <div className="flex justify-between items-center">
                <div>
                  <label className="text-xs uppercase font-bold text-slate-400 block tracking-wider">
                    {isEs ? "Número de Tokens a Adquirir:" : "Tokens to Purchase:"}
                  </label>
                  <span className="text-2xl font-black font-mono text-emerald-400">
                    {buyAmount} <span className="text-xs font-sans text-slate-300 font-normal">tokens</span>
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-xs uppercase font-bold text-slate-400 block tracking-wider">
                    {isEs ? "Total a Invertir:" : "Total Investment:"}
                  </span>
                  <span className="text-2xl font-black font-mono text-white">
                    ${totalPrice.toLocaleString()} MXN
                  </span>
                </div>
              </div>

              {/* Slider */}
              <input
                type="range"
                min="1"
                max={Math.min(200, availableTokens)}
                value={buyAmount}
                onChange={(e) => setBuyAmount(Number(e.target.value))}
                className="w-full h-2.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
              />

              {/* Quick Preset Buttons */}
              <div className="flex gap-2 pt-1">
                {[5, 10, 25, 50, 100].map((preset) => {
                  if (preset > availableTokens && preset !== 5) return null;
                  const isSelected = buyAmount === preset;
                  return (
                    <button
                      type="button"
                      key={preset}
                      onClick={() => setBuyAmount(preset)}
                      className={`flex-1 py-1.5 rounded-xl text-xs font-mono font-bold transition-all ${
                        isSelected
                          ? 'bg-emerald-500 text-slate-950 shadow-sm'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {preset} tok
                    </button>
                  );
                })}
              </div>

              {/* ROI Projected Gain Banner */}
              <div className="bg-emerald-950/60 border border-emerald-500/30 p-3 rounded-2xl flex items-center justify-between text-xs text-emerald-200">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>{isEs ? "Retorno Estimado al Cierre de Cosecha:" : "Estimated Harvest Return:"}</span>
                </span>
                <span className="font-mono font-black text-white text-sm">
                  ${Math.round(estimatedReturn).toLocaleString()} MXN <span className="text-emerald-400 text-xs">(+${Math.round(estimatedProfit).toLocaleString()})</span>
                </span>
              </div>
            </div>

            {/* Payment Method Selector Tabs */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                {isEs ? "Selecciona Cómo Deseas Invertir:" : "Select Payment Method:"}
              </label>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('CARD')}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    paymentMethod === 'CARD'
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-sm ring-2 ring-emerald-500/20'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-1 text-slate-800">
                    <CreditCard className="w-4 h-4 text-emerald-600" />
                    <span className="text-xs font-bold">{isEs ? "Tarjetas" : "Cards"}</span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-semibold">
                    VISA · MC · AMEX
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('WALLET')}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    paymentMethod === 'WALLET'
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-sm ring-2 ring-emerald-500/20'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-1 text-slate-800">
                    <Coins className="w-4 h-4 text-amber-500" />
                    <span className="text-xs font-bold">{isEs ? "Saldo Milpa" : "Milpa Balance"}</span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-semibold font-mono">
                    ${currentUser?.balance ? currentUser.balance.toLocaleString() : '0'} MXN
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('CRYPTO')}
                  className={`p-3 rounded-2xl border text-left transition-all col-span-2 sm:col-span-1 ${
                    paymentMethod === 'CRYPTO'
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-sm ring-2 ring-emerald-500/20'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-1 text-slate-800">
                    <Zap className="w-4 h-4 text-purple-600" />
                    <span className="text-xs font-bold">Polygon Web3</span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-semibold">
                    USDC / POL
                  </p>
                </button>
              </div>
            </div>

            {/* TAB 1: CARD PAYMENT ENGINE */}
            {paymentMethod === 'CARD' && (
              <div className="pt-2 border-t border-slate-100">
                <CardPaymentForm
                  amountMxn={totalPrice}
                  itemName={`${buyAmount} Tokens · ${crop.name}`}
                  itemCategory="Tokens Agrícolas"
                  lang={lang}
                  onPaymentSuccess={handleCardPaymentSuccess}
                  isProcessing={isProcessing}
                />
              </div>
            )}

            {/* TAB 2: WALLET BALANCE PAYMENT */}
            {paymentMethod === 'WALLET' && (
              <div className="bg-slate-50 border border-slate-200 p-5 rounded-3xl space-y-4">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-slate-600 font-medium">{isEs ? "Tu Saldo Disponible:" : "Available Balance:"}</span>
                  <span className="font-mono font-bold text-slate-900">${currentUser?.balance ? currentUser.balance.toLocaleString() : '0'} MXN</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-slate-600 font-medium">{isEs ? "Inversión en Tokens:" : "Token Investment:"}</span>
                  <span className="font-mono font-bold text-emerald-700">-${totalPrice.toLocaleString()} MXN</span>
                </div>
                <div className="flex justify-between items-center text-sm border-t border-slate-200 pt-3">
                  <span className="text-slate-700 font-bold">{isEs ? "Saldo Restante:" : "Remaining Balance:"}</span>
                  <span className={`font-mono font-black ${currentUser && currentUser.balance < totalPrice ? 'text-red-500' : 'text-slate-900'}`}>
                    ${currentUser ? (currentUser.balance - totalPrice).toLocaleString() : '0'} MXN
                  </span>
                </div>

                <button
                  type="button"
                  onClick={handleWalletInvestment}
                  disabled={isProcessing || (currentUser ? currentUser.balance < totalPrice : true)}
                  className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-2xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 text-sm"
                >
                  <Coins className="w-5 h-5" />
                  <span>{isEs ? `Confirmar Inversión ($${totalPrice.toLocaleString()} MXN)` : `Confirm Investment ($${totalPrice.toLocaleString()} MXN)`}</span>
                </button>
              </div>
            )}

            {/* TAB 3: POLYGON WEB3 */}
            {paymentMethod === 'CRYPTO' && (
              <div className="bg-purple-50 border border-purple-200 p-5 rounded-3xl space-y-4 text-center">
                <div className="w-12 h-12 rounded-2xl bg-purple-600 text-white flex items-center justify-center mx-auto shadow-md">
                  <Zap className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-purple-950">{isEs ? "Inversión Web3 Polygon" : "Polygon Web3 Investment"}</h4>
                  <p className="text-xs text-purple-800 mt-1 max-w-sm mx-auto">
                    {isEs
                      ? `Equivalente: ${(totalPrice / 20).toFixed(2)} USDC. Los tokens ERC-20 / NFT ERC-721 se transferirán directamente a tu billetera Polygon conectada.`
                      : `Equivalent: ${(totalPrice / 20).toFixed(2)} USDC. Tokens transferred directly to your connected Polygon wallet.`}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleWalletInvestment}
                  className="w-full py-4 bg-purple-700 hover:bg-purple-800 text-white font-black rounded-2xl transition-all shadow-md flex items-center justify-center gap-2 text-sm"
                >
                  <span>{isEs ? "Firmar y Pagar en Polygon" : "Sign and Pay on Polygon"}</span>
                </button>
              </div>
            )}

          </div>
        </div>
      </div>

      {/* Payment Receipt Voucher Modal */}
      <PaymentReceiptModal
        receipt={receiptData}
        isOpen={showReceipt}
        onClose={() => {
          setShowReceipt(false);
          onClose();
        }}
        lang={lang}
      />
    </>
  );
};
