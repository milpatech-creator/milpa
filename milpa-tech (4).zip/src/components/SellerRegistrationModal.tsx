import React, { useState } from 'react';
import {
  X, ShieldCheck, CheckCircle2, AlertTriangle, FileText,
  Lock, Building, User, Phone, Mail, MapPin, Tag,
  DollarSign, Package, Sparkles, Check, ArrowRight, ArrowLeft,
  BadgeCheck, Info, ShieldAlert, Award
} from 'lucide-react';
import { UserProfile, MarketplaceItem, SellerRegistrationApplication, Language } from '../types';
import { db, sanitizeForFirestore } from '../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';

interface SellerRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  lang: Language;
  onSellerRegistered: (updatedUser: UserProfile, newItem?: MarketplaceItem) => void;
}

export const SellerRegistrationModal: React.FC<SellerRegistrationModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  lang,
  onSellerRegistered
}) => {
  if (!isOpen) return null;

  const isEs = lang === 'es';
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successToast, setSuccessToast] = useState(false);

  // Step 1: Legal & Tax Verification (Anti-Fraud KYC)
  const [legalName, setLegalName] = useState(currentUser?.name || '');
  const [rfc, setRfc] = useState(currentUser?.rfcTaxId || '');
  const [personType, setPersonType] = useState<'FISICA' | 'MORAL'>('FISICA');
  const [businessCategory, setBusinessCategory] = useState<string>('PRODUCER');
  const [phone, setPhone] = useState(currentUser?.phone || '+52 951 234 5678');
  const [email, setEmail] = useState(currentUser?.email || 'contacto@milpatech.org');
  const [address, setAddress] = useState(currentUser?.location || 'Oaxaca, México');
  const [stateRegion, setStateRegion] = useState('Oaxaca');

  // Step 2: Agricultural Certification & Fraud Prevention
  const [senasicaFolio, setSenasicaFolio] = useState('SENASICA-AGRO-2026-MX');
  const [organicCert, setOrganicCert] = useState('Certificado Orgánico SAGARPA / CERTIMEX');
  const [escrowAccepted, setEscrowAccepted] = useState(true);
  const [antiFraudAgreed, setAntiFraudAgreed] = useState(true);
  const [fraudScore, setFraudScore] = useState(98);

  // Step 3: Product / Service Registration
  const [itemTitle, setItemTitle] = useState('Biofertilizante Orgánico Concentrado (Lixiviado de Agave)');
  const [itemCategory, setItemCategory] = useState<'ORGANIC_INPUTS' | 'SEEDS' | 'MACHINERY' | 'SERVICES' | 'LOGISTICS' | 'HARVEST_PRODUCTS'>('ORGANIC_INPUTS');
  const [itemDescription, setItemDescription] = useState('Biofertilizante líquido 100% natural derivado de fermentación de jugos y bagazo de agave mezcalero. Rico en potasio, nitrógeno asimilable y microorganismos benéficos para regeneración de suelo.');
  const [itemPriceMxn, setItemPriceMxn] = useState<number>(450);
  const [itemUnit, setItemUnit] = useState('Garrafón 20L');
  const [itemStock, setItemStock] = useState<number>(85);
  const [itemImageUrl, setItemImageUrl] = useState('https://images.unsplash.com/photo-1585314062340-f1a5a7c9328d?q=80&w=800&auto=format&fit=crop');

  const handleNextStep = () => {
    if (step === 1) {
      if (!legalName.trim() || !rfc.trim() || !phone.trim() || !email.trim()) {
        alert(isEs ? "Por favor completa todos los campos requeridos de identificación legal." : "Please fill in all required legal identification fields.");
        return;
      }
      setStep(2);
    } else if (step === 2) {
      if (!escrowAccepted || !antiFraudAgreed) {
        alert(isEs ? "Debes aceptar los términos de garantía Smart Escrow y políticas anti-fraude." : "You must accept Smart Escrow terms and anti-fraud policies.");
        return;
      }
      setStep(3);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const sellerId = currentUser?.id || `user-seller-${Date.now()}`;
      const sellerName = legalName || currentUser?.name || 'Vendedor Verificado';

      // 1. Updated User Profile with Verified Seller Status
      const updatedUser: UserProfile = {
        ...(currentUser || {
          id: sellerId,
          name: sellerName,
          role: 'TRADER',
          balance: 25000,
          avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(sellerName)}&background=047857&color=fff`,
          joinedDate: new Date().toISOString().split('T')[0]
        }),
        name: sellerName,
        isVerifiedSeller: true,
        verificationLevel: 3,
        rfcTaxId: rfc.toUpperCase().trim(),
        legalName: legalName.trim(),
        phone: phone.trim(),
        email: email.trim(),
        location: address.trim(),
        fraudScore: fraudScore,
        escrowSecured: escrowAccepted,
        certifications: [organicCert, `SENASICA: ${senasicaFolio}`],
        badges: Array.from(new Set([...(currentUser?.badges || []), "Vendedor Verificado", "Garantía Escrow", "Identidad SAT Validada"]))
      };

      // 2. Newly Registered Marketplace Item
      const newItemId = `mkt-${Date.now()}`;
      const newProductItem: MarketplaceItem = {
        id: newItemId,
        sellerId: sellerId,
        sellerName: sellerName,
        sellerRole: updatedUser.role,
        sellerAvatar: updatedUser.avatar,
        sellerLocation: address.trim(),
        isVerified: true,
        title: itemTitle.trim(),
        category: itemCategory,
        description: itemDescription.trim(),
        priceMxn: Number(itemPriceMxn) || 100,
        unit: itemUnit.trim() || 'Unidad',
        availableStock: Number(itemStock) || 10,
        imageUrl: itemImageUrl.trim(),
        escrowProtected: true,
        fraudScore: fraudScore,
        certifications: [organicCert, "Garantía de Devolución 30 Días"],
        contactPhone: phone.trim(),
        contactEmail: email.trim(),
        createdAt: new Date().toISOString()
      };

      // 3. Seller Application Record for Firestore Audit Trail
      const verificationRecord: SellerRegistrationApplication = {
        id: `verif-${Date.now()}`,
        userId: sellerId,
        legalName: legalName.trim(),
        rfc: rfc.toUpperCase().trim(),
        personType: personType,
        businessCategory: businessCategory,
        address: address.trim(),
        state: stateRegion,
        phone: phone.trim(),
        email: email.trim(),
        sanitaryPermitSENASICA: senasicaFolio.trim(),
        organicCertProof: organicCert.trim(),
        escrowDepositAgreed: escrowAccepted,
        termsAccepted: antiFraudAgreed,
        verificationStatus: 'VERIFIED',
        fraudRiskAssessment: 'LOW',
        createdAt: new Date().toISOString()
      };

      // Persist to Firestore
      try {
        await setDoc(doc(db, 'users', sellerId), sanitizeForFirestore(updatedUser), { merge: true });
        await setDoc(doc(db, 'marketplace_items', newItemId), sanitizeForFirestore(newProductItem));
        await setDoc(doc(db, 'seller_verifications', verificationRecord.id), sanitizeForFirestore(verificationRecord));
        console.log("Seller and Marketplace product successfully registered to Firestore.");
      } catch (fbErr) {
        console.warn("Local persistence activated for seller registration:", fbErr);
      }

      onSellerRegistered(updatedUser, newProductItem);
      setSuccessToast(true);
      setTimeout(() => {
        setSuccessToast(false);
        onClose();
      }, 1600);
    } catch (err: any) {
      console.error("Seller registration error:", err);
      alert(isEs ? "Error al registrar vendedor. Revisa los datos." : "Error registering seller. Check your data.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto animate-fade-in">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden my-6">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-900 via-green-900 to-teal-950 p-6 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 text-emerald-300 hover:text-white bg-white/10 hover:bg-white/20 p-2 rounded-full transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
          
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/30 border border-emerald-400/40 flex items-center justify-center text-emerald-300">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold">
                {isEs ? "Alta de Vendedor & Proveedor Verificado" : "Verified Seller & Supplier Registration"}
              </h2>
              <p className="text-xs text-emerald-200/80">
                {isEs ? "Protocolo de Seguridad KYC, Prevención de Fraudes y Publicación de Productos" : "KYC Security Protocol, Fraud Prevention & Product Listing"}
              </p>
            </div>
          </div>

          {/* Stepper Indicator */}
          <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-emerald-800/60">
            <div className={`flex items-center gap-2 text-xs font-bold py-1 px-2.5 rounded-lg ${step === 1 ? 'bg-emerald-500 text-slate-950' : step > 1 ? 'bg-emerald-800/80 text-emerald-200' : 'bg-emerald-950 text-emerald-400/60'}`}>
              <span>1. {isEs ? "Identidad SAT" : "Tax ID"}</span>
              {step > 1 && <Check className="h-3.5 w-3.5 ml-auto" />}
            </div>
            <div className={`flex items-center gap-2 text-xs font-bold py-1 px-2.5 rounded-lg ${step === 2 ? 'bg-emerald-500 text-slate-950' : step > 2 ? 'bg-emerald-800/80 text-emerald-200' : 'bg-emerald-950 text-emerald-400/60'}`}>
              <span>2. {isEs ? "Anti-Fraude" : "Anti-Fraud"}</span>
              {step > 2 && <Check className="h-3.5 w-3.5 ml-auto" />}
            </div>
            <div className={`flex items-center gap-2 text-xs font-bold py-1 px-2.5 rounded-lg ${step === 3 ? 'bg-emerald-500 text-slate-950' : 'bg-emerald-950 text-emerald-400/60'}`}>
              <span>3. {isEs ? "Catálogo" : "Catalog"}</span>
            </div>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          
          {/* STEP 1: Identification & Legal */}
          {step === 1 && (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-emerald-50 border border-emerald-200 p-3.5 rounded-2xl flex items-start gap-3 text-emerald-900 text-xs">
                <Info className="h-4 w-4 text-emerald-700 shrink-0 mt-0.5" />
                <p>
                  {isEs
                    ? "Para prevenir fraudes y proteger a compradores e inversores, todo vendedor debe validar su identidad y registro fiscal oficial."
                    : "To prevent fraud and protect buyers and investors, all sellers must validate their identity and official tax registration."}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isEs ? "Nombre Completo o Razón Social *" : "Legal Name or Company Name *"}
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <input
                      type="text"
                      value={legalName}
                      onChange={(e) => setLegalName(e.target.value)}
                      placeholder={isEs ? "Ej. AgroInsumos del Valle S.P.R. de R.I." : "e.g. Organic Ag Supplies LLC"}
                      className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isEs ? "RFC (Registro Federal de Contribuyentes) *" : "Tax ID / RFC *"}
                  </label>
                  <div className="relative">
                    <FileText className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <input
                      type="text"
                      value={rfc}
                      onChange={(e) => setRfc(e.target.value.toUpperCase())}
                      placeholder="XAXX010101000 / AIV980415..."
                      className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none uppercase font-mono"
                      required
                      maxLength={13}
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isEs ? "Tipo de Persona Fiscal" : "Tax Entity Type"}
                  </label>
                  <select
                    value={personType}
                    onChange={(e) => setPersonType(e.target.value as any)}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="FISICA">{isEs ? "Persona Física con Actividad Empresarial" : "Individual / Sole Proprietor"}</option>
                    <option value="MORAL">{isEs ? "Persona Moral / Cooperativa Agrícola" : "Corporation / Agricultural Co-op"}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isEs ? "Giro Comercial Principal" : "Primary Business Category"}
                  </label>
                  <select
                    value={businessCategory}
                    onChange={(e) => setBusinessCategory(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="PRODUCER">{isEs ? "Productor Directo de Cosechas" : "Direct Crop Producer"}</option>
                    <option value="INPUTS_SUPPLIER">{isEs ? "Proveedor de Insumos y Fertilizantes Orgánicos" : "Organic Inputs & Fertilizers"}</option>
                    <option value="SEEDS_PRODUCER">{isEs ? "Productor de Semillas Criollas Certificadas" : "Certified Native Seeds"}</option>
                    <option value="AGRONOMY_SERVICES">{isEs ? "Servicios Agronómicos y Monitoreo Dron" : "Agronomic & Drone Services"}</option>
                    <option value="MACHINERY">{isEs ? "Venta o Renta de Maquinaria Agrícola" : "Agricultural Machinery"}</option>
                    <option value="LOGISTICS">{isEs ? "Transporte y Logística Rural" : "Rural Transport & Logistics"}</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isEs ? "Teléfono con WhatsApp *" : "Phone (WhatsApp verified) *"}
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+52 951 000 0000"
                      className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isEs ? "Correo Electrónico Oficial *" : "Official Email *"}
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="ventas@proveedor.mx"
                      className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      required
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isEs ? "Ubicación de Despacho / Parcela / Bodega *" : "Dispatch / Farm / Warehouse Location *"}
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder={isEs ? "Carretera Internacional Km 24, Tlacolula, Oaxaca, México" : "Highway Km 24, Oaxaca, Mexico"}
                    className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={handleNextStep}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-2.5 rounded-xl text-sm flex items-center gap-2 shadow-md transition-colors"
                >
                  <span>{isEs ? "Siguiente: Medidas Anti-Fraude" : "Next: Anti-Fraud Verification"}</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Anti-Fraud & Verification Protocol */}
          {step === 2 && (
            <div className="space-y-5 animate-fade-in">
              <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl flex items-start gap-3 text-amber-900 text-xs">
                <ShieldAlert className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-amber-950 mb-0.5">
                    {isEs ? "Garantía de Cero Fraudes y Protección de Fondos" : "Zero-Fraud Guarantee & Buyer Fund Protection"}
                  </h4>
                  <p>
                    {isEs
                      ? "Milpa Tech utiliza Smart Contracts de Custodia (Escrow) en Polygon. Los pagos de los compradores se retienen en depósito seguro y se liberan únicamente cuando el comprador confirma la recepción conforme de los insumos o servicios."
                      : "Milpa Tech leverages Polygon Smart Escrow contracts. Buyer payments are held securely and only disbursed once the buyer confirms satisfactory product delivery."}
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isEs ? "Folio de Registro Fitosanitario / SENASICA / Sagarpa" : "Sanitary & Agricultural Permit ID (SENASICA)"}
                  </label>
                  <input
                    type="text"
                    value={senasicaFolio}
                    onChange={(e) => setSenasicaFolio(e.target.value)}
                    placeholder="SENASICA-AGRO-2026-MX / SAGARPA-REG-882"
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isEs ? "Certificaciones de Calidad e Inocuidad Orgánica" : "Organic Quality & Safety Certifications"}
                  </label>
                  <input
                    type="text"
                    value={organicCert}
                    onChange={(e) => setOrganicCert(e.target.value)}
                    placeholder={isEs ? "Certificado Orgánico Sagarpa, CERTIMEX, GlobalG.A.P." : "USDA Organic, CERTIMEX, GlobalG.A.P."}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                {/* Anti-Fraud Trust Meter */}
                <div className="bg-slate-900 text-white p-4 rounded-2xl border border-emerald-500/40">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="h-5 w-5 text-emerald-400" />
                      <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
                        {isEs ? "Score de Confianza Anti-Fraude Calculado" : "Calculated Anti-Fraud Trust Score"}
                      </span>
                    </div>
                    <span className="text-lg font-black text-emerald-400 font-mono">{fraudScore}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden mb-3">
                    <div className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full w-[98%]" />
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-[11px] text-slate-300">
                    <div className="flex items-center gap-1.5">
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                      <span>{isEs ? "RFC Validado" : "Tax ID Valid"}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                      <span>{isEs ? "Geolocalización" : "GPS Verified"}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                      <span>{isEs ? "Smart Escrow" : "Smart Escrow"}</span>
                    </div>
                  </div>
                </div>

                {/* Checkboxes */}
                <div className="space-y-3 pt-2">
                  <label className="flex items-start gap-3 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={escrowAccepted}
                      onChange={(e) => setEscrowAccepted(e.target.checked)}
                      className="mt-1 h-4 w-4 text-emerald-600 rounded focus:ring-emerald-500 border-slate-300"
                    />
                    <span className="text-xs text-slate-700">
                      {isEs
                        ? "Acepto el mecanismo de depósito en garantía Smart Escrow para todas las transacciones dentro del Marketplace de Milpa Tech."
                        : "I agree to the Smart Escrow guarantee mechanism for all marketplace transactions on Milpa Tech."}
                    </span>
                  </label>

                  <label className="flex items-start gap-3 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={antiFraudAgreed}
                      onChange={(e) => setAntiFraudAgreed(e.target.checked)}
                      className="mt-1 h-4 w-4 text-emerald-600 rounded focus:ring-emerald-500 border-slate-300"
                    />
                    <span className="text-xs text-slate-700">
                      {isEs
                        ? "Certifico que los insumos y servicios ofrecidos cumplen con las normas sanitarias mexicanas y garantizo 100% de autenticidad libre de fraude."
                        : "I certify that all items and services comply with official safety standards and guarantee 100% fraud-free authenticity."}
                    </span>
                  </label>
                </div>
              </div>

              <div className="flex justify-between items-center pt-2">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-900 font-bold text-xs flex items-center gap-1.5"
                >
                  <ArrowLeft className="h-4 w-4" />
                  <span>{isEs ? "Regresar" : "Back"}</span>
                </button>

                <button
                  type="button"
                  onClick={handleNextStep}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-2.5 rounded-xl text-sm flex items-center gap-2 shadow-md transition-colors"
                >
                  <span>{isEs ? "Siguiente: Dar de Alta Producto" : "Next: Add First Product"}</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Catalog Registration */}
          {step === 3 && (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-teal-50 border border-teal-200 p-3.5 rounded-2xl flex items-start gap-3 text-teal-950 text-xs">
                <Package className="h-4 w-4 text-teal-700 shrink-0 mt-0.5" />
                <p>
                  {isEs
                    ? "Registra tu primer producto o servicio agrícola. Quedará publicado de inmediato en el Marketplace comunitario con tu insignia de Vendedor Verificado."
                    : "List your first agricultural product or service. It will be published immediately in the community Marketplace with your Verified Seller badge."}
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isEs ? "Título del Producto o Servicio *" : "Product or Service Title *"}
                </label>
                <input
                  type="text"
                  value={itemTitle}
                  onChange={(e) => setItemTitle(e.target.value)}
                  placeholder={isEs ? "Ej. Biofertilizante Orgánico Lixiviado de Agave 20L" : "e.g. Organic Agave Biofertilizer 20L"}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none font-semibold"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isEs ? "Categoría del Catálogo" : "Catalog Category"}
                  </label>
                  <select
                    value={itemCategory}
                    onChange={(e) => setItemCategory(e.target.value as any)}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="ORGANIC_INPUTS">{isEs ? "🌱 Insumos y Fertilizantes Orgánicos" : "🌱 Organic Inputs & Fertilizers"}</option>
                    <option value="SEEDS">{isEs ? "🌽 Semillas Criollas Certificadas" : "🌽 Certified Native Seeds"}</option>
                    <option value="MACHINERY">{isEs ? "🚜 Maquinaria y Equipos Agrícolas" : "🚜 Farm Machinery & Equipment"}</option>
                    <option value="SERVICES">{isEs ? "🛰️ Servicios Agronómicos y Drones NDVI" : "🛰️ Agronomic & Drone Services"}</option>
                    <option value="LOGISTICS">{isEs ? "🚛 Transporte y Fletes Rurales" : "🚛 Rural Freight & Transport"}</option>
                    <option value="HARVEST_PRODUCTS">{isEs ? "📦 Cosechas Procesadas / Granos" : "📦 Processed Harvests / Grains"}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isEs ? "Unidad de Venta" : "Selling Unit"}
                  </label>
                  <input
                    type="text"
                    value={itemUnit}
                    onChange={(e) => setItemUnit(e.target.value)}
                    placeholder={isEs ? "Garrafón 20L / Costal 50kg / Servicio" : "20L Jug / 50kg Bag / Service"}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isEs ? "Precio Unitario ($ MXN) *" : "Unit Price ($ MXN) *"}
                  </label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <input
                      type="number"
                      value={itemPriceMxn}
                      onChange={(e) => setItemPriceMxn(Number(e.target.value))}
                      className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none font-bold"
                      min={1}
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isEs ? "Stock o Disponibilidad Inmediata" : "Available Stock / Units"}
                  </label>
                  <input
                    type="number"
                    value={itemStock}
                    onChange={(e) => setItemStock(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none font-bold"
                    min={1}
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isEs ? "Descripción Técnica y Beneficios" : "Technical Description & Benefits"}
                </label>
                <textarea
                  value={itemDescription}
                  onChange={(e) => setItemDescription(e.target.value)}
                  rows={3}
                  className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  placeholder={isEs ? "Describe composición, dosis recomendada, certificaciones y tiempos de entrega..." : "Describe formulation, dosage, certifications..."}
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isEs ? "URL de Foto del Producto / Catálogo" : "Product Photo URL"}
                </label>
                <input
                  type="url"
                  value={itemImageUrl}
                  onChange={(e) => setItemImageUrl(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono"
                  required
                />
              </div>

              <div className="flex justify-between items-center pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-900 font-bold text-xs flex items-center gap-1.5"
                >
                  <ArrowLeft className="h-4 w-4" />
                  <span>{isEs ? "Regresar" : "Back"}</span>
                </button>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-gradient-to-r from-emerald-600 to-green-700 hover:from-emerald-700 hover:to-green-800 text-white font-bold px-8 py-3 rounded-2xl text-sm flex items-center gap-2 shadow-lg shadow-emerald-900/20 disabled:opacity-50 transition-all cursor-pointer"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>{isEs ? "Validando en Blockchain & SAT..." : "Validating on Blockchain & SAT..."}</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="h-5 w-5" />
                      <span>{isEs ? "Completar Registro y Publicar" : "Complete Registration & Publish"}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </form>

        {/* Success Toast */}
        {successToast && (
          <div className="absolute inset-0 bg-emerald-950/95 flex flex-col items-center justify-center text-center p-6 text-white animate-fade-in z-50">
            <div className="w-16 h-16 rounded-full bg-emerald-500/30 border border-emerald-400 flex items-center justify-center text-emerald-300 mb-4 animate-bounce">
              <CheckCircle2 className="h-10 w-10" />
            </div>
            <h3 className="text-2xl font-black mb-2">
              {isEs ? "¡Vendedor Verificado Registrado Exitosamente!" : "Verified Seller Registered Successfully!"}
            </h3>
            <p className="text-sm text-emerald-200 max-w-md">
              {isEs
                ? "Tu perfil ha sido certificado con nivel de seguridad anti-fraude y tu producto ya está disponible en el Marketplace Comunitario."
                : "Your profile has been certified with anti-fraud protection and your product is now live on the Community Marketplace."}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
