import React, { useState, useMemo } from 'react';
import {
  Users, Search, ShieldCheck, MapPin, Award, Star,
  MessageSquare, ShoppingBag, Handshake, Filter, Plus,
  CheckCircle2, AlertTriangle, Sparkles, Building2, UserCheck,
  ChevronRight, Phone, Mail, ExternalLink, RefreshCw, Lock,
  Sprout, Coins, Store, ArrowUpRight
} from 'lucide-react';
import { UserProfile, Language, Crop, MarketplaceItem, PeerReview, Message } from '../types';

interface CommunityDirectoryViewProps {
  users?: UserProfile[];
  currentUser: UserProfile | null;
  lang: Language;
  crops?: Crop[];
  marketplaceItems?: MarketplaceItem[];
  reviews?: PeerReview[];
  onOpenUserProfile: (user: UserProfile) => void;
  onOpenDirectChat: (user: UserProfile) => void;
  onOpenSellerRegistration: () => void;
  onOpenMarketplaceItem: (item: MarketplaceItem) => void;
  onInvestInProducer?: (crop: Crop) => void;
  onSyncDatabase?: () => void;
  onCreateMarketplaceItem?: (item: MarketplaceItem) => void;
  onLoginRequired?: (role?: string) => void;
}

export const CommunityDirectoryView: React.FC<CommunityDirectoryViewProps> = ({
  users = [],
  currentUser,
  lang,
  crops = [],
  marketplaceItems = [],
  reviews = [],
  onOpenUserProfile,
  onOpenDirectChat,
  onOpenSellerRegistration,
  onOpenMarketplaceItem,
  onInvestInProducer,
  onSyncDatabase,
  onCreateMarketplaceItem,
  onLoginRequired
}) => {
  const isEs = lang === 'es';

  // Safe array references
  const safeUsers = users || [];
  const safeCrops = crops || [];
  const safeMarketplaceItems = marketplaceItems || [];
  const safeReviews = reviews || [];

  // Active Role Filter Tab: ALL | PRODUCER | INVESTOR | TRADER
  const [activeRoleTab, setActiveRoleTab] = useState<'ALL' | 'PRODUCER' | 'INVESTOR' | 'TRADER'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterVerifiedOnly, setFilterVerifiedOnly] = useState(false);
  const [filterEscrowOnly, setFilterEscrowOnly] = useState(false);
  const [selectedState, setSelectedState] = useState<string>('ALL');

  // Compute stats
  const totalUsers = safeUsers.length;
  const producerCount = safeUsers.filter(u => u && u.role === 'PRODUCER').length;
  const investorCount = safeUsers.filter(u => u && u.role === 'INVESTOR').length;
  const traderCount = safeUsers.filter(u => u && (u.role === 'TRADER' || u.isVerifiedSeller)).length;
  const verifiedCount = safeUsers.filter(u => u && (u.isVerifiedSeller || u.verificationLevel === 3 || (u.badges && u.badges.length > 0))).length;

  // Extract unique locations for filtering
  const availableStates = useMemo(() => {
    const states = new Set<string>();
    safeUsers.forEach(u => {
      if (u && u.location) {
        const parts = u.location.split(',');
        states.add(parts[0].trim());
      }
    });
    return Array.from(states);
  }, [safeUsers]);

  // Filtered Users List
  const filteredUsers = useMemo(() => {
    return safeUsers.filter(user => {
      if (!user) return false;
      // 1. Role Filter
      if (activeRoleTab !== 'ALL') {
        if (activeRoleTab === 'TRADER') {
          if (user.role !== 'TRADER' && !user.isVerifiedSeller) return false;
        } else if (user.role !== activeRoleTab) {
          return false;
        }
      }

      // 2. Verified Only Filter
      if (filterVerifiedOnly) {
        const isVerif = user.isVerifiedSeller || user.verificationLevel === 3 || (user.badges && user.badges.some(b => b.includes('Verificado') || b.includes('SAT')));
        if (!isVerif) return false;
      }

      // 3. Escrow Only Filter
      if (filterEscrowOnly && !user.escrowSecured) {
        return false;
      }

      // 4. State Filter
      if (selectedState !== 'ALL') {
        if (!user.location || !user.location.toLowerCase().includes(selectedState.toLowerCase())) {
          return false;
        }
      }

      // 5. Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = user.name.toLowerCase().includes(q);
        const matchesBio = (user.bio || '').toLowerCase().includes(q);
        const matchesLocation = (user.location || '').toLowerCase().includes(q);
        const matchesCert = Array.isArray(user.certifications)
          ? user.certifications.some(c => c.toLowerCase().includes(q))
          : (user.certifications || '').toLowerCase().includes(q);
        const matchesRfc = (user.rfcTaxId || '').toLowerCase().includes(q);

        if (!matchesName && !matchesBio && !matchesLocation && !matchesCert && !matchesRfc) {
          return false;
        }
      }

      return true;
    });
  }, [users, activeRoleTab, filterVerifiedOnly, filterEscrowOnly, selectedState, searchQuery]);

  return (
    <div className="space-y-8 animate-fade-in" id="community-directory-view">
      
      {/* Hero Header & Quick Actions */}
      <div className="bg-gradient-to-br from-emerald-950 via-green-900 to-slate-950 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden border border-emerald-800/60 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-80 h-80 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-bold uppercase tracking-wider">
              <Users className="h-3.5 w-3.5" />
              <span>{isEs ? "Ecosistema & Directorio Registrado" : "Registered Ecosystem & Directory"}</span>
            </div>
            
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white">
              {isEs ? "Comunidad de Productores, Inversores y Vendedores" : "Community of Producers, Investors & Sellers"}
            </h1>
            
            <p className="text-sm sm:text-base text-emerald-200/90 leading-relaxed">
              {isEs
                ? "Conecta directamente con productores certificados, inversores agrofinancieros y proveedores del Marketplace con verificación de identidad, trazabilidad en blockchain y protección anti-fraude."
                : "Connect directly with certified farmers, impact investors, and verified marketplace vendors with identity verification, blockchain traceability, and anti-fraud escrow."}
            </p>
          </div>

          {/* Quick Action CTA Buttons */}
          <div className="flex flex-col sm:flex-row md:flex-col gap-3 shrink-0">
            <button
              onClick={onOpenSellerRegistration}
              className="bg-gradient-to-r from-amber-500 to-emerald-500 hover:from-amber-600 hover:to-emerald-600 text-slate-950 font-black px-6 py-3.5 rounded-2xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
            >
              <ShieldCheck className="h-5 w-5" />
              <span>{isEs ? "🛡️ Dar de Alta como Vendedor" : "🛡️ Register as Verified Seller"}</span>
            </button>

            {onSyncDatabase && (
              <button
                onClick={onSyncDatabase}
                className="bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <RefreshCw className="h-4 w-4 text-emerald-400" />
                <span>{isEs ? "Sincronizar con Firestore" : "Sync with Firestore"}</span>
              </button>
            )}
          </div>
        </div>

        {/* Real-Time Ecosystem Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mt-8 pt-6 border-t border-emerald-800/60">
          <div className="bg-white/5 backdrop-blur-sm border border-emerald-500/20 p-4 rounded-2xl">
            <div className="flex items-center gap-2 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-1">
              <Users className="h-4 w-4" />
              <span>{isEs ? "Usuarios Totales" : "Total Users"}</span>
            </div>
            <span className="text-2xl font-black text-white font-mono">{totalUsers}</span>
          </div>

          <div className="bg-white/5 backdrop-blur-sm border border-emerald-500/20 p-4 rounded-2xl">
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider mb-1">
              <Sprout className="h-4 w-4" />
              <span>{isEs ? "Productores / Fincas" : "Producers / Farms"}</span>
            </div>
            <span className="text-2xl font-black text-emerald-400 font-mono">{producerCount}</span>
          </div>

          <div className="bg-white/5 backdrop-blur-sm border border-blue-500/20 p-4 rounded-2xl">
            <div className="flex items-center gap-2 text-blue-300 text-xs font-bold uppercase tracking-wider mb-1">
              <Coins className="h-4 w-4" />
              <span>{isEs ? "Inversionistas Activos" : "Active Investors"}</span>
            </div>
            <span className="text-2xl font-black text-blue-300 font-mono">{investorCount}</span>
          </div>

          <div className="bg-white/5 backdrop-blur-sm border border-amber-500/20 p-4 rounded-2xl">
            <div className="flex items-center gap-2 text-amber-300 text-xs font-bold uppercase tracking-wider mb-1">
              <Store className="h-4 w-4" />
              <span>{isEs ? "Vendedores Verificados" : "Verified Sellers"}</span>
            </div>
            <span className="text-2xl font-black text-amber-300 font-mono">{verifiedCount}</span>
          </div>
        </div>
      </div>

      {/* Role Navigation Filter Tabs */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-3 rounded-2xl border border-slate-200/80 shadow-sm">
        
        {/* Role Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
          <button
            onClick={() => setActiveRoleTab('ALL')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeRoleTab === 'ALL'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Users className="h-4 w-4" />
            <span>{isEs ? "Todos los Usuarios" : "All Users"} ({totalUsers})</span>
          </button>

          <button
            onClick={() => setActiveRoleTab('PRODUCER')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeRoleTab === 'PRODUCER'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Sprout className="h-4 w-4" />
            <span>👨‍🌾 {isEs ? "Productores Agrícolas" : "Producers"} ({producerCount})</span>
          </button>

          <button
            onClick={() => setActiveRoleTab('INVESTOR')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeRoleTab === 'INVESTOR'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Coins className="h-4 w-4" />
            <span>💼 {isEs ? "Inversionistas" : "Investors"} ({investorCount})</span>
          </button>

          <button
            onClick={() => setActiveRoleTab('TRADER')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeRoleTab === 'TRADER'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Store className="h-4 w-4" />
            <span>🛒 {isEs ? "Marketplace & Vendedores" : "Marketplace Sellers"} ({traderCount})</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative min-w-[260px] flex-1 max-w-md">
          <Search className="absolute left-3.5 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isEs ? "Buscar por nombre, estado, cultivo o insumo..." : "Search name, state, crop, or goods..."}
            className="w-full pl-10 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-700"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Secondary Fast Filters */}
      <div className="flex flex-wrap items-center gap-3 text-xs">
        <label className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200 bg-white cursor-pointer select-none font-semibold text-slate-700 hover:bg-slate-50">
          <input
            type="checkbox"
            checked={filterVerifiedOnly}
            onChange={(e) => setFilterVerifiedOnly(e.target.checked)}
            className="h-3.5 w-3.5 text-emerald-600 rounded focus:ring-emerald-500 border-slate-300"
          />
          <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
          <span>{isEs ? "Solo Verificados Anti-Fraude (SAT / SENASICA)" : "Verified Anti-Fraud Only"}</span>
        </label>

        <label className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200 bg-white cursor-pointer select-none font-semibold text-slate-700 hover:bg-slate-50">
          <input
            type="checkbox"
            checked={filterEscrowOnly}
            onChange={(e) => setFilterEscrowOnly(e.target.checked)}
            className="h-3.5 w-3.5 text-blue-600 rounded focus:ring-blue-500 border-slate-300"
          />
          <Lock className="h-3.5 w-3.5 text-blue-600" />
          <span>{isEs ? "Con Smart Escrow Activo" : "Smart Escrow Active"}</span>
        </label>

        {availableStates.length > 0 && (
          <div className="flex items-center gap-1.5 ml-auto">
            <MapPin className="h-3.5 w-3.5 text-slate-400" />
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="text-xs bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 font-semibold text-slate-700 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            >
              <option value="ALL">{isEs ? "Todos los Estados" : "All Mexican States"}</option>
              {availableStates.map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Grid of User Profiles */}
      {filteredUsers.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <Search className="h-8 w-8" />
          </div>
          <h3 className="text-lg font-bold text-slate-800">
            {isEs ? "No se encontraron usuarios registrados con esos criterios" : "No registered users matched your criteria"}
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            {isEs
              ? "Prueba eliminando algunos filtros o utiliza el botón para registrar a un nuevo vendedor o productor verificado."
              : "Try clearing some filters or register a new verified seller or producer."}
          </p>
          <button
            onClick={() => { setSearchQuery(''); setActiveRoleTab('ALL'); setFilterVerifiedOnly(false); setFilterEscrowOnly(false); setSelectedState('ALL'); }}
            className="text-xs font-bold text-emerald-600 hover:text-emerald-700 underline"
          >
            {isEs ? "Restablecer todos los filtros" : "Reset all filters"}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredUsers.map((user) => {
            const isSelf = currentUser?.id === user.id;
            
            // Associated crops and products for this user safely
            const userCrops = safeCrops.filter(c => c && (c.producerName?.toLowerCase().includes(user.name.toLowerCase()) || c.producerId === user.id));
            const userItems = safeMarketplaceItems.filter(i => i && (i.sellerId === user.id || i.sellerName?.toLowerCase().includes(user.name.toLowerCase())));
            
            // User reviews safely
            const userReviews = safeReviews.filter(r => r && (r.targetUserId === user.id || r.targetUserId === user.name));
            const ratingScore = user.rating || 4.9;

            const isProducer = user.role === 'PRODUCER';
            const isInvestor = user.role === 'INVESTOR';
            const isTraderOrSeller = user.role === 'TRADER' || user.isVerifiedSeller;

            return (
              <div
                key={user.id}
                className="bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-xl hover:border-emerald-300 transition-all duration-300 overflow-hidden flex flex-col group"
              >
                {/* Card Top Banner / Role Ribbon */}
                <div className={`p-4 text-white relative ${
                  isProducer
                    ? 'bg-gradient-to-r from-emerald-800 to-green-900'
                    : isInvestor
                    ? 'bg-gradient-to-r from-blue-900 to-slate-900'
                    : 'bg-gradient-to-r from-amber-700 to-amber-900'
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur-sm border border-white/20 flex items-center gap-1.5">
                      {isProducer && <span>🌱 {isEs ? "Productor Agrícola" : "Producer"}</span>}
                      {isInvestor && <span>💼 {isEs ? "Inversionista Agro" : "Investor"}</span>}
                      {isTraderOrSeller && <span>🛒 {isEs ? "Vendedor Marketplace" : "Marketplace Seller"}</span>}
                    </span>

                    {/* Anti-Fraud Trust Badge */}
                    <div className="flex items-center gap-1 bg-slate-950/40 px-2 py-0.5 rounded-full text-[10px] font-mono text-emerald-300 border border-emerald-400/30">
                      <ShieldCheck className="h-3 w-3 text-emerald-400" />
                      <span>{user.fraudScore || 98}% {isEs ? "Confianza" : "Trust"}</span>
                    </div>
                  </div>
                </div>

                {/* Main Card Content */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  
                  {/* User Avatar & Identity Details */}
                  <div className="flex items-start gap-3.5">
                    <div className="relative shrink-0">
                      <img
                        src={user.avatar}
                        alt={user.name}
                        className="w-14 h-14 rounded-2xl object-cover border-2 border-slate-100 shadow-sm group-hover:scale-105 transition-transform"
                      />
                      <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-white rounded-full" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <h3 className="font-bold text-slate-900 text-base truncate leading-tight group-hover:text-emerald-700 transition-colors">
                          {user.name}
                        </h3>
                      </div>

                      {user.location && (
                        <p className="text-xs text-slate-500 flex items-center gap-1 mt-1 truncate">
                          <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                          <span>{user.location}</span>
                        </p>
                      )}

                      {/* Ratings & Endorsements */}
                      <div className="flex items-center gap-2 mt-1.5 text-xs">
                        <div className="flex items-center gap-0.5 text-amber-500 font-bold">
                          <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                          <span>{ratingScore.toFixed(1)}</span>
                        </div>
                        <span className="text-slate-300">•</span>
                        <span className="text-slate-500 text-[11px]">
                          {userReviews.length} {isEs ? "reseñas" : "reviews"}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Bio snippet */}
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {user.bio || (isEs ? "Miembro verificado en el ecosistema agroecológico de Milpa Tech." : "Verified participant on Milpa Tech.")}
                  </p>

                  {/* Security & Verification Badges */}
                  <div className="flex flex-wrap gap-1.5">
                    {/* KYC/AML Tier Status Badge */}
                    <span
                      onClick={() => onOpenUserProfile(user)}
                      className="bg-emerald-100/90 text-emerald-900 border border-emerald-300/80 text-[10px] font-black px-2.5 py-0.5 rounded-md flex items-center gap-1 shadow-xs cursor-pointer hover:bg-emerald-200 transition-colors"
                      title={isEs ? "Usuario con Verificación de Identidad KYC y Filtro AML Aprobados" : "KYC & AML Verified User"}
                    >
                      <ShieldCheck className="h-3.5 w-3.5 text-emerald-700" />
                      <span>{isEs ? `KYC Nivel ${user.verificationLevel || 3} • AML Clean` : `KYC Tier ${user.verificationLevel || 3} • AML Clear`}</span>
                    </span>

                    {user.rfcTaxId && (
                      <span className="bg-slate-100 text-slate-800 border border-slate-200 text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1">
                        <CheckCircle2 className="h-3 w-3 text-emerald-600" />
                        <span>RFC: {user.rfcTaxId}</span>
                      </span>
                    )}

                    {user.escrowSecured !== false && (
                      <span className="bg-blue-50 text-blue-800 border border-blue-200 text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1">
                        <Lock className="h-3 w-3 text-blue-600" />
                        <span>Smart Escrow</span>
                      </span>
                    )}

                    {user.farmHectares && (
                      <span className="bg-slate-100 text-slate-700 text-[10px] font-semibold px-2 py-0.5 rounded-md">
                        🌾 {user.farmHectares} {isEs ? "Hectáreas" : "Hectares"}
                      </span>
                    )}
                  </div>

                  {/* Associated Crops (If Producer) */}
                  {isProducer && userCrops.length > 0 && (
                    <div className="bg-emerald-50/50 border border-emerald-200/60 p-2.5 rounded-xl space-y-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 block">
                        {isEs ? "Cultivos Tokenizados Activos:" : "Active Tokenized Crops:"}
                      </span>
                      <div className="space-y-1">
                        {userCrops.slice(0, 2).map(c => (
                          <div key={c.id} className="flex items-center justify-between text-xs font-semibold text-emerald-950">
                            <span>🌱 {c.name}</span>
                            <span className="text-emerald-700 font-mono">${c.tokenPrice} MXN ({c.yieldProjection}%)</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Associated Products & Services (If Marketplace Seller) */}
                  {userItems.length > 0 && (
                    <div className="bg-amber-50/50 border border-amber-200/60 p-2.5 rounded-xl space-y-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 block">
                        {isEs ? "Insumos y Servicios en Catálogo:" : "Catalog Items & Services:"}
                      </span>
                      <div className="space-y-1">
                        {userItems.slice(0, 2).map(item => (
                          <div
                            key={item.id}
                            onClick={() => onOpenMarketplaceItem(item)}
                            className="flex items-center justify-between text-xs font-semibold text-amber-950 cursor-pointer hover:underline"
                          >
                            <span className="truncate pr-2">📦 {item.title}</span>
                            <span className="text-amber-700 font-mono shrink-0">${item.priceMxn} MXN</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Interactive Action Buttons */}
                  <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => onOpenDirectChat(user)}
                        className="w-full bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-95"
                      >
                        <MessageSquare className="h-3.5 w-3.5 text-emerald-600" />
                        <span>{isEs ? "Enviar Mensaje" : "Message"}</span>
                      </button>

                      <button
                        onClick={() => onOpenUserProfile(user)}
                        className="w-full bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 active:scale-95"
                      >
                        <UserCheck className="h-3.5 w-3.5 text-slate-500" />
                        <span>{isEs ? "Ver Perfil" : "View Profile"}</span>
                      </button>
                    </div>

                    {/* Producer Specific Action: Invertir en sus lotes */}
                    {isProducer && userCrops.length > 0 && onInvestInProducer && (
                      <button
                        onClick={() => onInvestInProducer(userCrops[0])}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-md shadow-emerald-900/10"
                      >
                        <Handshake className="h-3.5 w-3.5" />
                        <span>{isEs ? `Invertir en ${userCrops[0].name}` : `Invest in ${userCrops[0].name}`}</span>
                      </button>
                    )}

                    {/* Seller Specific Action: Ver productos */}
                    {userItems.length > 0 && (
                      <button
                        onClick={() => onOpenMarketplaceItem(userItems[0])}
                        className="w-full bg-amber-600 hover:bg-amber-700 text-white py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-md shadow-amber-900/10"
                      >
                        <ShoppingBag className="h-3.5 w-3.5" />
                        <span>{isEs ? `Comprar Insumos (${userItems.length})` : `Buy Supplies (${userItems.length})`}</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
