import React, { useState } from 'react';
import {
  Sprout, Coins, ShoppingCart, Brain, ShieldCheck, CheckCircle2,
  TrendingUp, Users, Award, ChevronRight, ChevronLeft, ArrowRight,
  FileCheck, Shield, Sparkles, Building, Globe, Zap, HeartHandshake,
  Check, Layers, BookOpen, Presentation, SlidersHorizontal, Download
} from 'lucide-react';
import { Language } from '../types';
import { MilpaLogo } from './MilpaLogo';

interface AboutUsViewProps {
  lang: Language;
  onRegisterProducer: () => void;
  onRegisterInvestor: () => void;
  onRegisterTrader?: () => void;
  onExploreMarketplace: () => void;
  onOpenAiBot: () => void;
}

export const AboutUsView: React.FC<AboutUsViewProps> = ({
  lang,
  onRegisterProducer,
  onRegisterInvestor,
  onRegisterTrader,
  onExploreMarketplace,
  onOpenAiBot
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'model' | 'tech' | 'advantages' | 'audience' | 'invitation'>('all');
  const [viewMode, setViewMode] = useState<'document' | 'deck'>('document');
  const [currentSlide, setCurrentSlide] = useState(0);

  const isEs = lang === 'es';

  const slides = [
    {
      id: "intro",
      tag: isEs ? "PÁGINA 1 • INTRODUCCIÓN" : "PAGE 1 • INTRODUCTION",
      title: isEs ? "MILPA TECH – PLATAFORMA DE INVERSIÓN, COMERCIALIZACIÓN Y TECNOLOGÍA AGRÍCOLA" : "MILPA TECH – INVESTMENT, COMMERCIALIZATION & AGRI-TECH PLATFORM",
      subtitle: isEs
        ? "Conoce y forma parte de Milpa Tech, una plataforma tecnológica mexicana diseñada para transformar la manera en que el campo accede a financiamiento, mercados y herramientas digitales, conectando directamente a productores con inversionistas reales, compradores y servicios especializados, sin intermediarios innecesarios."
        : "Discover and join Milpa Tech, a Mexican technological platform designed to transform how agriculture accesses financing, markets, and digital tools, directly connecting producers with real investors, buyers, and specialized services, cutting out unnecessary intermediaries.",
      mission: isEs
        ? "Fortalecer al productor, mejorar su rentabilidad y darle acceso a oportunidades que hoy están reservadas solo para grandes actores del sector."
        : "Empower the producer, improve their profitability, and provide access to opportunities currently reserved only for major industry players.",
      elements: [
        {
          num: "1",
          title: isEs ? "Tokenización de cosechas" : "Harvest Tokenization",
          desc: isEs ? "Financiamiento anticipado mediante contratos inteligentes." : "Advance financing via smart contracts."
        },
        {
          num: "2",
          title: isEs ? "Marketplace de productos agrícolas" : "Agricultural Products Marketplace",
          desc: isEs ? "Venta directa de cosechas a compradores globales." : "Direct sales of harvests to global buyers."
        },
        {
          num: "3",
          title: isEs ? "Marketplace de servicios y asesorías técnicas" : "Services & Technical Consulting Marketplace",
          desc: isEs ? "Certificaciones, seguros y logística integrada." : "Certifications, insurance, and integrated logistics."
        }
      ]
    },
    {
      id: "model",
      tag: isEs ? "PÁGINA 2 • MODELO DE NEGOCIOS" : "PAGE 2 • BUSINESS MODEL",
      title: isEs ? "¿CÓMO FUNCIONA EL MODELO DE NEGOCIOS?" : "HOW DOES THE BUSINESS MODEL WORK?",
      subtitle: isEs
        ? "Un ecosistema integral que protege la soberanía del productor y maximiza la rentabilidad del campo mediante 3 pilares estratégicos."
        : "A comprehensive ecosystem that protects producer sovereignty and maximizes agricultural profitability through 3 strategic pillars.",
      pillars: [
        {
          title: isEs ? "🌱 1. Tokenización de cultivos" : "🌱 1. Crop Tokenization",
          points: isEs ? [
            "Usted conserva la propiedad y control de su producción",
            "El capital se destina directamente a su proyecto",
            "Los inversionistas participan en los resultados de la cosecha",
            "Permite: Sembrar y producir sin descapitalizarse",
            "Mejorar insumos, certificaciones y rendimiento",
            "Tener acceso a capital constante y recurrente"
          ] : [
            "You retain full ownership and control of your production",
            "Capital is deployed directly to your project",
            "Investors participate in harvest yields and results",
            "Allows: Planting and producing without running out of capital",
            "Upgrading inputs, organic certifications, and yield",
            "Securing constant and recurring working capital"
          ]
        },
        {
          title: isEs ? "🛒 2. Marketplace agrícola" : "🛒 2. Agricultural Marketplace",
          points: isEs ? [
            "Ofrecer su cosecha directamente a compradores calificados",
            "Publicar productos agrícolas con trazabilidad digital comprobada",
            "Acceder a mercados nacionales e internacionales",
            "Menos intermediarios = MEJOR PRECIO PARA EL PRODUCTOR"
          ] : [
            "Offer harvest directly to verified buyers",
            "List agricultural products with verified digital traceability",
            "Access premier national and international markets",
            "Fewer middlemen = BETTER PRICE FOR THE PRODUCER"
          ]
        },
        {
          title: isEs ? "🧠 3. Servicios y asesorías" : "🧠 3. Services & Technical Advice",
          points: isEs ? [
            "Asesoría técnica y agronomía especializada",
            "Certificaciones orgánicas, GlobalG.A.P. y comercio justo",
            "Seguros agrícolas paramétricos y climáticos",
            "Servicios logísticos y de cadena de frío comercial"
          ] : [
            "Specialized technical advice and agronomy support",
            "Organic, GlobalG.A.P., and fair trade certifications",
            "Parametric and climate-backed agricultural insurance",
            "Commercial logistics and cold chain services"
          ]
        }
      ]
    },
    {
      id: "tech_and_advantages",
      tag: isEs ? "PÁGINA 3 • TECNOLOGÍA Y VENTAJAS" : "PAGE 3 • TECHNOLOGY & ADVANTAGES",
      title: isEs ? "¿QUÉ TECNOLOGÍA UTILIZA MILPA TECH?" : "WHAT TECHNOLOGY POWERS MILPA TECH?",
      motto: isEs ? "«La tecnología trabaja para usted, no al revés.»" : "«Technology works for you, not the other way around.»",
      techItems: isEs ? [
        "Plataforma digital de registro de cultivos con monitoreo en tiempo real",
        "Contratos inteligentes (Smart Contracts) para inversión y distribución automática de ingresos",
        "Sistemas de trazabilidad y transparencia inmutable en blockchain",
        "Análisis de datos e inteligencia artificial para reducir riesgos agrícolas y climáticos",
        "Infraestructura tecnológica preparada para cumplir normativas y regulaciones oficiales"
      ] : [
        "Digital crop registration platform with real-time field monitoring",
        "Smart contracts for automated investment deployment and revenue distribution",
        "Immutable blockchain transparency and traceability systems",
        "Data analytics and artificial intelligence to mitigate agricultural and weather risks",
        "Technological infrastructure fully ready to comply with regulatory standards"
      ],
      advantages: isEs ? [
        "Acceso a inversionistas reales y constantes",
        "Financiamiento sin depender de créditos bancarios usureros",
        "Mejor precio por su cosecha al eliminar coyotes e intermediarios",
        "Mayor visibilidad y confianza ante compradores institucionales",
        "Transparencia total en pagos y resultados con liquidación rápida",
        "Reducción de riesgos mediante diversificación y seguros paramétricos",
        "Acompañamiento técnico y comercial continuo durante todo el ciclo"
      ] : [
        "Direct access to verified and recurring investors",
        "Alternative financing free from traditional banking bureaucracy",
        "Higher harvest prices by eliminating predatory middlemen",
        "Greater visibility and trustworthiness for institutional buyers",
        "Complete transparency in payouts and harvest yields",
        "Risk reduction through diversification and parametric insurance",
        "Continuous technical and commercial guidance across the crop lifecycle"
      ]
    },
    {
      id: "audience_and_invite",
      tag: isEs ? "PÁGINA 4 • INVITACIÓN FORMAL Y ALCANCE" : "PAGE 4 • FORMAL INVITATION & REACH",
      title: isEs ? "UNA OPORTUNIDAD PARA EL CAMPO MEXICANO" : "AN OPPORTUNITY FOR MEXICAN AGRICULTURE",
      audience: isEs ? [
        "Pequeños y medianos productores agrícolas",
        "Cooperativas, ejidos y asociaciones de productores",
        "Agroindustrias en crecimiento y exportadores",
        "Proyectos productivos con visión de largo plazo y sustentabilidad"
      ] : [
        "Small and medium agricultural producers",
        "Cooperatives, ejidos, and producer associations",
        "Growing agro-industries and exporters",
        "Long-term productive projects focused on sustainability"
      ],
      objective: isEs
        ? "Nuestro objetivo es construir una red sólida de productores que crezcan junto con la plataforma y sean parte activa de este nuevo modelo."
        : "Our objective is to build a robust network of producers who grow together with the platform and take an active role in this new paradigm.",
      invitePoints: isEs ? [
        "Conocer la plataforma y sus herramientas",
        "Registrar su interés formal y perfil productivo",
        "Preparar su proyecto agrícola para financiamiento",
        "Formar parte del ecosistema Milpa Tech desde sus primeras etapas"
      ] : [
        "Explore the platform and its digital toolset",
        "Register your formal interest and producer profile",
        "Prepare your agricultural crop project for funding",
        "Become part of the Milpa Tech ecosystem from its inception"
      ],
      closing: isEs
        ? "Su participación es clave para construir un modelo más justo, rentable y sostenible para el campo."
        : "Your participation is fundamental in building a fairer, more profitable, and sustainable future for agriculture."
    }
  ];

  return (
    <div className="space-y-10 animate-fade-in text-slate-800 pb-16" id="about-us-view">
      
      {/* Header Banner */}
      <section className="relative overflow-hidden bg-gradient-to-br from-green-950 via-emerald-900 to-slate-950 text-white rounded-3xl p-8 md:p-12 shadow-2xl border border-emerald-800/40">
        <div className="absolute top-0 right-0 -mt-16 -mr-16 w-80 h-80 bg-emerald-500 rounded-full mix-blend-screen filter blur-3xl opacity-20 pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 -mb-16 -ml-16 w-80 h-80 bg-amber-500 rounded-full mix-blend-screen filter blur-3xl opacity-15 pointer-events-none"></div>

        <div className="relative z-10 max-w-4xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-black uppercase tracking-wider backdrop-blur-md">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{isEs ? "Documento Institucional & Presentación" : "Institutional Document & Presentation"}</span>
          </div>

          <div className="flex justify-center mb-2">
            <MilpaLogo variant="full" size={48} />
          </div>

          <h1 className="text-3xl md:text-5xl font-black tracking-tight text-white leading-tight">
            {isEs ? "QUIÉNES SOMOS • ABOUT US" : "WHO WE ARE • ABOUT US"}
          </h1>

          <p className="text-lg md:text-xl font-semibold text-emerald-200 leading-relaxed max-w-3xl mx-auto">
            {isEs
              ? "MILPA TECH – Plataforma de Inversión, Comercialización y Tecnología Agrícola"
              : "MILPA TECH – Investment, Commercialization & Agri-Tech Platform"}
          </p>

          <p className="text-sm md:text-base text-emerald-100/90 max-w-2xl mx-auto font-normal leading-relaxed">
            {isEs
              ? "Conoce y forma parte de Milpa Tech, una plataforma tecnológica mexicana diseñada para transformar la manera en que el campo accede a financiamiento, mercados y herramientas digitales, conectando directamente a productores con inversionistas reales, compradores y servicios especializados, sin intermediarios innecesarios."
              : "Discover and join Milpa Tech, a Mexican technological platform designed to transform how agriculture accesses financing, markets, and digital tools, directly connecting producers with real investors, buyers, and specialized services without unnecessary intermediaries."}
          </p>

          {/* Quick Action CTAs */}
          <div className="flex flex-wrap justify-center items-center gap-3 pt-4">
            <button
              onClick={onRegisterProducer}
              className="px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-green-950 font-black rounded-2xl transition-all shadow-lg hover:shadow-emerald-500/25 flex items-center gap-2 text-sm transform hover:-translate-y-0.5 active:translate-y-0"
              id="about-cta-producer"
            >
              <Sprout className="w-4 h-4" />
              <span>{isEs ? "Darme de Alta como Productor" : "Register as Producer"}</span>
            </button>

            <button
              onClick={onRegisterInvestor}
              className="px-6 py-3 bg-white hover:bg-slate-100 text-slate-900 font-bold rounded-2xl transition-all shadow-md flex items-center gap-2 text-sm transform hover:-translate-y-0.5 active:translate-y-0"
              id="about-cta-investor"
            >
              <Coins className="w-4 h-4 text-emerald-600" />
              <span>{isEs ? "Registrarme como Inversionista" : "Register as Investor"}</span>
            </button>

            <button
              onClick={onExploreMarketplace}
              className="px-5 py-3 bg-emerald-950/60 hover:bg-emerald-900/80 text-emerald-200 border border-emerald-600/50 font-bold rounded-2xl transition-all text-sm flex items-center gap-2 backdrop-blur-sm"
              id="about-cta-market"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>{isEs ? "Explorar Marketplace" : "Explore Marketplace"}</span>
            </button>
          </div>
        </div>
      </section>

      {/* Mode Switcher (Document View vs. Slide Pitch Deck) */}
      <section className="flex flex-col sm:flex-row justify-between items-center gap-4 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm" id="about-toolbar">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setViewMode('document')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition-all ${
              viewMode === 'document'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>{isEs ? "Lectura Completa (Documento)" : "Full Document View"}</span>
          </button>
          <button
            onClick={() => setViewMode('deck')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition-all ${
              viewMode === 'deck'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Presentation className="w-4 h-4" />
            <span>{isEs ? "Modo Presentación (4 Páginas)" : "Presentation Deck (4 Pages)"}</span>
          </button>
        </div>

        <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-500"></span>
          <span>{isEs ? "Presentación Oficial Milpa Tech México 2026" : "Official Milpa Tech Mexico 2026 Presentation"}</span>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* MODE 1: INTERACTIVE PITCH DECK SLIDE VIEWER */}
      {/* ========================================================================= */}
      {viewMode === 'deck' && (
        <section className="space-y-6" id="deck-container">
          {/* Deck Navigation Controls */}
          <div className="flex items-center justify-between bg-slate-900 text-white px-6 py-3 rounded-2xl shadow-lg border border-slate-800">
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 bg-emerald-600 text-white font-mono text-xs font-black rounded-lg">
                {currentSlide + 1} / {slides.length}
              </span>
              <span className="text-xs font-bold text-slate-300 hidden sm:inline">
                {slides[currentSlide].tag}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentSlide(prev => Math.max(0, prev - 1))}
                disabled={currentSlide === 0}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed text-white transition-colors"
                title="Diapositiva Anterior"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <div className="flex gap-1.5">
                {slides.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentSlide(idx)}
                    className={`h-2.5 rounded-full transition-all ${
                      currentSlide === idx ? 'w-8 bg-emerald-400' : 'w-2.5 bg-slate-700 hover:bg-slate-600'
                    }`}
                    title={`Ir a página ${idx + 1}`}
                  />
                ))}
              </div>
              <button
                onClick={() => setCurrentSlide(prev => Math.min(slides.length - 1, prev + 1))}
                disabled={currentSlide === slides.length - 1}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed text-white transition-colors"
                title="Siguiente Diapositiva"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Active Slide Card Render */}
          <div className="bg-white rounded-3xl p-8 md:p-12 border border-slate-200 shadow-xl min-h-[500px] flex flex-col justify-between transition-all duration-300">
            {/* SLIDE 0: INTRO & MISSION */}
            {currentSlide === 0 && (
              <div className="space-y-8">
                <div className="border-b border-slate-150 pb-6 space-y-3">
                  <span className="text-xs font-black text-emerald-600 tracking-wider uppercase">{slides[0].tag}</span>
                  <h2 className="text-2xl md:text-3xl font-black text-slate-900">{slides[0].title}</h2>
                  <p className="text-slate-600 leading-relaxed font-medium">{slides[0].subtitle}</p>
                </div>

                <div className="bg-gradient-to-r from-emerald-50 to-teal-50 p-6 rounded-2xl border border-emerald-200/80 space-y-2">
                  <div className="flex items-center gap-2 text-emerald-800 font-black text-sm uppercase tracking-wider">
                    <span className="text-lg">👉</span>
                    <span>{isEs ? "Misión Clara Milpa Tech" : "Clear Milpa Tech Mission"}</span>
                  </div>
                  <p className="text-slate-800 font-bold text-lg leading-snug">
                    "{slides[0].mission}"
                  </p>
                </div>

                <div>
                  <h3 className="text-base font-black text-slate-800 mb-4 uppercase tracking-wider flex items-center gap-2">
                    <Layers className="w-5 h-5 text-emerald-600" />
                    <span>{isEs ? "¿QUÉ ES MILPA TECH? (3 ELEMENTOS CLAVE)" : "WHAT IS MILPA TECH? (3 KEY ELEMENTS)"}</span>
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {slides[0].elements?.map((el, i) => (
                      <div key={i} className="p-5 rounded-2xl bg-slate-50 border border-slate-200/70 hover:border-emerald-300 transition-all space-y-2">
                        <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white font-black text-sm flex items-center justify-center">
                          {el.num}
                        </div>
                        <h4 className="font-bold text-slate-900 text-sm">{el.title}</h4>
                        <p className="text-xs text-slate-600 leading-relaxed">{el.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <p className="text-xs text-slate-500 italic bg-slate-100 p-3 rounded-xl border border-slate-200 text-center">
                  {isEs
                    ? "Todo esto respaldado por tecnología digital, trazabilidad, análisis de datos y contratos inteligentes, con enfoque en transparencia y confianza."
                    : "Backed by digital technology, traceability, data analytics, and smart contracts, focused on transparency and trust."}
                </p>
              </div>
            )}

            {/* SLIDE 1: BUSINESS MODEL */}
            {currentSlide === 1 && (
              <div className="space-y-8">
                <div className="border-b border-slate-150 pb-6 space-y-3">
                  <span className="text-xs font-black text-emerald-600 tracking-wider uppercase">{slides[1].tag}</span>
                  <h2 className="text-2xl md:text-3xl font-black text-slate-900">{slides[1].title}</h2>
                  <p className="text-slate-600 leading-relaxed">{slides[1].subtitle}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {slides[1].pillars?.map((p, idx) => (
                    <div key={idx} className="bg-slate-50 p-6 rounded-2xl border border-slate-200/80 flex flex-col justify-between hover:border-emerald-300 transition-all">
                      <div className="space-y-4">
                        <h3 className="font-black text-base text-slate-900 border-b border-slate-200 pb-2">{p.title}</h3>
                        <ul className="space-y-2.5">
                          {p.points.map((pt, pIdx) => (
                            <li key={pIdx} className="flex items-start gap-2 text-xs text-slate-700 leading-relaxed">
                              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                              <span className={pt.includes("MEJOR PRECIO") || pt.includes("BETTER PRICE") ? "font-bold text-emerald-800" : ""}>{pt}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* SLIDE 2: TECH & ADVANTAGES */}
            {currentSlide === 2 && (
              <div className="space-y-8">
                <div className="border-b border-slate-150 pb-6 space-y-3">
                  <span className="text-xs font-black text-emerald-600 tracking-wider uppercase">{slides[2].tag}</span>
                  <h2 className="text-2xl md:text-3xl font-black text-slate-900">{slides[2].title}</h2>
                  <p className="text-emerald-700 font-bold text-base italic">{slides[2].motto}</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Technology Used */}
                  <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 space-y-4">
                    <h3 className="text-sm font-black uppercase tracking-wider text-emerald-400 flex items-center gap-2">
                      <Zap className="w-4 h-4 text-amber-400" />
                      <span>{isEs ? "Tecnología que Utiliza" : "Technology Architecture"}</span>
                    </h3>
                    <ul className="space-y-3">
                      {slides[2].techItems?.map((ti, tIdx) => (
                        <li key={tIdx} className="flex items-start gap-2.5 text-xs text-slate-300 leading-relaxed">
                          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0"></div>
                          <span>{ti}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Advantages for Producer */}
                  <div className="bg-emerald-50 p-6 rounded-2xl border border-emerald-200/80 space-y-4">
                    <h3 className="text-sm font-black uppercase tracking-wider text-emerald-900 flex items-center gap-2">
                      <Award className="w-4 h-4 text-emerald-600" />
                      <span>{isEs ? "Ventajas Competitivas para el Productor" : "Competitive Advantages for Producers"}</span>
                    </h3>
                    <ul className="space-y-2.5">
                      {slides[2].advantages?.map((adv, aIdx) => (
                        <li key={aIdx} className="flex items-start gap-2 text-xs text-emerald-950 font-semibold leading-relaxed">
                          <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{adv}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* SLIDE 3: AUDIENCE & INVITATION */}
            {currentSlide === 3 && (
              <div className="space-y-8">
                <div className="border-b border-slate-150 pb-6 space-y-3">
                  <span className="text-xs font-black text-emerald-600 tracking-wider uppercase">{slides[3].tag}</span>
                  <h2 className="text-2xl md:text-3xl font-black text-slate-900">{slides[3].title}</h2>
                  <p className="text-slate-700 font-semibold">{slides[3].objective}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Designed For */}
                  <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
                    <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                      <Building className="w-4 h-4 text-emerald-600" />
                      <span>{isEs ? "Milpa Tech está diseñada para:" : "Milpa Tech is designed for:"}</span>
                    </h3>
                    <ul className="space-y-2.5">
                      {slides[3].audience?.map((aud, aIdx) => (
                        <li key={aIdx} className="flex items-center gap-2.5 text-xs text-slate-700 font-medium">
                          <div className="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></div>
                          <span>{aud}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Formal Invitation */}
                  <div className="p-6 bg-gradient-to-br from-green-950 to-slate-900 text-white rounded-2xl border border-emerald-800 space-y-4">
                    <h3 className="text-sm font-black text-amber-300 uppercase tracking-wider flex items-center gap-2">
                      <HeartHandshake className="w-4 h-4" />
                      <span>{isEs ? "INVITACIÓN FORMAL" : "FORMAL INVITATION"}</span>
                    </h3>
                    <ul className="space-y-2.5">
                      {slides[3].invitePoints?.map((ip, iIdx) => (
                        <li key={iIdx} className="flex items-start gap-2.5 text-xs text-emerald-100 font-medium leading-relaxed">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{ip}</span>
                        </li>
                      ))}
                    </ul>
                    <p className="text-xs text-amber-200/90 italic pt-2 border-t border-emerald-800/60">
                      "{slides[3].closing}"
                    </p>
                  </div>
                </div>

                {/* Final Slide Onboarding Trigger */}
                <div className="bg-emerald-600 text-white p-6 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg">
                  <div>
                    <h4 className="font-black text-base">{isEs ? "¿Listo para dar el siguiente paso?" : "Ready to take the next step?"}</h4>
                    <p className="text-xs text-emerald-100">{isEs ? "Elige tu rol y completa el formulario de registro en menos de 3 minutos." : "Select your role and complete onboarding in under 3 minutes."}</p>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <button
                      onClick={onRegisterProducer}
                      className="px-5 py-2.5 bg-white text-emerald-950 font-black rounded-xl text-xs hover:bg-slate-100 shadow transition-all"
                    >
                      {isEs ? "Alta de Productor" : "Producer Signup"}
                    </button>
                    <button
                      onClick={onRegisterInvestor}
                      className="px-5 py-2.5 bg-emerald-900 text-white font-bold rounded-xl text-xs hover:bg-emerald-950 shadow transition-all border border-emerald-400/40"
                    >
                      {isEs ? "Alta Inversionista" : "Investor Signup"}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Slide Footer */}
            <div className="pt-6 mt-6 border-t border-slate-150 flex items-center justify-between text-xs text-slate-400">
              <span className="font-semibold">Milpa Tech México • Web3 & AgroTech</span>
              <div className="flex gap-2">
                {currentSlide > 0 && (
                  <button
                    onClick={() => setCurrentSlide(prev => prev - 1)}
                    className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold"
                  >
                    {isEs ? "← Anterior" : "← Previous"}
                  </button>
                )}
                {currentSlide < slides.length - 1 ? (
                  <button
                    onClick={() => setCurrentSlide(prev => prev + 1)}
                    className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold flex items-center gap-1"
                  >
                    <span>{isEs ? "Siguiente →" : "Next →"}</span>
                  </button>
                ) : (
                  <button
                    onClick={() => setViewMode('document')}
                    className="px-3 py-1 bg-slate-900 text-white rounded-lg font-bold"
                  >
                    {isEs ? "Ver Documento Completo" : "View Full Document"}
                  </button>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ========================================================================= */}
      {/* MODE 2: CONTINUOUS FULL DOCUMENT VIEW (Faithful to the 4-Page Brief) */}
      {/* ========================================================================= */}
      {viewMode === 'document' && (
        <div className="space-y-12" id="full-document-flow">
          
          {/* SECTION 1: QUIÉNES SOMOS & QUÉ ES MILPA TECH */}
          <section className="bg-white rounded-3xl p-8 md:p-12 border border-slate-200 shadow-sm space-y-8 text-left" id="sec-quienes-somos">
            <div className="flex items-center gap-3 border-b border-slate-150 pb-4">
              <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-black">
                1
              </div>
              <div>
                <span className="text-xs font-black text-emerald-600 uppercase tracking-widest">{isEs ? "PÁGINA 1 DEL DOCUMENTO" : "DOCUMENT PAGE 1"}</span>
                <h2 className="text-2xl md:text-3xl font-black text-slate-900">{isEs ? "¿QUÉ ES MILPA TECH?" : "WHAT IS MILPA TECH?"}</h2>
              </div>
            </div>

            <div className="prose prose-slate max-w-none space-y-4 text-slate-700 leading-relaxed font-normal">
              <p className="text-base md:text-lg text-slate-800 font-medium">
                {isEs
                  ? "Conoce y forma parte de Milpa Tech, una plataforma tecnológica mexicana diseñada para transformar la manera en que el campo accede a financiamiento, mercados y herramientas digitales, conectando directamente a productores con inversionistas reales, compradores y servicios especializados, sin intermediarios innecesarios."
                  : "Discover and join Milpa Tech, a Mexican technological platform designed to transform the way agriculture accesses financing, markets, and digital tools, directly connecting producers with real investors, buyers, and specialized services without unnecessary intermediaries."}
              </p>

              <div className="bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-transparent p-6 rounded-2xl border-l-4 border-emerald-600 space-y-1 my-4">
                <p className="text-xs font-black text-emerald-800 uppercase tracking-wider">{isEs ? "Milpa Tech nace con una misión clara:" : "Milpa Tech was born with a clear mission:"}</p>
                <p className="text-base md:text-lg font-black text-slate-900">
                  👉 {isEs ? "Fortalecer al productor, mejorar su rentabilidad y darle acceso a oportunidades que hoy están reservadas solo para grandes actores del sector." : "Empower the producer, enhance their profitability, and unlock opportunities currently reserved only for major industry players."}
                </p>
              </div>

              <p className="font-bold text-slate-800 pt-2">
                {isEs
                  ? "Milpa Tech es una plataforma agro-tecnológica y de inversión que integra tres elementos clave:"
                  : "Milpa Tech is an agro-technological and investment platform integrating three core elements:"}
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 hover:border-emerald-300 transition-all space-y-3">
                  <div className="w-12 h-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black shadow-sm">
                    <Sprout className="w-6 h-6" />
                  </div>
                  <h3 className="font-black text-slate-900 text-base">{isEs ? "1. Tokenización de cosechas" : "1. Harvest Tokenization"}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {isEs
                      ? "Emisión de activos digitales respaldados por cultivos reales para obtener liquidez y financiamiento anticipado."
                      : "Issuing digital tokens backed by real crops to secure liquidity and advance funding without debt."}
                  </p>
                </div>

                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 hover:border-emerald-300 transition-all space-y-3">
                  <div className="w-12 h-12 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black shadow-sm">
                    <ShoppingCart className="w-6 h-6" />
                  </div>
                  <h3 className="font-black text-slate-900 text-base">{isEs ? "2. Marketplace de productos agrícolas" : "2. Agricultural Marketplace"}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {isEs
                      ? "Mercado digital directo para comercializar cosechas a compradores nacionales e internacionales con trazabilidad."
                      : "Direct digital marketplace to trade harvests to national and global buyers with end-to-end traceability."}
                  </p>
                </div>

                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 hover:border-emerald-300 transition-all space-y-3">
                  <div className="w-12 h-12 rounded-xl bg-amber-600 text-white flex items-center justify-center font-black shadow-sm">
                    <Brain className="w-6 h-6" />
                  </div>
                  <h3 className="font-black text-slate-900 text-base">{isEs ? "3. Marketplace de servicios y asesorías" : "3. Services & Technical Consulting"}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {isEs
                      ? "Ecosistema integral de agronomía, certificaciones orgánicas, seguros climáticos y servicios logísticos."
                      : "Integrated ecosystem of agronomy advisory, organic certifications, climate insurance, and cold logistics."}
                  </p>
                </div>
              </div>

              <div className="bg-slate-900 text-emerald-300 p-5 rounded-2xl border border-slate-800 text-xs font-semibold text-center mt-4">
                {isEs
                  ? "Todo esto respaldado por tecnología digital, trazabilidad, análisis de datos y contratos inteligentes, con enfoque en transparencia y confianza."
                  : "All backed by digital technology, traceability, data analytics, and smart contracts, with unwavering focus on transparency and trust."}
              </div>
            </div>
          </section>

          {/* SECTION 2: MODELO DE NEGOCIOS */}
          <section className="bg-white rounded-3xl p-8 md:p-12 border border-slate-200 shadow-sm space-y-8 text-left" id="sec-modelo-negocio">
            <div className="flex items-center gap-3 border-b border-slate-150 pb-4">
              <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-black">
                2
              </div>
              <div>
                <span className="text-xs font-black text-emerald-600 uppercase tracking-widest">{isEs ? "PÁGINA 2 DEL DOCUMENTO" : "DOCUMENT PAGE 2"}</span>
                <h2 className="text-2xl md:text-3xl font-black text-slate-900">{isEs ? "¿CÓMO FUNCIONA EL MODELO DE NEGOCIOS?" : "HOW DOES THE BUSINESS MODEL WORK?"}</h2>
              </div>
            </div>

            <div className="space-y-8">
              {/* Pillar 1 */}
              <div className="bg-emerald-50/50 p-6 md:p-8 rounded-3xl border border-emerald-200/80 space-y-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🌱</span>
                  <h3 className="text-xl font-black text-slate-900">{isEs ? "1. Tokenización de cultivos" : "1. Crop Tokenization"}</h3>
                </div>
                <p className="text-sm text-slate-700 font-medium">
                  {isEs
                    ? "Los productores pueden dar de alta sus cultivos y cosechas dentro de la plataforma para recibir financiamiento anticipado por parte de inversionistas."
                    : "Producers can list their crops and harvests within the platform to receive advance financing from investors."}
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                  <div className="bg-white p-5 rounded-2xl border border-emerald-200 shadow-sm space-y-3">
                    <h4 className="text-xs font-black uppercase tracking-wider text-emerald-800">{isEs ? "Garantías y Control" : "Control & Guarantees"}</h4>
                    <ul className="space-y-2 text-xs text-slate-700">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span><strong>{isEs ? "Propiedad Total:" : "Full Ownership:"}</strong> {isEs ? "Usted conserva la propiedad y control de su producción." : "You retain complete ownership and control of your production."}</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span><strong>{isEs ? "Destino Directo:" : "Direct Deployment:"}</strong> {isEs ? "El capital se destina directamente a su proyecto." : "Capital is deployed directly to your project."}</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span><strong>{isEs ? "Inversionistas Alineados:" : "Aligned Investors:"}</strong> {isEs ? "Los inversionistas participan en los resultados de la cosecha." : "Investors participate in harvest yields and results."}</span>
                      </li>
                    </ul>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-emerald-200 shadow-sm space-y-3">
                    <h4 className="text-xs font-black uppercase tracking-wider text-emerald-800">{isEs ? "Esto le permite al productor:" : "This empowers the producer to:"}</h4>
                    <ul className="space-y-2 text-xs text-slate-700">
                      <li className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{isEs ? "Sembrar y producir sin descapitalizarse" : "Plant and produce without running out of cash"}</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{isEs ? "Mejorar insumos, certificaciones y rendimiento por hectárea" : "Upgrade bio-inputs, organic certifications, and yield per hectare"}</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{isEs ? "Tener acceso a capital constante y recurrente ciclo tras ciclo" : "Secure constant, recurring working capital cycle after cycle"}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Pillar 2 */}
              <div className="bg-blue-50/50 p-6 md:p-8 rounded-3xl border border-blue-200/80 space-y-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🛒</span>
                  <h3 className="text-xl font-black text-slate-900">{isEs ? "2. Marketplace agrícola" : "2. Agricultural Marketplace"}</h3>
                </div>
                <p className="text-sm text-slate-700 font-medium">
                  {isEs
                    ? "Milpa Tech funciona también como un mercado digital donde usted puede:"
                    : "Milpa Tech also operates as a premier digital marketplace where you can:"}
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
                  <div className="bg-white p-4 rounded-2xl border border-blue-200 shadow-sm text-xs text-slate-800 font-semibold flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                    <span>{isEs ? "Ofrecer su cosecha directamente a compradores" : "Offer your harvest directly to verified buyers"}</span>
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-blue-200 shadow-sm text-xs text-slate-800 font-semibold flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                    <span>{isEs ? "Publicar productos agrícolas con trazabilidad" : "Publish crops with verified blockchain traceability"}</span>
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-blue-200 shadow-sm text-xs text-slate-800 font-semibold flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                    <span>{isEs ? "Acceder a mercados nacionales e internacionales" : "Access premier national & global markets"}</span>
                  </div>
                </div>

                <div className="p-4 bg-blue-900 text-white rounded-2xl flex items-center justify-between font-black text-sm">
                  <span>{isEs ? "Menos intermediarios =" : "Fewer middlemen ="}</span>
                  <span className="text-amber-300 uppercase tracking-wider">{isEs ? "MEJOR PRECIO PARA EL PRODUCTOR" : "BETTER PRICE FOR THE PRODUCER"}</span>
                </div>
              </div>

              {/* Pillar 3 */}
              <div className="bg-amber-50/50 p-6 md:p-8 rounded-3xl border border-amber-200/80 space-y-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🧠</span>
                  <h3 className="text-xl font-black text-slate-900">{isEs ? "3. Servicios y asesorías" : "3. Services & Technical Advisory"}</h3>
                </div>
                <p className="text-sm text-slate-700 font-medium">
                  {isEs ? "Desde la plataforma podrá acceder a un catálogo integral de servicios:" : "Direct access to an integrated catalog of specialized services:"}
                </p>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-1">
                  <div className="bg-white p-4 rounded-2xl border border-amber-200 shadow-sm text-center space-y-1">
                    <Brain className="w-6 h-6 text-amber-600 mx-auto" />
                    <p className="text-xs font-bold text-slate-900">{isEs ? "Asesoría técnica" : "Technical Advice"}</p>
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-amber-200 shadow-sm text-center space-y-1">
                    <Award className="w-6 h-6 text-amber-600 mx-auto" />
                    <p className="text-xs font-bold text-slate-900">{isEs ? "Certificaciones" : "Certifications"}</p>
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-amber-200 shadow-sm text-center space-y-1">
                    <ShieldCheck className="w-6 h-6 text-amber-600 mx-auto" />
                    <p className="text-xs font-bold text-slate-900">{isEs ? "Seguros agrícolas" : "Agri-Insurance"}</p>
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-amber-200 shadow-sm text-center space-y-1">
                    <Globe className="w-6 h-6 text-amber-600 mx-auto" />
                    <p className="text-xs font-bold text-slate-900">{isEs ? "Logística y comercio" : "Logistics & Trade"}</p>
                  </div>
                </div>

                <p className="text-xs font-bold text-slate-600 italic text-right">
                  {isEs ? "Todo integrado en un solo ecosistema." : "All integrated within a single unified ecosystem."}
                </p>
              </div>
            </div>
          </section>

          {/* SECTION 3: TECNOLOGÍA & VENTAJAS COMPETITIVAS */}
          <section className="bg-white rounded-3xl p-8 md:p-12 border border-slate-200 shadow-sm space-y-8 text-left" id="sec-tecnologia-ventajas">
            <div className="flex items-center gap-3 border-b border-slate-150 pb-4">
              <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-black">
                3
              </div>
              <div>
                <span className="text-xs font-black text-emerald-600 uppercase tracking-widest">{isEs ? "PÁGINA 3 DEL DOCUMENTO" : "DOCUMENT PAGE 3"}</span>
                <h2 className="text-2xl md:text-3xl font-black text-slate-900">{isEs ? "¿QUÉ TECNOLOGÍA UTILIZA MILPA TECH?" : "WHAT TECHNOLOGY POWERS MILPA TECH?"}</h2>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Technology */}
              <div className="bg-slate-950 text-white p-8 rounded-3xl shadow-xl border border-slate-800 space-y-6 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-black uppercase">
                    <Zap className="w-3.5 h-3.5" />
                    <span>{isEs ? "Infraestructura Digital" : "Digital Infrastructure"}</span>
                  </div>
                  <h3 className="text-xl font-black text-white">{isEs ? "Herramientas Tecnológicas de Punta" : "Cutting-Edge Tech Stack"}</h3>
                  
                  <ul className="space-y-3 pt-2">
                    <li className="flex items-start gap-3 text-xs text-slate-300 leading-relaxed">
                      <div className="w-2 h-2 rounded-full bg-emerald-400 mt-1 shrink-0"></div>
                      <span><strong>{isEs ? "Registro digital de cultivos:" : "Digital crop registry:"}</strong> {isEs ? "Monitoreo satelital e IoT de humedad y temperatura." : "Satellite and IoT sensor monitoring for moisture and climate."}</span>
                    </li>
                    <li className="flex items-start gap-3 text-xs text-slate-300 leading-relaxed">
                      <div className="w-2 h-2 rounded-full bg-emerald-400 mt-1 shrink-0"></div>
                      <span><strong>{isEs ? "Contratos inteligentes (Smart Contracts):" : "Smart Contracts:"}</strong> {isEs ? "Para inversión transparente y distribución automática de ingresos." : "For transparent investment and automated revenue distribution."}</span>
                    </li>
                    <li className="flex items-start gap-3 text-xs text-slate-300 leading-relaxed">
                      <div className="w-2 h-2 rounded-full bg-emerald-400 mt-1 shrink-0"></div>
                      <span><strong>{isEs ? "Sistemas de trazabilidad:" : "Traceability systems:"}</strong> {isEs ? "Transparencia inmutable desde la siembra hasta la cosecha." : "Immutable transparency from planting to harvest."}</span>
                    </li>
                    <li className="flex items-start gap-3 text-xs text-slate-300 leading-relaxed">
                      <div className="w-2 h-2 rounded-full bg-emerald-400 mt-1 shrink-0"></div>
                      <span><strong>{isEs ? "Análisis de datos e IA:" : "Data analytics & AI:"}</strong> {isEs ? "Algoritmos predictivos para reducir riesgos agrícolas y climáticos." : "Predictive algorithms to mitigate agricultural and weather hazards."}</span>
                    </li>
                    <li className="flex items-start gap-3 text-xs text-slate-300 leading-relaxed">
                      <div className="w-2 h-2 rounded-full bg-emerald-400 mt-1 shrink-0"></div>
                      <span><strong>{isEs ? "Infraestructura regulada:" : "Compliant architecture:"}</strong> {isEs ? "Preparada para cumplir normativas y estándares internacionales." : "Built for KYC/AML compliance and international trade."}</span>
                    </li>
                  </ul>
                </div>

                <div className="p-4 rounded-2xl bg-emerald-950/80 border border-emerald-700/50 text-emerald-300 text-center font-bold text-sm italic">
                  {isEs ? "«La tecnología trabaja para usted, no al revés.»" : "«Technology works for you, not the other way around.»"}
                </div>
              </div>

              {/* Competitive Advantages */}
              <div className="bg-emerald-50/70 p-8 rounded-3xl border border-emerald-200 space-y-6 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-600 text-white text-xs font-black uppercase">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>{isEs ? "Beneficios Directos" : "Direct Benefits"}</span>
                  </div>
                  <h3 className="text-xl font-black text-slate-900">{isEs ? "VENTAJAS COMPETITIVAS PARA EL PRODUCTOR" : "COMPETITIVE ADVANTAGES FOR PRODUCERS"}</h3>

                  <ul className="space-y-3 pt-2">
                    {[
                      isEs ? "Acceso a inversionistas reales y constantes" : "Direct access to verified and recurring investors",
                      isEs ? "Financiamiento sin depender de créditos bancarios usureros" : "Financing without relying on bureaucratic bank loans",
                      isEs ? "Mejor precio por su cosecha al eliminar intermediarios" : "Higher crop prices by cutting out speculative brokers",
                      isEs ? "Mayor visibilidad y confianza ante compradores calificados" : "Greater visibility and trustworthiness with institutional buyers",
                      isEs ? "Transparencia total en pagos y resultados" : "Complete transparency in settlements and payouts",
                      isEs ? "Reducción de riesgos mediante diversificación y seguros" : "Risk mitigation through crop diversification & insurance",
                      isEs ? "Acompañamiento técnico y comercial permanente" : "Continuous technical and agronomic support"
                    ].map((adv, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-800 font-bold leading-relaxed">
                        <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{adv}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 rounded-2xl bg-white border border-emerald-200 text-emerald-900 text-xs font-black text-center shadow-sm">
                  {isEs ? "✓ Crecimiento sustentable y autonomía económica para el productor mexicano." : "✓ Sustainable growth and financial autonomy for Mexican producers."}
                </div>
              </div>
            </div>
          </section>

          {/* SECTION 4: AUDIENCIA & INVITACIÓN FORMAL */}
          <section className="bg-white rounded-3xl p-8 md:p-12 border border-slate-200 shadow-sm space-y-8 text-left" id="sec-invitacion-formal">
            <div className="flex items-center gap-3 border-b border-slate-150 pb-4">
              <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-black">
                4
              </div>
              <div>
                <span className="text-xs font-black text-emerald-600 uppercase tracking-widest">{isEs ? "PÁGINA 4 DEL DOCUMENTO" : "DOCUMENT PAGE 4"}</span>
                <h2 className="text-2xl md:text-3xl font-black text-slate-900">{isEs ? "UNA OPORTUNIDAD PARA EL CAMPO MEXICANO" : "AN OPPORTUNITY FOR MEXICAN AGRICULTURE"}</h2>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Audience Breakdown */}
              <div className="p-8 bg-slate-50 rounded-3xl border border-slate-200 space-y-5">
                <h3 className="text-lg font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <Building className="w-5 h-5 text-emerald-600" />
                  <span>{isEs ? "Milpa Tech está diseñada para:" : "Milpa Tech is designed for:"}</span>
                </h3>

                <ul className="space-y-3">
                  {[
                    isEs ? "Pequeños y medianos productores" : "Small and medium agricultural producers",
                    isEs ? "Cooperativas, ejidos y asociaciones de agricultores" : "Cooperatives, ejidos, and farming associations",
                    isEs ? "Agroindustrias en crecimiento y exportadores" : "Growing agro-industrial firms and exporters",
                    isEs ? "Proyectos productivos con visión de largo plazo" : "Long-term productive projects with ecological vision"
                  ].map((aud, idx) => (
                    <li key={idx} className="flex items-center gap-3 text-xs md:text-sm text-slate-800 font-semibold bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0"></div>
                      <span>{aud}</span>
                    </li>
                  ))}
                </ul>

                <p className="text-xs text-slate-600 leading-relaxed italic bg-emerald-50 p-4 rounded-2xl border border-emerald-200">
                  {isEs
                    ? "Nuestro objetivo es construir una red sólida de productores que crezcan junto con la plataforma y sean parte activa de este nuevo modelo."
                    : "Our objective is to build a robust network of producers who grow together with the platform and take an active role in this new model."}
                </p>
              </div>

              {/* Formal Invitation Card */}
              <div className="p-8 bg-gradient-to-br from-green-950 via-emerald-950 to-slate-950 text-white rounded-3xl border-2 border-emerald-500/50 shadow-xl space-y-6 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/20 text-amber-300 text-xs font-black uppercase tracking-wider">
                    <HeartHandshake className="w-4 h-4" />
                    <span>{isEs ? "INVITACIÓN FORMAL" : "FORMAL INVITATION"}</span>
                  </div>

                  <h3 className="text-2xl font-black text-white">{isEs ? "Le invitamos a formar parte:" : "You are cordially invited:"}</h3>

                  <ul className="space-y-3">
                    {[
                      isEs ? "Conocer la plataforma y sus herramientas" : "Explore the platform and its digital toolset",
                      isEs ? "Registrar su interés formal y capacidad productiva" : "Register your formal interest and productive capacity",
                      isEs ? "Preparar su proyecto productivo para financiamiento" : "Prepare your crop project for investment allocation",
                      isEs ? "Formar parte del ecosistema Milpa Tech desde sus primeras etapas" : "Join the Milpa Tech ecosystem from its inaugural stages"
                    ].map((inv, idx) => (
                      <li key={idx} className="flex items-start gap-3 text-xs md:text-sm text-emerald-100 font-medium leading-relaxed">
                        <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{inv}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 rounded-2xl bg-emerald-900/60 border border-emerald-600/50 text-amber-200 text-xs font-bold italic text-center">
                  "{isEs ? "Su participación es clave para construir un modelo más justo, rentable y sostenible para el campo." : "Your participation is key to building a fairer, more profitable, and sustainable agricultural sector."}"
                </div>
              </div>
            </div>

            {/* Bottom Call to Action Grid */}
            <div className="bg-gradient-to-r from-emerald-600 to-teal-700 rounded-3xl p-8 md:p-10 text-white text-center space-y-6 shadow-2xl">
              <h3 className="text-2xl md:text-3xl font-black">
                {isEs ? "¡Únete a la Revolución Agrícola y Tecnológica!" : "Join the Agri-Tech Revolution Today!"}
              </h3>
              <p className="text-sm md:text-base text-emerald-100 max-w-2xl mx-auto leading-relaxed">
                {isEs
                  ? "Regístrate ahora para tokenizar cosechas, invertir con seguridad jurídica o comercializar directamente tus productos agrícolas."
                  : "Register now to tokenize crops, invest with legal security, or trade your agricultural products directly."}
              </p>

              <div className="flex flex-wrap justify-center items-center gap-4 pt-2">
                <button
                  onClick={onRegisterProducer}
                  className="px-6 py-3.5 bg-white text-emerald-950 hover:bg-slate-100 font-black rounded-2xl transition-all shadow-xl flex items-center gap-2.5 text-sm transform hover:-translate-y-0.5 active:translate-y-0"
                >
                  <Sprout className="w-5 h-5 text-emerald-600" />
                  <span>{isEs ? "Alta como Productor" : "Producer Registration"}</span>
                </button>

                <button
                  onClick={onRegisterInvestor}
                  className="px-6 py-3.5 bg-emerald-950 hover:bg-emerald-900 text-white font-black rounded-2xl transition-all shadow-xl flex items-center gap-2.5 text-sm border border-emerald-400/50 transform hover:-translate-y-0.5 active:translate-y-0"
                >
                  <Coins className="w-5 h-5 text-amber-400" />
                  <span>{isEs ? "Alta como Inversionista" : "Investor Registration"}</span>
                </button>

                {onRegisterTrader && (
                  <button
                    onClick={onRegisterTrader}
                    className="px-6 py-3.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-2xl transition-all shadow-xl flex items-center gap-2.5 text-sm border border-amber-300 transform hover:-translate-y-0.5 active:translate-y-0"
                  >
                    <ShoppingCart className="w-5 h-5 text-slate-950" />
                    <span>{isEs ? "Alta Comprador/Vendedor" : "Trader / Buyer Registration"}</span>
                  </button>
                )}

                <button
                  onClick={onOpenAiBot}
                  className="px-5 py-3.5 bg-white/10 hover:bg-white/20 text-white font-bold rounded-2xl transition-all text-sm border border-white/20 flex items-center gap-2 backdrop-blur-sm"
                >
                  <Brain className="w-4 h-4 text-emerald-300" />
                  <span>{isEs ? "Preguntar a Milpa AI" : "Ask Milpa AI"}</span>
                </button>
              </div>
            </div>
          </section>

        </div>
      )}

    </div>
  );
};
