import React, { useState } from 'react';
import {
  X, Send, ShieldCheck, User, MessageSquare, DollarSign,
  CheckCircle2, Sparkles, Building2, MapPin, Handshake,
  ShoppingBag, HelpCircle, Phone, Mail
} from 'lucide-react';
import { UserProfile, Message, Language, MarketplaceItem, Crop } from '../types';

interface DirectUserChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetUser: UserProfile;
  currentUser: UserProfile | null;
  lang: Language;
  onSendMessage: (msg: Message) => void;
  crops?: Crop[];
  marketplaceItems?: MarketplaceItem[];
}

export const DirectUserChatModal: React.FC<DirectUserChatModalProps> = ({
  isOpen,
  onClose,
  targetUser,
  currentUser,
  lang,
  onSendMessage,
  crops = [],
  marketplaceItems = []
}) => {
  if (!isOpen) return null;

  const isEs = lang === 'es';
  const [inputText, setInputText] = useState('');
  const [proposalMode, setProposalMode] = useState<'GENERAL' | 'INVESTMENT_OFFER' | 'MARKETPLACE_ORDER' | 'SERVICE_INQUIRY'>('GENERAL');
  const [offerAmount, setOfferAmount] = useState<number>(5000);
  const [sentToast, setSentToast] = useState(false);

  // Filter crops or items associated with this user
  const userCrops = crops.filter(c => c.producerName.toLowerCase().includes(targetUser.name.toLowerCase()) || c.producerId === targetUser.id);
  const userItems = marketplaceItems.filter(i => i.sellerId === targetUser.id || i.sellerName.toLowerCase().includes(targetUser.name.toLowerCase()));

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() && proposalMode === 'GENERAL') return;

    let finalMessage = inputText.trim();
    if (proposalMode === 'INVESTMENT_OFFER') {
      finalMessage = isEs
        ? `🤝 **Propuesta Formal de Inversión Agrícola**:\nHola ${targetUser.name}, me interesa estructurar una inversión de **$${offerAmount.toLocaleString()} MXN** en tus proyectos agroecológicos. ${inputText}`
        : `🤝 **Formal Agricultural Investment Proposal**:\nHello ${targetUser.name}, I am interested in structuring an investment of **$${offerAmount.toLocaleString()} MXN** into your agroecological lots. ${inputText}`;
    } else if (proposalMode === 'MARKETPLACE_ORDER') {
      finalMessage = isEs
        ? `🛒 **Solicitud de Compra / Pedido Marketplace**:\nHola ${targetUser.name}, deseo adquirir insumos/servicios de tu catálogo con protección Smart Escrow. ${inputText}`
        : `🛒 **Marketplace Purchase Inquiry**:\nHello ${targetUser.name}, I want to purchase items/services from your catalog under Smart Escrow protection. ${inputText}`;
    }

    const newMsg: Message = {
      id: `msg-${Date.now()}`,
      senderId: currentUser?.id || 'guest',
      senderName: currentUser?.name || (isEs ? 'Inversionista Milpa' : 'Milpa Investor'),
      senderAvatar: currentUser?.avatar || `https://ui-avatars.com/api/?name=User&background=047857&color=fff`,
      receiverId: targetUser.id,
      text: finalMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      proposalType: proposalMode,
      proposalDetails: proposalMode === 'INVESTMENT_OFFER' ? { amount: offerAmount } : undefined
    };

    onSendMessage(newMsg);
    setSentToast(true);
    setInputText('');
    setTimeout(() => {
      setSentToast(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-xl w-full shadow-2xl overflow-hidden flex flex-col">
        
        {/* Header with recipient identity */}
        <div className="bg-gradient-to-r from-emerald-900 to-green-950 p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={targetUser.avatar}
                alt={targetUser.name}
                className="w-12 h-12 rounded-full object-cover border-2 border-emerald-400"
              />
              <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-400 border-2 border-emerald-950 rounded-full" />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base leading-tight">{targetUser.name}</h3>
                {targetUser.isVerifiedSeller && (
                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                    <ShieldCheck className="h-3 w-3 text-emerald-400" />
                    {isEs ? "Verificado" : "Verified"}
                  </span>
                )}
              </div>
              <p className="text-xs text-emerald-200/80 flex items-center gap-2 mt-0.5">
                <span>
                  {targetUser.role === 'PRODUCER'
                    ? (isEs ? '🌱 Productor Agrícola' : '🌱 Agricultural Producer')
                    : targetUser.role === 'INVESTOR'
                    ? (isEs ? '💼 Inversionista Agrofinanciero' : '💼 Impact Investor')
                    : (isEs ? '🛒 Proveedor Marketplace' : '🛒 Marketplace Supplier')}
                </span>
                {targetUser.location && (
                  <>
                    <span>•</span>
                    <span className="flex items-center gap-0.5">
                      <MapPin className="h-3 w-3 text-emerald-400" />
                      {targetUser.location}
                    </span>
                  </>
                )}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-emerald-300 hover:text-white bg-white/10 hover:bg-white/20 p-2 rounded-full transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4">
          
          {/* Interaction Mode Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              {isEs ? "Propósito del Contacto Directo" : "Direct Interaction Purpose"}
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setProposalMode('GENERAL')}
                className={`py-2 px-2.5 rounded-xl text-xs font-bold transition-all flex flex-col items-center gap-1 border ${
                  proposalMode === 'GENERAL'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <MessageSquare className="h-4 w-4 text-emerald-600" />
                <span>{isEs ? "Mensaje General" : "General Chat"}</span>
              </button>

              <button
                type="button"
                onClick={() => setProposalMode('INVESTMENT_OFFER')}
                className={`py-2 px-2.5 rounded-xl text-xs font-bold transition-all flex flex-col items-center gap-1 border ${
                  proposalMode === 'INVESTMENT_OFFER'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Handshake className="h-4 w-4 text-blue-600" />
                <span>{isEs ? "Proponer Inversión" : "Invest Offer"}</span>
              </button>

              <button
                type="button"
                onClick={() => setProposalMode('MARKETPLACE_ORDER')}
                className={`py-2 px-2.5 rounded-xl text-xs font-bold transition-all flex flex-col items-center gap-1 border ${
                  proposalMode === 'MARKETPLACE_ORDER'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <ShoppingBag className="h-4 w-4 text-amber-600" />
                <span>{isEs ? "Comprar / Insumos" : "Order / Goods"}</span>
              </button>
            </div>
          </div>

          {/* If Investment Offer Mode */}
          {proposalMode === 'INVESTMENT_OFFER' && (
            <div className="bg-blue-50/70 border border-blue-200 p-4 rounded-2xl space-y-2">
              <label className="block text-xs font-bold text-blue-950">
                {isEs ? "Monto Propuesto para Financiamiento ($ MXN):" : "Proposed Investment Capital ($ MXN):"}
              </label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-blue-600" />
                <input
                  type="number"
                  value={offerAmount}
                  onChange={(e) => setOfferAmount(Number(e.target.value))}
                  min={500}
                  step={500}
                  className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-blue-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none font-bold text-blue-950"
                />
              </div>
              <p className="text-[11px] text-blue-800">
                {isEs
                  ? "Esta propuesta iniciará un canal seguro de negociación para asignar tokens de cosecha."
                  : "This proposal opens a direct channel to structure harvest token allocations."}
              </p>
            </div>
          )}

          {/* If user has crops or catalog items */}
          {userCrops.length > 0 && (
            <div className="bg-slate-50 border border-slate-200/80 p-3 rounded-2xl">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
                {isEs ? "Cultivos Vinculados de este Productor:" : "Active Crops by this Producer:"}
              </span>
              <div className="flex flex-wrap gap-2">
                {userCrops.map(c => (
                  <span key={c.id} className="bg-white border border-emerald-300 text-emerald-900 text-xs px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1.5 shadow-sm">
                    🌱 {c.name} (${c.tokenPrice} MXN)
                  </span>
                ))}
              </div>
            </div>
          )}

          {userItems.length > 0 && (
            <div className="bg-slate-50 border border-slate-200/80 p-3 rounded-2xl">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
                {isEs ? "Insumos y Servicios en Catálogo:" : "Catalog Items & Services:"}
              </span>
              <div className="flex flex-wrap gap-2">
                {userItems.map(i => (
                  <span key={i.id} className="bg-white border border-amber-300 text-amber-900 text-xs px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1.5 shadow-sm">
                    📦 {i.title} (${i.priceMxn} MXN/{i.unit})
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Message Textarea */}
          <form onSubmit={handleSend} className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {isEs ? "Tu Mensaje o Condiciones de Acuerdo:" : "Your Message or Deal Terms:"}
              </label>
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={
                  proposalMode === 'INVESTMENT_OFFER'
                    ? (isEs ? "Especifica fechas estimadas de desembolso, rendimiento esperado o preguntas sobre el lote..." : "Specify disbursement dates, expected return, or questions...")
                    : proposalMode === 'MARKETPLACE_ORDER'
                    ? (isEs ? "Indica volumen deseado, dirección de entrega y requerimientos de factura..." : "Indicate volume, delivery address, and invoicing requirements...")
                    : (isEs ? "Escribe tu consulta directamente al usuario..." : "Write your direct inquiry...")
                }
                rows={3}
                className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                required
              />
            </div>

            <div className="flex justify-between items-center pt-2">
              <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
                <span>{isEs ? "Canal encriptado y trazable" : "Encrypted & traceable channel"}</span>
              </div>

              <button
                type="submit"
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-2.5 rounded-xl text-sm flex items-center gap-2 shadow-md transition-colors cursor-pointer"
              >
                <Send className="h-4 w-4" />
                <span>{isEs ? "Enviar Mensaje Directo" : "Send Direct Message"}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Success confirmation */}
        {sentToast && (
          <div className="absolute inset-0 bg-emerald-950/90 flex flex-col items-center justify-center text-center p-6 text-white animate-fade-in z-50">
            <CheckCircle2 className="h-12 w-12 text-emerald-400 mb-2 animate-bounce" />
            <h3 className="text-xl font-bold mb-1">
              {isEs ? "¡Mensaje Enviado con Éxito!" : "Message Sent Successfully!"}
            </h3>
            <p className="text-xs text-emerald-200">
              {isEs ? `Tu contacto directo con ${targetUser.name} ha sido registrado.` : `Your direct inquiry to ${targetUser.name} has been logged.`}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
