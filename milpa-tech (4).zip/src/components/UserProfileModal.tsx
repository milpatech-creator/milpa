import React, { useState } from 'react';
import {
  X, Star, ShieldCheck, MapPin, Phone, Globe, Award, Image as ImageIcon,
  CheckCircle2, Plus, Edit3, UserCheck, MessageSquare, ThumbsUp, Calendar,
  ExternalLink, Sparkles, Upload, FileText, Share2, Shield, Lock, Scale,
  Landmark, Fingerprint, FileCheck, Check, Copy, AlertCircle, QrCode,
  ArrowUpRight, Info, RefreshCw, Camera
} from 'lucide-react';
import { UserProfile, PeerReview, Language } from '../types';

interface UserProfileModalProps {
  user: UserProfile;
  currentUser: UserProfile | null;
  lang: Language;
  isOpen: boolean;
  onClose: () => void;
  onUpdateProfile?: (updated: UserProfile) => void;
  reviews?: PeerReview[];
  onAddReview?: (review: PeerReview) => void;
}

const PRESET_PHOTOS = [
  { url: "https://images.unsplash.com/photo-1530595467537-0b5996c41f2d?q=80&w=800&auto=format&fit=crop", title: "Cosecha de Maíz Criollo" },
  { url: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?q=80&w=800&auto=format&fit=crop", title: "Tractor y Campo Agroecológico" },
  { url: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=800&auto=format&fit=crop", title: "Finca de Café de Altura" },
  { url: "https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?q=80&w=800&auto=format&fit=crop", title: "Huerta de Aguacate Hass" },
  { url: "https://images.unsplash.com/photo-1569428034239-f9565e32e224?q=80&w=800&auto=format&fit=crop", title: "Plantación de Agave Mezcalero" },
  { url: "https://images.unsplash.com/photo-1595974482597-4b8da8879bc5?q=80&w=800&auto=format&fit=crop", title: "Invernadero Automatizado IoT" }
];

const PRESET_AVATARS = [
  { url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=300&auto=format&fit=crop", label: "Productor Don Juan" },
  { url: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=300&auto=format&fit=crop", label: "Inversionista Elena" },
  { url: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=300&auto=format&fit=crop", label: "Comerciante Agro" },
  { url: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=300&auto=format&fit=crop", label: "Productora Agroecológica" },
  { url: "https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=300&auto=format&fit=crop", label: "Fondo Agrícola S.A." },
  { url: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=300&auto=format&fit=crop", label: "Auditora SENASICA" },
  { url: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=300&auto=format&fit=crop", label: "Ingeniero Agrónomo" },
  { url: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=300&auto=format&fit=crop", label: "Especialista IoT" }
];

const PRESET_ENDORSEMENTS = [
  "Cumplimiento en Cosechas",
  "Prácticas 100% Orgánicas",
  "Transparencia Financiera",
  "Pagos Puntuales",
  "Comunicación Constante",
  "Socio Confiable",
  "Innovación Agroecológica"
];

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  user,
  currentUser,
  lang,
  isOpen,
  onClose,
  onUpdateProfile,
  reviews = [],
  onAddReview
}) => {
  if (!isOpen) return null;

  const isOwnProfile = currentUser && currentUser.id === user.id;
  const [activeTab, setActiveTab] = useState<'info' | 'compliance' | 'photos' | 'reviews' | 'edit'>('info');
  const [showCertificateModal, setShowCertificateModal] = useState(false);
  const [copiedHash, setCopiedHash] = useState(false);

  // KYC/AML Compliance Computed Attributes
  const kycLevel = user.verificationLevel ?? (user.isVerifiedSeller ? 3 : 2);
  const kycStatus = user.kycStatus || (kycLevel === 3 ? 'TIER_3_FULL' : kycLevel === 2 ? 'TIER_2_VERIFIED' : 'TIER_1_BASIC');
  const amlStatus = user.amlStatus || 'PASSED_CLEAN';
  const kycScore = user.kycScore || (kycLevel === 3 ? 99.4 : kycLevel === 2 ? 96.2 : 88.5);
  const amlScore = user.amlScreeningScore || 99.8;
  const fraudScore = user.fraudScore || 99;
  const rfcTaxId = user.rfcTaxId || (user.role === 'PRODUCER' ? 'PEAJ780415A90' : user.role === 'INVESTOR' ? 'EGI160520PL8' : 'ACV091102MK4');
  const verifiedDate = user.kycVerifiedDate || '12 Enero 2026';
  const auditorName = user.kycAuditor || 'MilpaTrust CNBV & SAT Compliance Protocol';
  const didHash = user.walletAddress ? `did:polygon:${user.walletAddress}` : 'did:polygon:0x3db5ae71bca21cf29871fa8d810ba2cde1297fb9';

  // Photo state
  const [userPhotos, setUserPhotos] = useState<string[]>(
    user.photos && user.photos.length > 0
      ? user.photos
      : PRESET_PHOTOS.slice(0, 3).map(p => p.url)
  );
  const [newPhotoUrl, setNewPhotoUrl] = useState('');
  const [showPhotoPicker, setShowPhotoPicker] = useState(false);
  const [showAvatarPickerModal, setShowAvatarPickerModal] = useState(false);
  const [avatarUploadFileName, setAvatarUploadFileName] = useState<string | null>(null);

  // Review Form state
  const [ratingInput, setRatingInput] = useState<number>(5);
  const [commentInput, setCommentInput] = useState('');
  const [selectedEndorsements, setSelectedEndorsements] = useState<string[]>([]);
  const [reviewSubmittedToast, setReviewSubmittedToast] = useState(false);

  // Edit Profile Form state
  const [editName, setEditName] = useState(user.name);
  const [editBio, setEditBio] = useState(user.bio || '');
  const [editLocation, setEditLocation] = useState(user.location || '');
  const [editPhone, setEditPhone] = useState(user.phone || '');
  const [editWebsite, setEditWebsite] = useState(user.website || '');
  const [editHectares, setEditHectares] = useState(user.farmHectares || 15);
  const [editExperience, setEditExperience] = useState(user.experienceYears || 8);
  const [editCertifications, setEditCertifications] = useState(
    Array.isArray(user.certifications) ? user.certifications.join(', ') : (user.certifications || 'Certificado Orgánico SAGARPA, Comercio Justo')
  );
  const [editAvatar, setEditAvatar] = useState(user.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=150&auto=format&fit=crop');

  // Handle local avatar upload
  const handleAvatarFileUpload = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert(lang === 'es' ? "Por favor selecciona un archivo de imagen válido." : "Please select a valid image file.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      alert(lang === 'es' ? "La imagen no debe superar los 5 MB." : "Image must be under 5 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        const dataUrl = e.target.result as string;
        setEditAvatar(dataUrl);
        setAvatarUploadFileName(file.name);
      }
    };
    reader.readAsDataURL(file);
  };

  // Safe reviews array
  const safeReviews = reviews || [];

  // Filter reviews for this user
  const userReviews = safeReviews.filter(r => r && (r.targetUserId === user.id || r.targetUserId === user.name));
  const avgRating = userReviews.length > 0
    ? (userReviews.reduce((acc, r) => acc + r.rating, 0) / userReviews.length).toFixed(1)
    : (user.rating || 4.9).toFixed(1);

  const toggleEndorsement = (tag: string) => {
    if (selectedEndorsements.includes(tag)) {
      setSelectedEndorsements(selectedEndorsements.filter(t => t !== tag));
    } else {
      setSelectedEndorsements([...selectedEndorsements, tag]);
    }
  };

  const handleCopyHash = () => {
    navigator.clipboard.writeText(didHash);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 2500);
  };

  const handleAddPhoto = (url: string) => {
    if (!url) return;
    const updated = [url, ...userPhotos];
    setUserPhotos(updated);
    setNewPhotoUrl('');
    setShowPhotoPicker(false);
    if (onUpdateProfile) {
      onUpdateProfile({ ...user, photos: updated });
    }
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!commentInput.trim()) return;

    const newReview: PeerReview = {
      id: `rev-${Date.now()}`,
      targetUserId: user.id,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorRole: currentUser.role,
      authorAvatar: currentUser.avatar,
      rating: ratingInput,
      comment: commentInput.trim(),
      endorsements: selectedEndorsements,
      date: new Date().toLocaleDateString(lang === 'es' ? 'es-MX' : 'en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
    };

    if (onAddReview) {
      onAddReview(newReview);
    }

    setCommentInput('');
    setSelectedEndorsements([]);
    setReviewSubmittedToast(true);
    setTimeout(() => setReviewSubmittedToast(false), 3000);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserProfile = {
      ...user,
      name: editName,
      bio: editBio,
      location: editLocation,
      phone: editPhone,
      website: editWebsite,
      farmHectares: editHectares,
      experienceYears: editExperience,
      certifications: editCertifications.split(',').map(s => s.trim()).filter(Boolean),
      avatar: editAvatar,
      photos: userPhotos
    };

    if (onUpdateProfile) {
      onUpdateProfile(updated);
    }
    setActiveTab('info');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-fade-in">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-emerald-500/30 rounded-3xl shadow-2xl overflow-hidden my-8">
        
        {/* Cover Header Banner */}
        <div className="relative h-48 sm:h-56 bg-gradient-to-r from-emerald-950 via-green-950 to-teal-950 overflow-hidden">
          <div className="absolute inset-0 opacity-30 bg-[radial-gradient(#22c55e_1px,transparent_1px)] [background-size:16px_16px]"></div>
          
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-10 p-2.5 rounded-full bg-slate-950/70 hover:bg-slate-900 text-slate-300 hover:text-white border border-emerald-500/30 transition-all shadow-xl"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Top Visual KYC/AML Status Ribbon & Certificate Trigger */}
          <div className="absolute top-4 left-6 flex flex-wrap items-center gap-2">
            <button
              onClick={() => setShowCertificateModal(true)}
              className={`group flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-black tracking-wider uppercase backdrop-blur-md transition-all shadow-lg border ${
                kycLevel === 3
                  ? 'bg-emerald-950/80 border-emerald-400 text-emerald-300 hover:bg-emerald-900/90 shadow-emerald-900/40 ring-1 ring-emerald-500/30'
                  : kycLevel === 2
                  ? 'bg-cyan-950/80 border-cyan-400 text-cyan-300 hover:bg-cyan-900/90 shadow-cyan-900/40'
                  : 'bg-amber-950/80 border-amber-400 text-amber-300 hover:bg-amber-900/90'
              }`}
              title={lang === 'es' ? "Clic para ver Certificado Oficial KYC/AML" : "Click to view Official KYC/AML Certificate"}
            >
              <div className="relative flex items-center justify-center">
                <ShieldCheck className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
                <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              </div>
              <span className="font-extrabold">
                {kycLevel === 3
                  ? (lang === 'es' ? "KYC/AML NIVEL 3: AUDITORÍA INTEGRAL APROBADA" : "KYC/AML TIER 3: FULLY AUDITED")
                  : kycLevel === 2
                  ? (lang === 'es' ? "KYC/AML NIVEL 2: RFC & BIOMETRÍA VERIFICADA" : "KYC/AML TIER 2: TAX ID & BIOMETRICS")
                  : (lang === 'es' ? "KYC NIVEL 1: CONTACTO VALIDADO" : "KYC TIER 1: CONTACT VALIDATED")}
              </span>
              <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-400/30 ml-1">
                {kycScore}%
              </span>
            </button>

            <span className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-950/60 border border-slate-700/60 text-slate-300 text-xs font-bold backdrop-blur-md">
              <Scale className="w-3.5 h-3.5 text-teal-400" />
              <span>AML: {amlStatus === 'PASSED_CLEAN' ? (lang === 'es' ? 'OFAC/SAT Sin Riesgo' : 'OFAC/SAT Clean') : amlStatus}</span>
            </span>
          </div>
        </div>

        {/* Profile Identity Bar */}
        <div className="relative px-6 sm:px-8 pb-6 bg-slate-900 border-b border-slate-800">
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between -mt-16 sm:-mt-20 gap-4 mb-4">
            
            <div className="flex items-end gap-4">
              <div className="relative group">
                <img
                  src={isOwnProfile ? (editAvatar || user.avatar) : (user.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=150&auto=format&fit=crop")}
                  alt={user.name}
                  className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover border-4 border-slate-900 shadow-2xl bg-slate-800"
                />
                {/* Official Verification Stamp */}
                <div
                  onClick={() => setShowCertificateModal(true)}
                  className="absolute -bottom-2 -right-2 p-1.5 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-500 text-slate-950 shadow-xl cursor-pointer hover:scale-110 transition-transform border-2 border-slate-900"
                  title={lang === 'es' ? "Usuario Verificado KYC/AML - Clic para ver Dictamen" : "KYC/AML Verified - Click to inspect"}
                >
                  <ShieldCheck className="w-5 h-5 fill-slate-950 text-emerald-200" />
                </div>

                {/* Quick Avatar Change Button for Own Profile */}
                {isOwnProfile && (
                  <button
                    type="button"
                    onClick={() => setShowAvatarPickerModal(true)}
                    className="absolute inset-0 bg-black/60 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-[10px] font-bold p-1 cursor-pointer border-4 border-emerald-500/60"
                    title={lang === 'es' ? "Cambiar foto de perfil" : "Change profile picture"}
                  >
                    <Camera className="w-5 h-5 text-emerald-400 mb-0.5" />
                    <span>{lang === 'es' ? "Cambiar Foto" : "Edit Photo"}</span>
                  </button>
                )}
              </div>

              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2">
                    {user.name}
                  </h2>
                  
                  {/* Inline Verified Pill */}
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-black">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{lang === 'es' ? 'Verificado KYC' : 'KYC Verified'}</span>
                  </span>

                  {isOwnProfile && (
                    <button
                      type="button"
                      onClick={() => setShowAvatarPickerModal(true)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition-colors"
                    >
                      <Camera className="w-3 h-3 text-emerald-400" />
                      <span>{lang === 'es' ? "Foto de Perfil" : "Profile Photo"}</span>
                    </button>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2 mt-1">
                  <span className={`px-3 py-1 rounded-full text-xs font-black tracking-wider uppercase border ${
                    user.role === 'PRODUCER'
                      ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300'
                      : user.role === 'INVESTOR'
                      ? 'bg-cyan-950/80 border-cyan-500/50 text-cyan-300'
                      : 'bg-amber-950/80 border-amber-500/50 text-amber-300'
                  }`}>
                    {user.role === 'PRODUCER'
                      ? (lang === 'es' ? '🌾 Productor Orgánico' : '🌾 Organic Producer')
                      : user.role === 'INVESTOR'
                      ? (lang === 'es' ? '💎 Inversionista de Impacto' : '💎 Impact Investor')
                      : (lang === 'es' ? '🛒 Comprador / Vendedor Marketplace' : '🛒 Marketplace Buyer & Trader')}
                  </span>

                  <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-extrabold">
                    <Star className="w-3.5 h-3.5 fill-amber-400" />
                    <span>{avgRating}</span>
                    <span className="text-slate-400">({userReviews.length} {lang === 'es' ? 'reseñas' : 'reviews'})</span>
                  </div>

                  {user.joinedDate && (
                    <span className="text-slate-400 text-xs font-medium">
                      {lang === 'es' ? `Miembro desde ${user.joinedDate}` : `Member since ${user.joinedDate}`}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={() => setShowCertificateModal(true)}
                className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/30 rounded-xl font-extrabold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md"
              >
                <QrCode className="w-4 h-4 text-emerald-400" />
                <span>{lang === 'es' ? "Ver Dictamen KYC" : "KYC Certificate"}</span>
              </button>

              {isOwnProfile ? (
                <button
                  onClick={() => setActiveTab('edit')}
                  className="flex-1 sm:flex-initial px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-extrabold text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-900/30"
                >
                  <Edit3 className="w-4 h-4" />
                  <span>{lang === 'es' ? "Editar Mi Perfil" : "Edit My Profile"}</span>
                </button>
              ) : (
                <button
                  onClick={() => setActiveTab('reviews')}
                  className="flex-1 sm:flex-initial px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl font-extrabold text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-900/30"
                >
                  <Star className="w-4 h-4" />
                  <span>{lang === 'es' ? "Escribir Reseña" : "Write Review"}</span>
                </button>
              )}
            </div>
          </div>

          {/* VISUAL KYC / AML COMPLIANCE BADGE STRIP */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-emerald-950/40 border border-emerald-500/30 shadow-inner mt-3">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              
              <div className="flex flex-wrap items-center gap-2">
                {/* 1. Main KYC Tier Badge */}
                <div
                  onClick={() => setActiveTab('compliance')}
                  className="cursor-pointer px-3 py-1.5 rounded-xl bg-emerald-950/90 border border-emerald-400/50 text-emerald-300 text-xs font-black flex items-center gap-2 hover:bg-emerald-900/80 transition-all shadow-sm"
                  title="Auditoría KYC Nivel 3 Integral"
                >
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>{lang === 'es' ? `KYC: Nivel ${kycLevel} Integral (${kycScore}%)` : `KYC: Tier ${kycLevel} Full (${kycScore}%)`}</span>
                </div>

                {/* 2. AML Anti-Money Laundering Badge */}
                <div
                  onClick={() => setActiveTab('compliance')}
                  className="cursor-pointer px-3 py-1.5 rounded-xl bg-teal-950/90 border border-teal-400/50 text-teal-300 text-xs font-black flex items-center gap-2 hover:bg-teal-900/80 transition-all shadow-sm"
                  title="Filtro Anti-Lavado de Dinero (OFAC / PEPs / SAT 69-B)"
                >
                  <Scale className="w-4 h-4 text-teal-400" />
                  <span>{lang === 'es' ? `AML: Sin Riesgo (${amlScore}%)` : `AML: Clean Screening (${amlScore}%)`}</span>
                </div>

                {/* 3. SAT Tax Registration */}
                <div className="px-3 py-1.5 rounded-xl bg-slate-800/90 border border-slate-700 text-cyan-300 text-xs font-bold flex items-center gap-1.5">
                  <Landmark className="w-3.5 h-3.5 text-cyan-400" />
                  <span>RFC: <strong className="font-mono text-white">{rfcTaxId}</strong></span>
                </div>

                {/* 4. Escrow Secured Badge */}
                <div className="px-3 py-1.5 rounded-xl bg-slate-800/90 border border-slate-700 text-amber-300 text-xs font-bold flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-amber-400" />
                  <span>{lang === 'es' ? 'Smart Escrow Asegurado' : 'Escrow Protected'}</span>
                </div>
              </div>

              {/* Action to Compliance Tab */}
              <button
                onClick={() => setActiveTab('compliance')}
                className="text-xs font-black text-emerald-400 hover:text-emerald-300 flex items-center gap-1 whitespace-nowrap"
              >
                <span>{lang === 'es' ? "Ver detalles de auditoría" : "View audit details"}</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 px-6 overflow-x-auto">
          <button
            onClick={() => setActiveTab('info')}
            className={`px-5 py-3.5 text-xs font-black tracking-wider uppercase border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'info'
                ? 'border-emerald-500 text-emerald-400 bg-emerald-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>{lang === 'es' ? "Información Pública" : "Public Info"}</span>
          </button>

          {/* DEDICATED COMPLIANCE & KYC/AML TAB */}
          <button
            onClick={() => setActiveTab('compliance')}
            className={`px-5 py-3.5 text-xs font-black tracking-wider uppercase border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'compliance'
                ? 'border-emerald-500 text-emerald-400 bg-emerald-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>{lang === 'es' ? "Seguridad & KYC/AML" : "Security & KYC/AML"}</span>
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
          </button>

          <button
            onClick={() => setActiveTab('photos')}
            className={`px-5 py-3.5 text-xs font-black tracking-wider uppercase border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'photos'
                ? 'border-emerald-500 text-emerald-400 bg-emerald-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ImageIcon className="w-4 h-4" />
            <span>{lang === 'es' ? "Fotos del Campo" : "Field Photos"} ({userPhotos.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('reviews')}
            className={`px-5 py-3.5 text-xs font-black tracking-wider uppercase border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'reviews'
                ? 'border-emerald-500 text-emerald-400 bg-emerald-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Star className="w-4 h-4" />
            <span>{lang === 'es' ? "Reseñas & Validación" : "Reviews & Trust"} ({userReviews.length})</span>
          </button>

          {isOwnProfile && (
            <button
              onClick={() => setActiveTab('edit')}
              className={`px-5 py-3.5 text-xs font-black tracking-wider uppercase border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
                activeTab === 'edit'
                  ? 'border-emerald-500 text-emerald-400 bg-emerald-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Edit3 className="w-4 h-4" />
              <span>{lang === 'es' ? "Editar Perfil" : "Edit Profile"}</span>
            </button>
          )}
        </div>

        {/* Tab Content Body */}
        <div className="p-6 sm:p-8 max-h-[60vh] overflow-y-auto space-y-6">

          {/* TAB 1: INFORMACIÓN PÚBLICA */}
          {activeTab === 'info' && (
            <div className="space-y-6 animate-fade-in">
              {/* Bio Section */}
              <div className="bg-slate-950/60 p-5 rounded-2xl border border-slate-800 space-y-2">
                <h3 className="text-xs font-black uppercase tracking-widest text-emerald-400 flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  <span>{lang === 'es' ? "Biografía & Trayectoria" : "Biography & Background"}</span>
                </h3>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {user.bio || (user.role === 'PRODUCER'
                    ? "Productor agrícola comprometido con la soberanía alimentaria, cultivo de granos criollos y la implementación de técnicas de agricultura regenerativa y captura de carbono en el suelo."
                    : user.role === 'INVESTOR'
                    ? "Inversionista apasionado por el impacto agroecológico y la democratización del capital para comunidades campesinas en México."
                    : "Comercializador y comprador en Marketplace dedicado a la adquisición de lotes agrícolas tokenizados y distribución justa directa a cadenas de valor.")}
                </p>
              </div>

              {/* Data Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 flex items-start gap-3">
                  <div className="p-2.5 rounded-xl bg-emerald-950/80 text-emerald-400 border border-emerald-500/30">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase text-slate-400">{lang === 'es' ? "Ubicación" : "Location"}</span>
                    <p className="text-sm font-extrabold text-white">{user.location || "Oaxaca, México"}</p>
                  </div>
                </div>

                <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 flex items-start gap-3">
                  <div className="p-2.5 rounded-xl bg-cyan-950/80 text-cyan-400 border border-cyan-500/30">
                    <Calendar className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase text-slate-400">{lang === 'es' ? "Experiencia" : "Experience"}</span>
                    <p className="text-sm font-extrabold text-white">{user.experienceYears || 10} {lang === 'es' ? "Años en el Sector" : "Years in Sector"}</p>
                  </div>
                </div>

                <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 flex items-start gap-3">
                  <div className="p-2.5 rounded-xl bg-teal-950/80 text-teal-400 border border-teal-500/30">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase text-slate-400">
                      {user.role === 'PRODUCER' ? (lang === 'es' ? "Hectáreas" : "Hectares") : user.role === 'INVESTOR' ? (lang === 'es' ? "Proyectos" : "Projects") : (lang === 'es' ? "Volumen Operado" : "Volume Traded")}
                    </span>
                    <p className="text-sm font-extrabold text-white">
                      {user.role === 'PRODUCER' ? `${user.farmHectares || 25} Ha` : user.role === 'INVESTOR' ? `12 ${lang === 'es' ? "Cultivos Financiados" : "Funded Crops"}` : `$450K MXN`}
                    </p>
                  </div>
                </div>
              </div>

              {/* Contact & Verification Box */}
              <div className="bg-slate-950/60 p-5 rounded-2xl border border-slate-800 space-y-4">
                <h3 className="text-xs font-black uppercase tracking-widest text-emerald-400 flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  <span>{lang === 'es' ? "Contacto & Documentación de Confianza" : "Verified Contact & Documentation"}</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-slate-400">{lang === 'es' ? "Teléfono Verificado:" : "Verified Phone:"}</span>
                    <span className="font-extrabold text-white">{user.phone || "+52 951 492 8102"}</span>
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-slate-400">{lang === 'es' ? "Sitio Web / Org:" : "Website / Org:"}</span>
                    <span className="font-extrabold text-emerald-400">{user.website || "milpatech.org"}</span>
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800 col-span-1 sm:col-span-2">
                    <span className="text-slate-400">{lang === 'es' ? "Billetera Blockchain:" : "Blockchain Wallet:"}</span>
                    <span className="font-mono text-emerald-400 text-[11px] truncate">{user.walletAddress || "0x3db5ae71bca21cf29871fa8d810ba2cde1297fb9"}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: SEGURIDAD & KYC/AML COMPLIANCE */}
          {activeTab === 'compliance' && (
            <div className="space-y-6 animate-fade-in">
              
              {/* Compliance Hero Card */}
              <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950/60 border-2 border-emerald-500/40 p-6 sm:p-7 shadow-2xl">
                <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

                <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                  <div className="flex items-start gap-4">
                    <div className="p-3.5 rounded-2xl bg-emerald-500/20 border-2 border-emerald-400 text-emerald-300 shadow-xl">
                      <ShieldCheck className="w-9 h-9" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400 text-emerald-300 text-[10px] font-black uppercase tracking-wider">
                          {lang === 'es' ? "Expediente Aprobado & Vigente" : "Approved & Active Record"}
                        </span>
                        <span className="text-xs text-slate-400 font-medium">
                          {lang === 'es' ? `Auditado: ${verifiedDate}` : `Audited: ${verifiedDate}`}
                        </span>
                      </div>
                      <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight mt-1">
                        {lang === 'es' ? "Dictamen Integral de Verificación KYC/AML" : "Comprehensive KYC/AML Verification Certificate"}
                      </h3>
                      <p className="text-xs text-slate-300 mt-1 max-w-xl">
                        {lang === 'es'
                          ? `Este usuario ha completado el protocolo de validación de identidad nivel ${kycLevel}, confronta fiscal SAT y screening anti-lavado de dinero (AML) conforme a los estándares de la plataforma.`
                          : `This member has completed Tier ${kycLevel} identity validation, SAT tax verification, and AML anti-money laundering screening in full platform compliance.`}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row md:flex-col items-stretch sm:items-center md:items-end gap-2 w-full md:w-auto">
                    <button
                      onClick={() => setShowCertificateModal(true)}
                      className="px-5 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-emerald-900/40 flex items-center justify-center gap-2 transition-all"
                    >
                      <FileCheck className="w-4 h-4" />
                      <span>{lang === 'es' ? "Ver Certificado Oficial (PDF/QR)" : "View Official Certificate"}</span>
                    </button>
                    <span className="text-[11px] text-emerald-400/80 text-center font-mono">
                      {auditorName}
                    </span>
                  </div>
                </div>

                {/* Score Indicators Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800">
                  <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
                    <div className="flex items-center justify-between text-slate-400 text-[10px] font-bold uppercase">
                      <span>{lang === 'es' ? "Score KYC Identidad" : "KYC Identity Score"}</span>
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    </div>
                    <div className="text-2xl font-black text-emerald-400 mt-1">{kycScore}%</div>
                    <span className="text-[10px] text-slate-400">{lang === 'es' ? "Biometría & INE Validados" : "Biometrics & ID Validated"}</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
                    <div className="flex items-center justify-between text-slate-400 text-[10px] font-bold uppercase">
                      <span>{lang === 'es' ? "Filtro AML Anti-Lavado" : "AML Screening"}</span>
                      <Scale className="w-3.5 h-3.5 text-teal-400" />
                    </div>
                    <div className="text-2xl font-black text-teal-400 mt-1">{amlScore}%</div>
                    <span className="text-[10px] text-slate-400">{lang === 'es' ? "0 Listas Negras (OFAC/SAT)" : "OFAC/PEPs Clear"}</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
                    <div className="flex items-center justify-between text-slate-400 text-[10px] font-bold uppercase">
                      <span>{lang === 'es' ? "Índice Antifraude" : "Anti-Fraud Index"}</span>
                      <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                    </div>
                    <div className="text-2xl font-black text-cyan-400 mt-1">{fraudScore}/100</div>
                    <span className="text-[10px] text-slate-400">{lang === 'es' ? "Riesgo Nulo Calculado" : "Zero Calculated Risk"}</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
                    <div className="flex items-center justify-between text-slate-400 text-[10px] font-bold uppercase">
                      <span>{lang === 'es' ? "Protección Escrow" : "Escrow Protection"}</span>
                      <Lock className="w-3.5 h-3.5 text-amber-400" />
                    </div>
                    <div className="text-2xl font-black text-amber-400 mt-1">{lang === 'es' ? "100%" : "100%"}</div>
                    <span className="text-[10px] text-slate-400">{lang === 'es' ? "Custodia Smart Contract" : "Smart Contract Custody"}</span>
                  </div>
                </div>
              </div>

              {/* Six Pillars of Verification Checklist */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-black uppercase tracking-widest text-emerald-400 flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    <span>{lang === 'es' ? "6 Pilares de Verificación & Cumplimiento Acreditados" : "6 Accredited Verification & Compliance Pillars"}</span>
                  </h4>
                  <span className="text-[11px] text-slate-400 font-bold">
                    {lang === 'es' ? "6 de 6 Requisitos Cumplidos" : "6 of 6 Completed"}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {/* Pilar 1: Identidad Biometrizada */}
                  <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-emerald-500/40 transition-all space-y-2">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                          <Fingerprint className="w-5 h-5" />
                        </div>
                        <div>
                          <h5 className="text-sm font-extrabold text-white">
                            {lang === 'es' ? "1. Identidad Oficial & Biometría" : "1. Official ID & Biometrics"}
                          </h5>
                          <span className="text-[11px] text-slate-400">{lang === 'es' ? "INE / Pasaporte con chip NFC & Liveness Test" : "National ID / Passport & Proof of Life"}</span>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-500/30">
                        ✓ {lang === 'es' ? "Verificado" : "Passed"}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 pl-11">
                      {lang === 'es' ? "Cotejo biométrico facial 1:1 aprobado contra base de datos oficial. Prueba de vida activa sin indicios de manipulación digital." : "1:1 biometric facial match passed against official record."}
                    </p>
                  </div>

                  {/* Pilar 2: Validación Fiscal SAT */}
                  <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-emerald-500/40 transition-all space-y-2">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 rounded-xl bg-cyan-950 text-cyan-400 border border-cyan-500/30">
                          <Landmark className="w-5 h-5" />
                        </div>
                        <div>
                          <h5 className="text-sm font-extrabold text-white">
                            {lang === 'es' ? "2. Cumplimiento Fiscal SAT / RFC" : "2. Tax Compliance (SAT / RFC)"}
                          </h5>
                          <span className="text-[11px] font-mono text-cyan-300">{rfcTaxId}</span>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-500/30">
                        ✓ {lang === 'es' ? "Opinión 32-D Positiva" : "Active & Clear"}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 pl-11">
                      {lang === 'es' ? "Estatus tributario activo verificado en WebService del SAT. Cero antecedentes en listas de empresas que facturan operaciones simuladas (EFOS)." : "Tax status verified with zero alerts on simulated operations lists."}
                    </p>
                  </div>

                  {/* Pilar 3: Filtro Anti-Lavado AML */}
                  <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-emerald-500/40 transition-all space-y-2">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 rounded-xl bg-teal-950 text-teal-400 border border-teal-500/30">
                          <Scale className="w-5 h-5" />
                        </div>
                        <div>
                          <h5 className="text-sm font-extrabold text-white">
                            {lang === 'es' ? "3. Filtro Anti-Lavado (AML Screening)" : "3. AML Screening (Anti-Laundering)"}
                          </h5>
                          <span className="text-[11px] text-slate-400">OFAC / GAFI / PEPs / SAT 69-B</span>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-500/30">
                        ✓ {lang === 'es' ? "Limpio (0 Coincidencias)" : "Clean (0 Matches)"}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 pl-11">
                      {lang === 'es' ? "Rastreo continuo en bases internacionales de prevención de lavado de dinero, personas políticamente expuestas y sanciones internacionales." : "Continuous screening across international sanctions and PEPs databases."}
                    </p>
                  </div>

                  {/* Pilar 4: Dictamen de Parcela / Propiedad */}
                  <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-emerald-500/40 transition-all space-y-2">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                          <MapPin className="w-5 h-5" />
                        </div>
                        <div>
                          <h5 className="text-sm font-extrabold text-white">
                            {lang === 'es' ? "4. Trazabilidad & Dictamen de Tierra" : "4. Land Rights & GPS Traceability"}
                          </h5>
                          <span className="text-[11px] text-slate-400">{lang === 'es' ? "Certificado Agrario / Título Georreferenciado" : "Georeferenced Title & Polygon"}</span>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-500/30">
                        ✓ {lang === 'es' ? "Georreferenciado" : "Audited"}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 pl-11">
                      {lang === 'es' ? "Polígono agrícola satelital delimitado con coordenadas GPS reales y verificación registral ante el Registro Agrario Nacional / Catastro." : "Satellite polygon bounded with actual GPS coordinates and title deeds."}
                    </p>
                  </div>

                  {/* Pilar 5: Fitosanidad SENASICA & Sello Orgánico */}
                  <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-emerald-500/40 transition-all space-y-2">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 rounded-xl bg-amber-950 text-amber-400 border border-amber-500/30">
                          <Award className="w-5 h-5" />
                        </div>
                        <div>
                          <h5 className="text-sm font-extrabold text-white">
                            {lang === 'es' ? "5. Inocuidad SENASICA & Orgánico" : "5. Food Safety & Organic Standards"}
                          </h5>
                          <span className="text-[11px] text-slate-400">{lang === 'es' ? "SAGARPA / SENASICA / Buenas Prácticas" : "Organic SAGARPA / Fair Trade"}</span>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-500/30">
                        ✓ {lang === 'es' ? "Certificado" : "Certified"}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 pl-11">
                      {lang === 'es' ? "Acreditación de insumos agroecológicos libres de pesticidas sintéticos y cumplimiento de normativas de sanidad vegetal." : "Certified organic practices and phytosanitary traceability."}
                    </p>
                  </div>

                  {/* Pilar 6: Custodia Smart Escrow */}
                  <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-emerald-500/40 transition-all space-y-2">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 rounded-xl bg-purple-950 text-purple-400 border border-purple-500/30">
                          <Lock className="w-5 h-5" />
                        </div>
                        <div>
                          <h5 className="text-sm font-extrabold text-white">
                            {lang === 'es' ? "6. Custodia Smart Contract Escrow" : "6. Smart Contract Escrow Vault"}
                          </h5>
                          <span className="text-[11px] text-slate-400">{lang === 'es' ? "Depósito en Bóveda Criptográfica Polygon" : "Polygon Network Escrow Vault"}</span>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-500/30">
                        ✓ {lang === 'es' ? "Asegurado" : "Protected"}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 pl-11">
                      {lang === 'es' ? "Garantía de liquidación contra entrega con liberación de fondos por hitos tokenizados e inspección satelital." : "Milestone-based token release with multi-sig escrow arbitration."}
                    </p>
                  </div>
                </div>
              </div>

              {/* Cryptographic DID Proof Banner */}
              <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black uppercase text-slate-300 flex items-center gap-2">
                    <Fingerprint className="w-4 h-4 text-emerald-400" />
                    <span>{lang === 'es' ? "Identificador Criptográfico Descentralizado (DID)" : "Decentralized Identifier (DID Hash)"}</span>
                  </span>
                  <button
                    onClick={handleCopyHash}
                    className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-emerald-300 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all"
                  >
                    {copiedHash ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedHash ? (lang === 'es' ? "Copiado!" : "Copied!") : (lang === 'es' ? "Copiar DID" : "Copy DID")}</span>
                  </button>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs text-emerald-400/90 break-all">
                  {didHash}
                </div>
                <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-400 pt-1">
                  <span>{lang === 'es' ? "Red: Polygon PoS Mainnet • Smart Contract Verified" : "Network: Polygon PoS Mainnet"}</span>
                  <span className="text-emerald-400 font-bold">{lang === 'es' ? "Inmutable & Auditable" : "Immutable & Auditable"}</span>
                </div>
              </div>

            </div>
          )}
          {activeTab === 'photos' && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-black text-white">{lang === 'es' ? "Galería del Campo & Proyectos" : "Field & Project Gallery"}</h3>
                  <p className="text-xs text-slate-400">{lang === 'es' ? "Evidencia visual del trabajo agrícola y certificaciones de suelo." : "Visual evidence of agricultural labor and soil certificates."}</p>
                </div>

                {isOwnProfile && (
                  <button
                    onClick={() => setShowPhotoPicker(!showPhotoPicker)}
                    className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black flex items-center gap-2 transition-all"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{lang === 'es' ? "Cargar Foto" : "Add Photo"}</span>
                  </button>
                )}
              </div>

              {/* Add Photo Picker Form */}
              {showPhotoPicker && (
                <div className="p-4 bg-slate-950 rounded-2xl border border-emerald-500/40 space-y-4 animate-fade-in">
                  <h4 className="text-xs font-black uppercase text-emerald-400">{lang === 'es' ? "Añadir Nueva Fotografía" : "Add New Photograph"}</h4>
                  
                  <div className="space-y-2">
                    <label className="text-xs text-slate-300 font-bold">{lang === 'es' ? "Opción 1: Pegar URL de Imagen" : "Option 1: Paste Image URL"}</label>
                    <div className="flex gap-2">
                      <input
                        type="url"
                        placeholder="https://..."
                        value={newPhotoUrl}
                        onChange={(e) => setNewPhotoUrl(e.target.value)}
                        className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                      />
                      <button
                        onClick={() => handleAddPhoto(newPhotoUrl)}
                        className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-black"
                      >
                        {lang === 'es' ? "Guardar" : "Save"}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <label className="text-xs text-slate-300 font-bold">{lang === 'es' ? "Opción 2: Elegir de Imágenes Agrícolas" : "Option 2: Select Agricultural Preset"}</label>
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                      {PRESET_PHOTOS.map((preset, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleAddPhoto(preset.url)}
                          className="relative aspect-square rounded-xl overflow-hidden border border-slate-700 hover:border-emerald-400 group"
                        >
                          <img src={preset.url} alt={preset.title} className="w-full h-full object-cover group-hover:scale-110 transition-all" />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Photo Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {userPhotos.map((photoUrl, index) => (
                  <div key={index} className="relative group aspect-video rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 shadow-lg">
                    <img
                      src={photoUrl}
                      alt={`Foto ${index + 1}`}
                      className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-all flex items-end p-3">
                      <span className="text-[10px] font-bold text-emerald-300">
                        {lang === 'es' ? `Foto del Campo #${index + 1}` : `Field Photo #${index + 1}`}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: RESEÑAS Y VALIDACIÓN */}
          {activeTab === 'reviews' && (
            <div className="space-y-6 animate-fade-in">
              {/* Review Header Stats */}
              <div className="bg-gradient-to-r from-emerald-950/80 to-slate-950 p-5 rounded-2xl border border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="text-center p-3 bg-slate-900 rounded-xl border border-emerald-500/30">
                    <span className="text-3xl font-black text-amber-400">{avgRating}</span>
                    <span className="block text-[10px] text-slate-400 font-bold uppercase">/ 5.0 Estrellas</span>
                  </div>
                  <div>
                    <h3 className="text-base font-black text-white">{lang === 'es' ? "Índice de Confianza Comunitario" : "Community Trust Score"}</h3>
                    <p className="text-xs text-emerald-300 font-bold">{lang === 'es' ? "98% Validación Positiva entre Productor e Inversionistas" : "98% Positive Peer Validation"}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-3 py-1.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-black uppercase">
                    {userReviews.length} {lang === 'es' ? "Reseñas Verificadas" : "Verified Reviews"}
                  </span>
                </div>
              </div>

              {/* Submit Review Form (If signed in and not own profile) */}
              {currentUser && !isOwnProfile && (
                <form onSubmit={handleSubmitReview} className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-4">
                  <h4 className="text-xs font-black uppercase tracking-widest text-emerald-400 flex items-center gap-2">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <span>{lang === 'es' ? "Dejar Reseña de Validación de Par" : "Leave Peer Validation Review"}</span>
                  </h4>

                  {reviewSubmittedToast && (
                    <div className="p-3 bg-emerald-950 border border-emerald-500/50 text-emerald-300 text-xs font-black rounded-xl">
                      {lang === 'es' ? "¡Reseña enviada exitosamente!" : "Review submitted successfully!"}
                    </div>
                  )}

                  {/* Star Selector */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-300 font-bold">{lang === 'es' ? "Calificación:" : "Rating:"}</span>
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRatingInput(star)}
                          className="p-1 hover:scale-125 transition-all"
                        >
                          <Star className={`w-5 h-5 ${
                            star <= ratingInput ? 'fill-amber-400 text-amber-400' : 'text-slate-600'
                          }`} />
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Endorsement Tags Selector */}
                  <div className="space-y-2">
                    <span className="text-xs text-slate-300 font-bold block">{lang === 'es' ? "Etiquetas de Acreditación:" : "Endorsement Badges:"}</span>
                    <div className="flex flex-wrap gap-2">
                      {PRESET_ENDORSEMENTS.map((tag) => (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => toggleEndorsement(tag)}
                          className={`px-2.5 py-1 rounded-lg text-xs font-bold border transition-all ${
                            selectedEndorsements.includes(tag)
                              ? 'bg-emerald-600 border-emerald-400 text-white'
                              : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          {tag}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Review text */}
                  <div>
                    <textarea
                      required
                      rows={3}
                      value={commentInput}
                      onChange={(e) => setCommentInput(e.target.value)}
                      placeholder={lang === 'es'
                        ? "Escribe tu experiencia de trabajo, puntualidad, transparencia y manejo ecológico..."
                        : "Describe your experience working together, transparency, and ecological practices..."}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all"
                  >
                    {lang === 'es' ? "Publicar Reseña" : "Post Review"}
                  </button>
                </form>
              )}

              {/* Reviews List */}
              <div className="space-y-4">
                {userReviews.length === 0 ? (
                  <div className="p-8 text-center bg-slate-950/40 rounded-2xl border border-slate-800 text-slate-400 text-xs">
                    {lang === 'es' ? "Aún no hay reseñas registradas para este usuario. ¡Sé el primero en calificar!" : "No reviews yet. Be the first to leave a peer validation review!"}
                  </div>
                ) : (
                  userReviews.map((rev) => (
                    <div key={rev.id} className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <img
                            src={rev.authorAvatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=150&auto=format&fit=crop"}
                            alt={rev.authorName}
                            className="w-9 h-9 rounded-full object-cover border border-emerald-500/40"
                          />
                          <div>
                            <span className="text-xs font-black text-white block">{rev.authorName}</span>
                            <span className="text-[10px] text-emerald-400 font-bold uppercase">{rev.authorRole}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <div className="flex text-amber-400">
                            {[...Array(rev.rating)].map((_, i) => (
                              <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                            ))}
                          </div>
                          <span className="text-[10px] text-slate-500">{rev.date}</span>
                        </div>
                      </div>

                      <p className="text-xs text-slate-300 leading-relaxed italic">
                        "{rev.comment}"
                      </p>

                      {rev.endorsements && rev.endorsements.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {rev.endorsements.map((tag, idx) => (
                            <span key={idx} className="px-2 py-0.5 rounded-md bg-emerald-950/80 border border-emerald-500/30 text-emerald-300 text-[10px] font-bold">
                              ✓ {tag}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 4: EDITAR MI PERFIL */}
          {activeTab === 'edit' && isOwnProfile && (
            <form onSubmit={handleSaveProfile} className="space-y-5 animate-fade-in">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-xs font-black uppercase tracking-widest text-emerald-400">
                  {lang === 'es' ? "Editar Información y Fotografía del Perfil" : "Edit Profile Information & Photo"}
                </h3>
              </div>

              {/* Avatar Selector Card */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-white flex items-center gap-2">
                    <Camera className="w-4 h-4 text-emerald-400" />
                    <span>{lang === 'es' ? "Foto de Perfil del Usuario" : "User Profile Picture"}</span>
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">JPG / PNG / Base64</span>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <div className="relative w-20 h-20 rounded-2xl overflow-hidden border-2 border-emerald-500/50 bg-slate-900 shrink-0 shadow-md">
                    <img src={editAvatar} alt="Avatar Preview" className="w-full h-full object-cover" />
                  </div>

                  <div className="flex-1 space-y-2 w-full">
                    <div className="flex gap-2">
                      <input
                        type="url"
                        value={editAvatar}
                        onChange={(e) => setEditAvatar(e.target.value)}
                        placeholder="https://images.unsplash.com/..."
                        className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => document.getElementById('user-avatar-upload')?.click()}
                        className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shrink-0 flex items-center gap-1.5"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>{lang === 'es' ? "Subir Foto" : "Upload"}</span>
                      </button>
                    </div>

                    <input
                      id="user-avatar-upload"
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        if (e.target.files && e.target.files.length > 0) {
                          handleAvatarFileUpload(e.target.files[0]);
                        }
                      }}
                    />

                    {avatarUploadFileName && (
                      <p className="text-[10px] text-emerald-400 font-mono">
                        ✓ {lang === 'es' ? "Cargado archivo local:" : "Loaded local file:"} {avatarUploadFileName}
                      </p>
                    )}

                    {/* Quick Avatar Presets Grid */}
                    <div className="pt-2 border-t border-slate-800/80">
                      <span className="text-[10px] font-bold text-slate-400 block mb-1.5">
                        {lang === 'es' ? "O elige un avatar representativo:" : "Or select a representative avatar:"}
                      </span>
                      <div className="flex items-center gap-2 overflow-x-auto pb-1">
                        {PRESET_AVATARS.map((av, idx) => (
                          <img
                            key={idx}
                            src={av.url}
                            alt={av.label}
                            title={av.label}
                            onClick={() => setEditAvatar(av.url)}
                            className={`w-9 h-9 rounded-xl object-cover cursor-pointer border-2 transition-transform hover:scale-110 shrink-0 ${
                              editAvatar === av.url ? 'border-emerald-400 ring-2 ring-emerald-400/40' : 'border-slate-700 opacity-70 hover:opacity-100'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">{lang === 'es' ? "Nombre Completo / Razón Social" : "Full Name / Company"}</label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">{lang === 'es' ? "Ubicación" : "Location"}</label>
                  <input
                    type="text"
                    value={editLocation}
                    onChange={(e) => setEditLocation(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">{lang === 'es' ? "Teléfono Verificado" : "Phone"}</label>
                  <input
                    type="text"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">{lang === 'es' ? "Sitio Web / Enlace Organismo" : "Website"}</label>
                  <input
                    type="text"
                    value={editWebsite}
                    onChange={(e) => setEditWebsite(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">{lang === 'es' ? "Hectáreas o Capital Administrado" : "Hectares / Capital"}</label>
                  <input
                    type="number"
                    value={editHectares}
                    onChange={(e) => setEditHectares(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">{lang === 'es' ? "Años de Experiencia" : "Years of Experience"}</label>
                  <input
                    type="number"
                    value={editExperience}
                    onChange={(e) => setEditExperience(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1 text-xs">{lang === 'es' ? "Biografía / Descripción" : "Biography / Description"}</label>
                <textarea
                  rows={3}
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1 text-xs">{lang === 'es' ? "Certificaciones (Separadas por Comas)" : "Certifications (Comma separated)"}</label>
                <input
                  type="text"
                  value={editCertifications}
                  onChange={(e) => setEditCertifications(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                />
              </div>

              <div className="pt-3 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('info')}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold"
                >
                  {lang === 'es' ? "Cancelar" : "Cancel"}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black shadow-lg"
                >
                  {lang === 'es' ? "Guardar Cambios" : "Save Changes"}
                </button>
              </div>
            </form>
          )}

        </div>

        {/* OFFICIAL KYC / AML VERIFICATION CERTIFICATE MODAL */}
        {showCertificateModal && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-fade-in">
            <div className="relative w-full max-w-2xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 border-2 border-emerald-500/50 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
              
              <button
                onClick={() => setShowCertificateModal(false)}
                className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Certificate Official Header */}
              <div className="text-center space-y-2 border-b border-emerald-500/30 pb-5">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-black uppercase tracking-wider">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>{lang === 'es' ? "Constancia Oficial de Cumplimiento & Confianza" : "Official Compliance & Trust Certificate"}</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                  {lang === 'es' ? "DICTAMEN KYC / AML MILPATRUST" : "MILPATRUST KYC / AML AUDIT SEAL"}
                </h3>
                <p className="text-xs text-slate-400">
                  {lang === 'es' ? "Acreditación de Identidad Digital, Validación Fiscal y Prevención de Lavado de Dinero" : "Digital Identity, Tax Verification & AML Anti-Money Laundering Accreditation"}
                </p>
              </div>

              {/* Certificate Body Profile & Stamp */}
              <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-3.5">
                    <img
                      src={user.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=150&auto=format&fit=crop"}
                      alt={user.name}
                      className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-500/60 shadow-lg"
                    />
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400">{lang === 'es' ? "Titular Verificado:" : "Verified Subject:"}</span>
                      <h4 className="text-lg font-black text-white">{user.name}</h4>
                      <span className="text-xs font-mono text-emerald-400">RFC: {rfcTaxId}</span>
                    </div>
                  </div>

                  {/* Golden Shield Hologram Seal */}
                  <div className="flex flex-col items-center justify-center p-3 rounded-2xl bg-gradient-to-br from-emerald-950 to-teal-950 border border-emerald-400/50 text-center shadow-lg">
                    <ShieldCheck className="w-8 h-8 text-emerald-400" />
                    <span className="text-[10px] font-black uppercase text-emerald-300 mt-1">
                      {lang === 'es' ? "NIVEL 3 AUDITADO" : "TIER 3 AUDITED"}
                    </span>
                    <span className="text-[9px] text-slate-400 font-mono">ID #{user.id.slice(0, 8)}</span>
                  </div>
                </div>

                {/* Audit Attributes */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-3 border-t border-slate-800 text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">{lang === 'es' ? "Estatus KYC" : "KYC Status"}</span>
                    <span className="font-black text-emerald-400">✓ 100% {lang === 'es' ? "Aprobado" : "Approved"}</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">{lang === 'es' ? "Screening AML" : "AML Screening"}</span>
                    <span className="font-black text-teal-400">✓ OFAC/SAT {lang === 'es' ? "Limpio" : "Clear"}</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">{lang === 'es' ? "Vigencia" : "Validity"}</span>
                    <span className="font-black text-white">2026 - 2027</span>
                  </div>
                </div>

                {/* Cryptographic Hash */}
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">
                    {lang === 'es' ? "Hash de Firma Criptográfica (Polygon PoS DID)" : "Cryptographic Signature Hash (Polygon PoS DID)"}
                  </span>
                  <div className="font-mono text-[11px] text-emerald-400/90 break-all">
                    {didHash}
                  </div>
                </div>
              </div>

              {/* QR and Trust Note */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-slate-900 rounded-xl border border-emerald-500/40 text-emerald-400">
                    <QrCode className="w-8 h-8" />
                  </div>
                  <div>
                    <span className="text-xs font-black text-white block">{lang === 'es' ? "Validación Instantánea por Código QR" : "Instant QR Validation"}</span>
                    <span className="text-[11px] text-slate-300">{lang === 'es' ? "Escanee para validar la autenticidad en tiempo real en la blockchain." : "Scan to verify real-time cryptographic validity."}</span>
                  </div>
                </div>

                <button
                  onClick={() => window.print()}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-black flex items-center gap-2 transition-all shrink-0"
                >
                  <FileText className="w-4 h-4 text-emerald-400" />
                  <span>{lang === 'es' ? "Imprimir / Guardar" : "Print / Save"}</span>
                </button>
              </div>

              <div className="text-center pt-2">
                <button
                  onClick={() => setShowCertificateModal(false)}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl shadow-lg transition-all uppercase tracking-wider"
                >
                  {lang === 'es' ? "Cerrar Dictamen" : "Close Certificate"}
                </button>
              </div>

            </div>
          </div>
        )}

        {/* DEDICATED AVATAR PICKER POPUP MODAL */}
        {showAvatarPickerModal && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
            <div className="relative w-full max-w-lg bg-slate-900 border-2 border-emerald-500/50 rounded-3xl p-6 shadow-2xl space-y-5 text-left">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                    <Camera className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-white">
                      {lang === 'es' ? "Cambiar Foto de Perfil" : "Change Profile Picture"}
                    </h3>
                    <p className="text-xs text-slate-400">{user.name}</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setShowAvatarPickerModal(false)}
                  className="p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Avatar Live Preview */}
              <div className="flex items-center gap-4 p-3.5 bg-slate-950 rounded-2xl border border-slate-800">
                <img
                  src={editAvatar}
                  alt="Avatar Preview"
                  className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-400 bg-slate-800 shrink-0"
                />
                <div className="flex-1 space-y-1">
                  <span className="text-xs font-bold text-white block">
                    {lang === 'es' ? "Vista Previa del Avatar" : "Avatar Live Preview"}
                  </span>
                  <p className="text-[10px] text-slate-400 font-mono truncate">
                    {editAvatar.startsWith('data:') ? 'archivo_cargado_local.png' : editAvatar}
                  </p>
                </div>
              </div>

              {/* Upload or URL input */}
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1.5">
                    {lang === 'es' ? "1. Subir archivo de imagen desde tu equipo:" : "1. Upload image file from your device:"}
                  </label>
                  <button
                    type="button"
                    onClick={() => document.getElementById('popup-avatar-upload')?.click()}
                    className="w-full py-3 px-4 bg-slate-950 border-2 border-dashed border-slate-700 hover:border-emerald-400 rounded-2xl text-xs font-bold text-slate-200 hover:bg-slate-800/60 transition-all flex items-center justify-center gap-2"
                  >
                    <Upload className="w-4 h-4 text-emerald-400" />
                    <span>{lang === 'es' ? "Seleccionar Fotografía Local (JPG, PNG)" : "Choose Local Photograph (JPG, PNG)"}</span>
                  </button>
                  <input
                    id="popup-avatar-upload"
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files.length > 0) {
                        handleAvatarFileUpload(e.target.files[0]);
                      }
                    }}
                  />
                  {avatarUploadFileName && (
                    <p className="text-[10px] text-emerald-400 font-mono mt-1">
                      ✓ {lang === 'es' ? "Archivo cargado:" : "Loaded file:"} {avatarUploadFileName}
                    </p>
                  )}
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    {lang === 'es' ? "2. O pega una URL directa:" : "2. Or paste a direct image URL:"}
                  </label>
                  <input
                    type="url"
                    value={editAvatar}
                    onChange={(e) => setEditAvatar(e.target.value)}
                    placeholder="https://images.unsplash.com/..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white font-mono focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1.5">
                    {lang === 'es' ? "3. O selecciona un avatar de la galería:" : "3. Or choose a preset avatar:"}
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {PRESET_AVATARS.map((av, idx) => (
                      <div
                        key={idx}
                        onClick={() => setEditAvatar(av.url)}
                        className={`p-1 rounded-xl border-2 cursor-pointer transition-all flex flex-col items-center gap-1 ${
                          editAvatar === av.url
                            ? 'border-emerald-400 bg-emerald-950/60 ring-2 ring-emerald-400/30'
                            : 'border-slate-800 bg-slate-950 hover:border-slate-700'
                        }`}
                      >
                        <img src={av.url} alt={av.label} className="w-10 h-10 rounded-lg object-cover" />
                        <span className="text-[9px] text-slate-300 font-bold truncate max-w-[70px] text-center leading-tight">
                          {av.label.split(' ')[0]}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAvatarPickerModal(false)}
                  className="flex-1 py-2.5 border border-slate-700 text-slate-300 hover:bg-slate-800 rounded-xl text-xs font-bold transition-colors"
                >
                  {lang === 'es' ? "Cancelar" : "Cancel"}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const updated: UserProfile = {
                      ...user,
                      avatar: editAvatar
                    };
                    if (onUpdateProfile) {
                      onUpdateProfile(updated);
                    }
                    setShowAvatarPickerModal(false);
                  }}
                  className="flex-1 py-2.5 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white rounded-xl text-xs font-black shadow-lg transition-all flex items-center justify-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>{lang === 'es' ? "Guardar Foto" : "Save Photo"}</span>
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
