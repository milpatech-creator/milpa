import React, { useState, useEffect } from 'react';
import {
  CreditCard, ShieldCheck, Lock, CheckCircle2, AlertCircle, Info,
  Sparkles, Check, ChevronRight, RefreshCw, Layers, Shield
} from 'lucide-react';
import { CardDetails, SavedCard, Language } from '../types';

interface CardPaymentFormProps {
  amountMxn: number;
  itemName: string;
  itemCategory?: string;
  lang: Language;
  onPaymentSuccess: (details: {
    cardBrand: 'VISA' | 'MASTERCARD' | 'AMEX';
    cardType: 'CREDIT' | 'DEBIT';
    last4: string;
    cardholder: string;
    authCode: string;
    installments: number;
  }) => void;
  onCancel?: () => void;
  isProcessing?: boolean;
}

// Brand detector helper
export const detectCardBrand = (number: string): 'VISA' | 'MASTERCARD' | 'AMEX' | 'UNKNOWN' => {
  const clean = number.replace(/\D/g, '');
  if (/^4/.test(clean)) return 'VISA';
  if (/^(5[1-5]|2[2-7])/.test(clean)) return 'MASTERCARD';
  if (/^3[47]/.test(clean)) return 'AMEX';
  return 'UNKNOWN';
};

export const CardPaymentForm: React.FC<CardPaymentFormProps> = ({
  amountMxn,
  itemName,
  itemCategory,
  lang,
  onPaymentSuccess,
  onCancel,
  isProcessing: externalProcessing = false
}) => {
  const isEs = lang === 'es';

  // Form states
  const [cardNumber, setCardNumber] = useState('');
  const [cardholderName, setCardholderName] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [cardType, setCardType] = useState<'CREDIT' | 'DEBIT'>('CREDIT');
  const [installments, setInstallments] = useState<number>(1);
  const [saveCard, setSaveCard] = useState<boolean>(true);
  const [selectedSavedCardId, setSelectedSavedCardId] = useState<string | null>(null);

  // Security 3D Secure / OTP Simulation step
  const [show3DSModal, setShow3DSModal] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [isLocalProcessing, setIsLocalProcessing] = useState(false);

  // Mock initial saved cards
  const [savedCards, setSavedCards] = useState<SavedCard[]>(() => {
    const saved = localStorage.getItem('milpa_saved_cards');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return [
      {
        id: 'card-1',
        last4: '4242',
        brand: 'VISA',
        cardholder: 'SOBOL ENNIS',
        expiry: '08/28',
        cardType: 'CREDIT'
      },
      {
        id: 'card-2',
        last4: '8891',
        brand: 'MASTERCARD',
        cardholder: 'SOBOL ENNIS',
        expiry: '11/27',
        cardType: 'DEBIT'
      },
      {
        id: 'card-3',
        last4: '3005',
        brand: 'AMEX',
        cardholder: 'SOBOL ENNIS',
        expiry: '05/29',
        cardType: 'CREDIT'
      }
    ];
  });

  const cardBrand = selectedSavedCardId
    ? savedCards.find(c => c.id === selectedSavedCardId)?.brand || 'VISA'
    : detectCardBrand(cardNumber);

  // Auto-format card number
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedSavedCardId(null);
    const raw = e.target.value.replace(/\D/g, '');
    const brand = detectCardBrand(raw);

    let formatted = '';
    if (brand === 'AMEX') {
      // 4 - 6 - 5 format for Amex (15 digits max)
      const limited = raw.slice(0, 15);
      if (limited.length <= 4) {
        formatted = limited;
      } else if (limited.length <= 10) {
        formatted = `${limited.slice(0, 4)} ${limited.slice(4)}`;
      } else {
        formatted = `${limited.slice(0, 4)} ${limited.slice(4, 10)} ${limited.slice(10)}`;
      }
    } else {
      // 4 - 4 - 4 - 4 format (16 digits max)
      const limited = raw.slice(0, 16);
      const parts = [];
      for (let i = 0; i < limited.length; i += 4) {
        parts.push(limited.slice(i, i + 4));
      }
      formatted = parts.join(' ');
    }

    setCardNumber(formatted);
  };

  // Auto-format expiry date MM/YY
  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let raw = e.target.value.replace(/\D/g, '').slice(0, 4);
    if (raw.length >= 3) {
      raw = `${raw.slice(0, 2)}/${raw.slice(2)}`;
    }
    setExpiryDate(raw);
  };

  // Select a saved card
  const handleSelectSavedCard = (card: SavedCard) => {
    setSelectedSavedCardId(card.id);
    setCardNumber(`•••• •••• •••• ${card.last4}`);
    setCardholderName(card.cardholder);
    setExpiryDate(card.expiry);
    setCvv('•••');
    setCardType(card.cardType);
  };

  // Submit payment
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedSavedCardId && cardNumber.replace(/\D/g, '').length < 15) {
      alert(isEs ? "Por favor ingresa un número de tarjeta válido (15 o 16 dígitos)." : "Please enter a valid card number.");
      return;
    }

    // Trigger 3D Secure / SafeKey check for cards
    setShow3DSModal(true);
    setOtpCode('749210'); // Simulated SMS OTP
  };

  // Verify OTP and complete
  const handleConfirm3DS = () => {
    setIsVerifyingOtp(true);
    setTimeout(() => {
      setIsVerifyingOtp(false);
      setShow3DSModal(false);
      setIsLocalProcessing(true);

      const cleanNum = cardNumber.replace(/\D/g, '');
      const last4 = selectedSavedCardId
        ? savedCards.find(c => c.id === selectedSavedCardId)?.last4 || '4242'
        : (cleanNum.slice(-4) || '8841');

      const brand = cardBrand === 'UNKNOWN' ? 'VISA' : cardBrand;
      const authCode = "AUTH-" + Math.floor(100000 + Math.random() * 900000);

      // Save card if checked
      if (saveCard && !selectedSavedCardId && cleanNum.length >= 15) {
        const newSaved: SavedCard = {
          id: `card-${Date.now()}`,
          last4,
          brand,
          cardholder: cardholderName.toUpperCase() || 'USUARIO MILPATECH',
          expiry: expiryDate || '12/28',
          cardType
        };
        const updatedCards = [newSaved, ...savedCards];
        setSavedCards(updatedCards);
        localStorage.setItem('milpa_saved_cards', JSON.stringify(updatedCards));
      }

      setTimeout(() => {
        setIsLocalProcessing(false);
        onPaymentSuccess({
          cardBrand: brand,
          cardType,
          last4,
          cardholder: cardholderName.toUpperCase() || 'CLIENTE VERIFICADO',
          authCode,
          installments: cardType === 'CREDIT' ? installments : 1
        });
      }, 900);
    }, 1200);
  };

  const isProcessing = externalProcessing || isLocalProcessing;

  // Monthly calculation for MSI
  const monthlyAmount = installments > 1 ? Math.round(amountMxn / installments) : amountMxn;

  return (
    <div className="space-y-6" id="card-payment-engine">
      
      {/* 1. Quick Saved Cards Carousel */}
      {savedCards.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isEs ? "Tarjetas Guardadas en Token Seguro" : "Saved Tokenized Cards"}</span>
            </span>
            <button
              type="button"
              onClick={() => {
                setSelectedSavedCardId(null);
                setCardNumber('');
                setCardholderName('');
                setExpiryDate('');
                setCvv('');
              }}
              className="text-[11px] text-emerald-700 font-bold hover:underline"
            >
              {isEs ? "+ Usar Nueva Tarjeta" : "+ Use New Card"}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {savedCards.map((card) => {
              const isSelected = selectedSavedCardId === card.id;
              return (
                <button
                  type="button"
                  key={card.id}
                  onClick={() => handleSelectSavedCard(card)}
                  className={`p-3 rounded-2xl border text-left transition-all relative overflow-hidden ${
                    isSelected
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-md ring-2 ring-emerald-500/20'
                      : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/80'
                  }`}
                >
                  {isSelected && (
                    <div className="absolute top-2 right-2 w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                      <Check className="w-3 h-3" />
                    </div>
                  )}

                  <div className="flex items-center gap-2 mb-1.5">
                    {/* Brand Logo Mini */}
                    {card.brand === 'VISA' && (
                      <span className="font-black text-blue-700 italic tracking-tighter text-xs">VISA</span>
                    )}
                    {card.brand === 'MASTERCARD' && (
                      <div className="flex items-center -space-x-1">
                        <div className="w-3.5 h-3.5 rounded-full bg-red-500 opacity-90" />
                        <div className="w-3.5 h-3.5 rounded-full bg-amber-500 opacity-90" />
                      </div>
                    )}
                    {card.brand === 'AMEX' && (
                      <span className="font-black text-cyan-700 text-[10px] tracking-tight bg-cyan-50 px-1 rounded border border-cyan-200">
                        AMEX
                      </span>
                    )}
                    <span className="text-[10px] font-bold text-slate-500 uppercase">
                      {card.cardType === 'DEBIT' ? (isEs ? 'Débito' : 'Debit') : (isEs ? 'Crédito' : 'Credit')}
                    </span>
                  </div>

                  <p className="font-mono text-xs font-bold text-slate-800 tracking-wider">
                    •••• {card.last4}
                  </p>
                  <p className="text-[10px] text-slate-400 font-medium truncate mt-0.5">
                    {card.cardholder} · {card.expiry}
                  </p>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. Interactive Realistic Card Preview */}
      <div className="relative">
        <div
          className={`w-full h-48 rounded-3xl p-5 text-white shadow-2xl relative overflow-hidden transition-all duration-500 flex flex-col justify-between ${
            cardBrand === 'VISA'
              ? 'bg-gradient-to-tr from-blue-900 via-indigo-900 to-slate-900 border border-blue-500/30'
              : cardBrand === 'MASTERCARD'
              ? 'bg-gradient-to-tr from-red-950 via-slate-900 to-amber-950 border border-red-500/30'
              : cardBrand === 'AMEX'
              ? 'bg-gradient-to-tr from-cyan-950 via-slate-900 to-blue-950 border border-cyan-500/30'
              : 'bg-gradient-to-tr from-slate-900 via-emerald-950 to-slate-900 border border-emerald-500/30'
          }`}
        >
          {/* Card Geometric Watermark & Glow */}
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-56 h-56 rounded-full bg-white/5 blur-2xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-56 h-56 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none" />

          {/* Top Bar: Chip & Card Type & Brand Logo */}
          <div className="flex items-center justify-between z-10">
            <div className="flex items-center gap-3">
              {/* Gold Chip */}
              <div className="w-10 h-7 rounded-lg bg-gradient-to-br from-amber-200 via-yellow-400 to-amber-600 p-0.5 shadow-inner border border-amber-300 flex items-center justify-center">
                <div className="w-full h-full border border-amber-800/20 rounded grid grid-cols-2 gap-0.5 opacity-60" />
              </div>
              {/* Contactless symbol */}
              <svg className="w-5 h-5 text-slate-300 opacity-70" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M8.5 16.5a5 5 0 0 1 0-9" />
                <path d="M12 19a8.5 8.5 0 0 0 0-14" />
                <path d="M15.5 21.5a12 12 0 0 0 0-19" />
              </svg>
            </div>

            {/* Brand Logo Dynamic */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-300 px-2 py-0.5 rounded-full bg-white/10 backdrop-blur-sm">
                {cardType === 'DEBIT' ? (isEs ? 'DÉBITO' : 'DEBIT') : (isEs ? 'CRÉDITO' : 'CREDIT')}
              </span>

              {cardBrand === 'VISA' && (
                <div className="bg-white/95 px-3 py-1 rounded-lg">
                  <span className="font-black text-blue-800 italic tracking-tighter text-base">VISA</span>
                </div>
              )}
              {cardBrand === 'MASTERCARD' && (
                <div className="flex items-center -space-x-2 bg-slate-950/60 p-1.5 rounded-lg backdrop-blur-sm">
                  <div className="w-6 h-6 rounded-full bg-red-600 opacity-90 shadow-md" />
                  <div className="w-6 h-6 rounded-full bg-amber-500 opacity-90 shadow-md" />
                </div>
              )}
              {cardBrand === 'AMEX' && (
                <div className="bg-cyan-500/20 border border-cyan-400/50 px-2.5 py-1 rounded-lg">
                  <span className="font-black text-cyan-300 tracking-tighter text-xs">AMERICAN EXPRESS</span>
                </div>
              )}
              {cardBrand === 'UNKNOWN' && (
                <div className="flex items-center gap-1.5 text-slate-400 text-xs font-bold bg-white/10 px-2.5 py-1 rounded-lg">
                  <CreditCard className="w-4 h-4" />
                  <span>VISA / MC / AMEX</span>
                </div>
              )}
            </div>
          </div>

          {/* Card Number Display */}
          <div className="z-10 my-auto">
            <p className="text-[10px] uppercase font-mono tracking-widest text-slate-400">Card Number</p>
            <p className="font-mono text-xl sm:text-2xl font-black tracking-widest text-white drop-shadow-md">
              {cardNumber || '•••• •••• •••• ••••'}
            </p>
          </div>

          {/* Bottom Row: Cardholder & Expiration */}
          <div className="flex items-center justify-between z-10 pt-1 text-slate-300">
            <div>
              <p className="text-[9px] uppercase font-mono tracking-widest text-slate-400">Cardholder</p>
              <p className="font-mono text-xs sm:text-sm font-extrabold uppercase text-white tracking-wider truncate max-w-[190px]">
                {cardholderName || (isEs ? 'NOMBRE TITULAR' : 'CARDHOLDER NAME')}
              </p>
            </div>

            <div className="text-right">
              <p className="text-[9px] uppercase font-mono tracking-widest text-slate-400">Expires</p>
              <p className="font-mono text-xs sm:text-sm font-extrabold text-white tracking-wider">
                {expiryDate || 'MM/YY'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Card Details Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        
        {/* Card Type Selector (Credit / Debit) */}
        <div className="flex bg-slate-100 p-1 rounded-2xl">
          <button
            type="button"
            onClick={() => setCardType('CREDIT')}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              cardType === 'CREDIT'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5 text-indigo-600" />
            <span>{isEs ? "Tarjeta de Crédito" : "Credit Card"}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setCardType('DEBIT');
              setInstallments(1);
            }}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              cardType === 'DEBIT'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>{isEs ? "Tarjeta de Débito" : "Debit Card"}</span>
          </button>
        </div>

        {/* Card Number Input */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            {isEs ? "Número de Tarjeta (VISA, Mastercard o AMEX)" : "Card Number (VISA, Mastercard or AMEX)"}
          </label>
          <div className="relative">
            <input
              type="text"
              required
              placeholder={cardBrand === 'AMEX' ? "3782 822463 10005" : "4532 8920 4819 4242"}
              value={cardNumber}
              onChange={handleCardNumberChange}
              className="w-full pl-11 pr-24 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-mono font-bold text-slate-800 placeholder-slate-400 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
            />
            <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
              <CreditCard className="w-5 h-5" />
            </div>

            {/* Brand icon inside input */}
            <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
              {cardBrand === 'VISA' && (
                <span className="font-black text-blue-700 italic tracking-tighter text-sm bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                  VISA
                </span>
              )}
              {cardBrand === 'MASTERCARD' && (
                <span className="font-bold text-red-600 text-xs bg-red-50 px-2 py-0.5 rounded border border-red-200">
                  Mastercard
                </span>
              )}
              {cardBrand === 'AMEX' && (
                <span className="font-black text-cyan-700 text-xs bg-cyan-50 px-2 py-0.5 rounded border border-cyan-200">
                  AMEX
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Cardholder Name */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            {isEs ? "Nombre del Titular (Como aparece en la tarjeta)" : "Cardholder Full Name"}
          </label>
          <input
            type="text"
            required
            placeholder="SOBOL ENNIS"
            value={cardholderName}
            onChange={(e) => setCardholderName(e.target.value.toUpperCase())}
            className="w-full px-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
          />
        </div>

        {/* Expiry & CVV & Zip Row */}
        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              {isEs ? "Vencimiento" : "Expiry"}
            </label>
            <input
              type="text"
              required
              placeholder="MM/YY"
              maxLength={5}
              value={expiryDate}
              onChange={handleExpiryChange}
              className="w-full px-3 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-mono font-bold text-center text-slate-800 placeholder-slate-400 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                CVV / CVC
              </label>
              <span className="text-[9px] text-slate-400">{cardBrand === 'AMEX' ? '4 dig' : '3 dig'}</span>
            </div>
            <input
              type="password"
              required
              maxLength={cardBrand === 'AMEX' ? 4 : 3}
              placeholder={cardBrand === 'AMEX' ? "••••" : "•••"}
              value={cvv}
              onChange={(e) => setCvv(e.target.value.replace(/\D/g, ''))}
              className="w-full px-3 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-mono font-bold text-center text-slate-800 placeholder-slate-400 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              {isEs ? "C.P. / Postal" : "Zip Code"}
            </label>
            <input
              type="text"
              placeholder="68000"
              maxLength={6}
              value={postalCode}
              onChange={(e) => setPostalCode(e.target.value)}
              className="w-full px-3 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-mono font-bold text-center text-slate-800 placeholder-slate-400 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
            />
          </div>
        </div>

        {/* Meses Sin Intereses (Only for Credit Cards and amount > $1,000 MXN) */}
        {cardType === 'CREDIT' && amountMxn >= 500 && (
          <div className="bg-slate-50 border border-slate-200/80 p-3.5 rounded-2xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>{isEs ? "Plan de Meses Sin Intereses (MSI):" : "Installment Plan (0% Interest):"}</span>
              </span>
              <span className="text-[10px] font-bold bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full">
                {isEs ? "0% Comisión Financiera" : "0% APR Promotion"}
              </span>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {[1, 3, 6, 12].map((num) => {
                const isSelected = installments === num;
                const monthly = Math.round(amountMxn / num);
                return (
                  <button
                    type="button"
                    key={num}
                    onClick={() => setInstallments(num)}
                    className={`py-2 px-1.5 rounded-xl border text-center transition-all ${
                      isSelected
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm font-bold'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300 font-semibold text-xs'
                    }`}
                  >
                    <div className="text-xs">{num === 1 ? (isEs ? '1 Pago' : '1 Payment') : `${num} MSI`}</div>
                    <div className={`text-[10px] font-mono mt-0.5 ${isSelected ? 'text-emerald-100' : 'text-slate-500'}`}>
                      ${monthly.toLocaleString()}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Save Card Checkbox */}
        <label className="flex items-center gap-2.5 cursor-pointer text-xs text-slate-600 select-none pt-1">
          <input
            type="checkbox"
            checked={saveCard}
            onChange={(e) => setSaveCard(e.target.checked)}
            className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300"
          />
          <span>
            {isEs
              ? "Guardar tarjeta de forma segura para compras futuras (Tokenización PCI-DSS Nivel 1)"
              : "Save card securely for future transactions (PCI-DSS Level 1 Tokenization)"}
          </span>
        </label>

        {/* Breakdown & Submit Button */}
        <div className="bg-slate-900 text-white p-5 rounded-3xl space-y-3 mt-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>{isEs ? "Concepto:" : "Item:"}</span>
            <span className="font-semibold text-white truncate max-w-[200px]">{itemName}</span>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>{isEs ? "Comisión de Procesamiento Card:" : "Processing Fee:"}</span>
            <span className="text-emerald-400 font-bold">{isEs ? "GRATIS ($0 MXN)" : "FREE ($0 MXN)"}</span>
          </div>

          {installments > 1 && (
            <div className="flex items-center justify-between text-xs text-amber-300 bg-amber-950/40 px-3 py-1.5 rounded-xl border border-amber-500/20">
              <span>{installments} {isEs ? "pagos mensuales de:" : "monthly payments of:"}</span>
              <span className="font-mono font-bold">${monthlyAmount.toLocaleString()} MXN</span>
            </div>
          )}

          <div className="flex items-center justify-between pt-3 border-t border-slate-800">
            <div>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                {isEs ? "Total a Pagar:" : "Total Amount:"}
              </span>
              <span className="text-2xl font-black font-mono text-emerald-400">
                ${amountMxn.toLocaleString()} MXN
              </span>
            </div>

            <button
              type="submit"
              disabled={isProcessing}
              className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black px-6 py-3 rounded-2xl text-sm flex items-center gap-2 shadow-lg shadow-emerald-500/20 transition-all cursor-pointer disabled:opacity-50 active:scale-98"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{isEs ? "Procesando Tarjeta..." : "Processing Card..."}</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>
                    {isEs
                      ? `Pagar $${amountMxn.toLocaleString()} MXN`
                      : `Pay $${amountMxn.toLocaleString()} MXN`}
                  </span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Trust Badges & Compliance Footer */}
        <div className="flex flex-wrap items-center justify-center gap-4 pt-2 text-[10px] text-slate-500">
          <span className="flex items-center gap-1">
            <Lock className="w-3 h-3 text-emerald-600" />
            <span>256-Bit SSL Encryption</span>
          </span>
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-blue-600" />
            <span>Visa Secure</span>
          </span>
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-amber-600" />
            <span>Mastercard Identity Check</span>
          </span>
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-cyan-600" />
            <span>Amex SafeKey</span>
          </span>
        </div>
      </form>

      {/* 4. 3D Secure / Anti-Fraud OTP Verification Modal Simulation */}
      {show3DSModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 text-center shadow-2xl border border-slate-200 animate-scale-up space-y-4">
            
            {/* Bank / Card Network Header */}
            <div className="flex items-center justify-center gap-2">
              {cardBrand === 'VISA' && <span className="font-black text-blue-800 italic text-xl">VISA</span>}
              {cardBrand === 'MASTERCARD' && (
                <div className="flex items-center -space-x-1">
                  <div className="w-5 h-5 rounded-full bg-red-600" />
                  <div className="w-5 h-5 rounded-full bg-amber-500" />
                </div>
              )}
              {cardBrand === 'AMEX' && <span className="font-black text-cyan-700 text-sm">AMERICAN EXPRESS</span>}
              <span className="text-slate-300">|</span>
              <span className="text-xs font-bold text-slate-700 flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>3D Secure 2.0</span>
              </span>
            </div>

            <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-xs text-slate-600 leading-relaxed">
              <p className="font-bold text-slate-800 mb-1">
                {isEs ? "Verificación de Seguridad Bancaria" : "Bank Security Verification"}
              </p>
              <p>
                {isEs
                  ? `Se ha enviado un código de seguridad de 6 dígitos a tu teléfono registrado para autorizar el cargo de $${amountMxn.toLocaleString()} MXN en ${itemName}.`
                  : `A 6-digit security code was sent to your registered phone to authorize $${amountMxn.toLocaleString()} MXN.`}
              </p>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                {isEs ? "Código OTP de Autorización" : "OTP Authorization Code"}
              </label>
              <input
                type="text"
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value)}
                className="w-full text-center font-mono text-2xl font-black tracking-widest py-3 bg-slate-100 border border-slate-300 rounded-2xl focus:outline-none focus:border-emerald-500 focus:bg-white text-slate-900"
                maxLength={6}
              />
              <p className="text-[10px] text-slate-400 mt-1.5">
                {isEs ? "Código autocompletado en entorno seguro de prueba" : "Code auto-filled in secure sandbox"}
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShow3DSModal(false)}
                className="flex-1 py-3 border border-slate-200 text-slate-700 rounded-xl font-bold text-xs hover:bg-slate-50 transition-colors"
              >
                {isEs ? "Cancelar" : "Cancel"}
              </button>
              <button
                type="button"
                onClick={handleConfirm3DS}
                disabled={isVerifyingOtp}
                className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20"
              >
                {isVerifyingOtp ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>{isEs ? "Autorizando..." : "Authorizing..."}</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{isEs ? "Confirmar Pago" : "Confirm Payment"}</span>
                  </>
                )}
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
