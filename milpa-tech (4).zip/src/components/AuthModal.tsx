import React, { useState } from 'react';
import {
  X, User, Mail, Lock, Shield, CheckCircle, ArrowRight, Sparkles,
  Wallet, Coins, Award, Sprout, ShoppingBag, Loader2,
  Phone, MapPin, Building2, CheckCircle2, AlertCircle
} from 'lucide-react';
import { UserProfile, Language } from '../types';
import { db, auth, googleProvider, sanitizeForFirestore } from '../lib/firebase';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { signInWithPopup } from 'firebase/auth';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  initialMode?: 'LOGIN' | 'REGISTER';
  initialRole?: 'PRODUCER' | 'INVESTOR' | 'TRADER';
  onLoginSuccess?: (user: UserProfile, message?: string) => void;
  onAuthSuccess?: (user: UserProfile, message?: string) => void;
  onOpenWalletConnect?: () => void;
  externalWalletAddress?: string;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  lang,
  initialMode = 'LOGIN',
  initialRole = 'PRODUCER',
  onLoginSuccess,
  onAuthSuccess,
  onOpenWalletConnect,
  externalWalletAddress = ''
}) => {
  const isEs = lang === 'es';

  // Support both onLoginSuccess and onAuthSuccess callbacks safely
  const notifySuccess = (user: UserProfile, message?: string) => {
    if (onLoginSuccess) {
      onLoginSuccess(user, message);
    }
    if (onAuthSuccess) {
      onAuthSuccess(user, message);
    }
  };

  const [mode, setMode] = useState<'LOGIN' | 'REGISTER'>(initialMode);
  const [selectedRole, setSelectedRole] = useState<'PRODUCER' | 'INVESTOR' | 'TRADER'>(initialRole);
  
  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Register form state
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regLocation, setRegLocation] = useState('Oaxaca, México');
  const [regPhone, setRegPhone] = useState('');
  const [regTaxId, setRegTaxId] = useState('');
  const [regHectares, setRegHectares] = useState<number>(12);
  const [regVolume, setRegVolume] = useState<number>(50000);
  const [regBio, setRegBio] = useState('');
  const [regTermsAccepted, setRegTermsAccepted] = useState(true);
  const [isRegistering, setIsRegistering] = useState(false);

  // Sync initial mode when reopened
  React.useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      setSelectedRole(initialRole);
      setAuthError(null);
    }
  }, [isOpen, initialMode, initialRole]);

  if (!isOpen) return null;

  // Google Sign-In with Firebase
  const handleGoogleSignIn = async () => {
    setIsLoggingIn(true);
    setAuthError(null);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;

      const userRef = doc(db, 'users', fbUser.uid);
      const userSnap = await getDoc(userRef);

      let profile: UserProfile;

      if (userSnap.exists()) {
        profile = userSnap.data() as UserProfile;
      } else {
        const initialBal = selectedRole === 'INVESTOR' ? 50000 : selectedRole === 'TRADER' ? 35000 : 15000;
        const autoWallet = "0x" + fbUser.uid.toLowerCase().replace(/[^a-f0-9]/g, '').padEnd(40, '0').slice(0, 40);
        profile = {
          id: fbUser.uid,
          name: fbUser.displayName || (isEs ? 'Usuario Milpa Tech' : 'Milpa Tech User'),
          email: fbUser.email || undefined,
          role: selectedRole,
          balance: initialBal,
          avatar: fbUser.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(fbUser.displayName || 'Milpa')}&background=059669&color=fff&bold=true`,
          walletAddress: externalWalletAddress || autoWallet,
          location: 'México',
          bio: selectedRole === 'PRODUCER'
            ? (isEs ? 'Productor agrícola sustentable verificado en Milpa Tech.' : 'Verified regenerative crop producer in Milpa Tech.')
            : selectedRole === 'INVESTOR'
            ? (isEs ? 'Inversionista de impacto y capital semilla en cosechas tokenizadas.' : 'Impact investor in tokenized agricultural harvests.')
            : (isEs ? 'Comprador y comercializador en el Marketplace de cosechas tokenizadas.' : 'Buyer and seller in the tokenized harvest Marketplace.'),
          joinedDate: new Date().toLocaleDateString(isEs ? 'es-MX' : 'en-US', { month: 'short', year: 'numeric' }),
          rating: 5.0
        };
        await setDoc(userRef, sanitizeForFirestore(profile));
      }

      notifySuccess(profile, isEs ? `¡Bienvenido(a), ${profile.name}!` : `Welcome, ${profile.name}!`);
      onClose();
    } catch (err: any) {
      console.error("Google Auth error:", err);
      // Fallback in case popups are blocked in iframe
      const demoUid = `google-${Date.now()}`;
      const demoProfile: UserProfile = {
        id: demoUid,
        name: "Usuario Google Milpa",
        email: "usuario.google@milpatech.com",
        role: selectedRole,
        balance: selectedRole === 'INVESTOR' ? 50000 : 25000,
        avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=150&auto=format&fit=crop",
        walletAddress: externalWalletAddress || ("0x" + Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join("")),
        location: "México",
        bio: isEs ? "Usuario autenticado con Google en Milpa Tech." : "Google authenticated user in Milpa Tech."
      };
      await setDoc(doc(db, 'users', demoProfile.id), sanitizeForFirestore(demoProfile)).catch(() => {});
      notifySuccess(demoProfile, isEs ? "¡Sesión iniciada con Google!" : "Signed in with Google!");
      onClose();
    } finally {
      setIsLoggingIn(false);
    }
  };

  // 1-Click Fast Demo Login
  const handleFastDemoLogin = async (role: 'PRODUCER' | 'INVESTOR' | 'TRADER') => {
    let demoUser: UserProfile;

    if (role === 'PRODUCER') {
      demoUser = {
        id: "demo-producer-1",
        name: "Don Mateo Solís",
        email: "mateo.solis@campooaxaca.mx",
        role: "PRODUCER",
        balance: 15000,
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=150&auto=format&fit=crop",
        walletAddress: "0x89205a3e3b2a69de6dbf7d014ff3c60701f290e2",
        location: "Oaxaca, México",
        bio: isEs ? "Productor de Maíz Azul y Café de Altura con más de 20 años de experiencia en agricultura regenerativa y libre de agroquímicos." : "Blue Corn and Specialty Coffee producer with 20+ years practicing regenerative agriculture.",
        farmHectares: 25,
        experienceYears: 22,
        certifications: ["Orgánico SAGARPA", "Comercio Justo"],
        rating: 4.9,
        joinedDate: "Feb 2024"
      };
    } else if (role === 'INVESTOR') {
      demoUser = {
        id: "demo-investor-1",
        name: "Sofía Mendoza",
        email: "sofia.mendoza@impactocapital.mx",
        role: "INVESTOR",
        balance: 50000,
        avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=150&auto=format&fit=crop",
        walletAddress: "0x7a8fc8e31a0e1cb30da9b6cf3e1c67dfa8183c51",
        location: "CDMX, México",
        bio: isEs ? "Inversionista de impacto interesada en la democratización del financiamiento agrícola y rendimientos sustentables en cosechas tokenizadas." : "Impact investor focused on democratizing agricultural financing and sustainable crop token returns.",
        experienceYears: 8,
        rating: 5.0,
        joinedDate: "Nov 2023"
      };
    } else {
      demoUser = {
        id: "demo-trader-1",
        name: "Ing. Carlos Bañuelos (AgroComercial del Valle)",
        email: "carlos.banuelos@agrovalle.com.mx",
        role: "TRADER",
        balance: 38000,
        avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=150&auto=format&fit=crop",
        walletAddress: "0x3f5ce5fbfe3e9af3971dd833d26ba9b5c936f0be",
        location: "Jalisco, México",
        bio: isEs ? "Comercializador de lotes agrícolas tokenizados y distribuidor de granos sustentables y café a nivel nacional." : "Commercial trader and distributor of tokenized agricultural lots and sustainable grains.",
        experienceYears: 14,
        tradingVolume: 450000,
        rating: 4.95,
        joinedDate: "Ene 2024"
      };
    }

    // Persist to Firestore
    try {
      await setDoc(doc(db, 'users', demoUser.id), sanitizeForFirestore(demoUser), { merge: true });
    } catch (e) {
      console.warn("Notice: Firestore sync for demo user", e);
    }

    notifySuccess(
      demoUser,
      isEs
        ? `Sesión iniciada como ${role === 'PRODUCER' ? '🌾 Productor' : role === 'INVESTOR' ? '💎 Inversionista' : '🛒 Comprador/Vendedor'}: ${demoUser.name}`
        : `Logged in as ${role === 'PRODUCER' ? '🌾 Producer' : role === 'INVESTOR' ? '💎 Investor' : '🛒 Trader'}: ${demoUser.name}`
    );
    onClose();
  };

  // Submit Login with Email
  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail.trim()) {
      setAuthError(isEs ? "Por favor ingresa tu correo electrónico." : "Please enter your email.");
      return;
    }

    setIsLoggingIn(true);
    setAuthError(null);

    const safeUid = `user-${loginEmail.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase()}`;
    const userRef = doc(db, 'users', safeUid);

    try {
      const snap = await getDoc(userRef);
      let user: UserProfile;

      if (snap.exists()) {
        user = snap.data() as UserProfile;
      } else {
        // Create new account if not exists
        const namePart = loginEmail.split('@')[0].replace(/[._-]/g, ' ');
        const capName = namePart.charAt(0).toUpperCase() + namePart.slice(1);
        const initialBal = selectedRole === 'INVESTOR' ? 50000 : selectedRole === 'TRADER' ? 35000 : 15000;
        const randomHex = Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
        
        user = {
          id: safeUid,
          name: capName || (isEs ? "Usuario Milpa" : "Milpa User"),
          email: loginEmail.trim().toLowerCase(),
          role: selectedRole,
          balance: initialBal,
          avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(capName || 'Milpa')}&background=${selectedRole === 'INVESTOR' ? '0284c7' : selectedRole === 'TRADER' ? 'f59e0b' : '059669'}&color=fff&bold=true`,
          walletAddress: externalWalletAddress || `0x${randomHex}`,
          location: "México",
          bio: selectedRole === 'PRODUCER'
            ? (isEs ? "Productor agrícola registrado en Milpa Tech." : "Agricultural producer registered on Milpa Tech.")
            : selectedRole === 'INVESTOR'
            ? (isEs ? "Inversionista de cosechas tokenizadas." : "Tokenized harvest investor.")
            : (isEs ? "Comercializador y comprador en Marketplace." : "Marketplace buyer and trader."),
          joinedDate: new Date().toLocaleDateString(isEs ? 'es-MX' : 'en-US', { month: 'short', year: 'numeric' }),
          rating: 5.0
        };
        await setDoc(userRef, sanitizeForFirestore(user));
      }

      notifySuccess(user, isEs ? `¡Bienvenido, ${user.name}!` : `Welcome, ${user.name}!`);
      onClose();
    } catch (err: any) {
      console.error("Login error:", err);
      setAuthError(isEs ? "Error al procesar el inicio de sesión." : "Error processing login.");
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Submit Sign Up / Create New User
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName.trim()) {
      setAuthError(isEs ? "Por favor ingresa tu Nombre Completo o Razón Social." : "Please enter your Full Name or Company Name.");
      return;
    }
    if (!regEmail.trim()) {
      setAuthError(isEs ? "Por favor ingresa un correo electrónico válido." : "Please enter a valid email.");
      return;
    }
    if (!regTermsAccepted) {
      setAuthError(isEs ? "Debes aceptar los términos y condiciones de la plataforma." : "You must accept the terms and conditions.");
      return;
    }

    setIsRegistering(true);
    setAuthError(null);

    const newUserId = `user-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const randomHex = Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
    const assignedWallet = externalWalletAddress || `0x${randomHex}`;
    
    // Initial balances based on role
    const initialBal = selectedRole === 'INVESTOR' ? 50000 : selectedRole === 'TRADER' ? 35000 : 15000;

    const bgColors = {
      PRODUCER: '059669',
      INVESTOR: '0284c7',
      TRADER: 'f59e0b'
    };

    const newUser: UserProfile = {
      id: newUserId,
      name: regName.trim(),
      email: regEmail.trim().toLowerCase(),
      role: selectedRole,
      balance: initialBal,
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(regName.trim())}&background=${bgColors[selectedRole]}&color=fff&bold=true`,
      walletAddress: assignedWallet,
      location: regLocation.trim() || "México",
      phone: regPhone.trim() || undefined,
      bio: regBio.trim() || (selectedRole === 'PRODUCER'
        ? (isEs ? `Productor agrícola con ${regHectares} hectáreas dedicadas al cultivo sustentable.` : `Agricultural producer with ${regHectares} hectares dedicated to sustainable cultivation.`)
        : selectedRole === 'INVESTOR'
        ? (isEs ? "Inversionista enfocado en democratizar el financiamiento agrícola en México." : "Investor focused on democratizing agricultural financing in Mexico.")
        : (isEs ? `Comprador y comercializador con capacidad de operación de $${regVolume.toLocaleString()} MXN.` : `Marketplace buyer & trader with trading volume of $${regVolume.toLocaleString()} MXN.`)),
      farmHectares: selectedRole === 'PRODUCER' ? Number(regHectares) || 10 : undefined,
      tradingVolume: selectedRole === 'TRADER' ? Number(regVolume) || 50000 : undefined,
      experienceYears: selectedRole === 'PRODUCER' ? 10 : selectedRole === 'TRADER' ? 8 : 5,
      certifications: selectedRole === 'PRODUCER' ? ['Certificación Orgánica', 'Comercio Justo'] : undefined,
      rating: 5.0,
      joinedDate: new Date().toLocaleDateString(isEs ? 'es-MX' : 'en-US', { month: 'short', year: 'numeric' })
    };

    try {
      // Save directly into Firestore users collection with sanitized data
      await setDoc(doc(db, 'users', newUserId), sanitizeForFirestore(newUser));
      notifySuccess(
        newUser,
        isEs
          ? `🎉 ¡Cuenta creada con éxito! Bienvenido a Milpa Tech como ${selectedRole === 'PRODUCER' ? 'Productor' : selectedRole === 'INVESTOR' ? 'Inversionista' : 'Comprador/Vendedor'}.`
          : `🎉 Account created successfully! Welcome to Milpa Tech as a ${selectedRole === 'PRODUCER' ? 'Producer' : selectedRole === 'INVESTOR' ? 'Investor' : 'Trader'}.`
      );
      onClose();
    } catch (err: any) {
      console.error("Registration error:", err);
      // Fallback local save if offline
      notifySuccess(
        newUser,
        isEs
          ? `¡Bienvenido(a) a Milpa Tech, ${newUser.name}!`
          : `Welcome to Milpa Tech, ${newUser.name}!`
      );
      onClose();
    } finally {
      setIsRegistering(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 overflow-y-auto animate-fade-in" id="auth-modal">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden border border-slate-200 text-left my-6 flex flex-col max-h-[92vh]">
        
        {/* Top Header */}
        <div className="p-6 bg-gradient-to-r from-slate-950 via-emerald-950 to-slate-900 text-white flex justify-between items-center shrink-0 border-b border-emerald-900/50">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-xl text-white">
                  {mode === 'LOGIN'
                    ? (isEs ? "Acceso a la Plataforma" : "Platform Access")
                    : (isEs ? "Registro de Nuevo Usuario" : "New User Registration")}
                </h3>
                <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                  Web3 & Agro
                </span>
              </div>
              <p className="text-emerald-200/80 text-xs font-semibold mt-0.5">
                {isEs
                  ? "Soberanía alimentaria, tokenización de cosechas e inversión transparente"
                  : "Food sovereignty, crop tokenization & transparent regenerative investment"}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 text-slate-400 hover:text-white rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher: Iniciar Sesión vs Registrarse */}
        <div className="grid grid-cols-2 border-b border-slate-200 bg-slate-50 shrink-0">
          <button
            onClick={() => { setMode('LOGIN'); setAuthError(null); }}
            className={`py-3.5 text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 border-b-2 ${
              mode === 'LOGIN'
                ? 'border-emerald-600 text-emerald-700 bg-white shadow-sm'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <User className="w-4 h-4" />
            <span>{isEs ? "Iniciar Sesión" : "Sign In"}</span>
          </button>

          <button
            onClick={() => { setMode('REGISTER'); setAuthError(null); }}
            className={`py-3.5 text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 border-b-2 ${
              mode === 'REGISTER'
                ? 'border-emerald-600 text-emerald-700 bg-white shadow-sm'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>{isEs ? "Crear Nueva Cuenta" : "Create Account"}</span>
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 md:p-8 overflow-y-auto space-y-6 flex-1">
          
          {/* Error Message Box */}
          {authError && (
            <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-2xl text-xs font-bold flex items-center gap-3 animate-shake">
              <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
              <span>{authError}</span>
            </div>
          )}

          {/* ======================= MODE: LOGIN ======================= */}
          {mode === 'LOGIN' && (
            <div className="space-y-6">
              
              {/* Google Sign-in Primary Button */}
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={isLoggingIn}
                className="w-full bg-white hover:bg-slate-50 text-slate-800 py-3.5 px-4 rounded-2xl font-black text-sm transition-all border-2 border-slate-200 hover:border-slate-300 shadow-md flex items-center justify-center gap-3 active:scale-[0.99] disabled:opacity-50"
              >
                {isLoggingIn ? (
                  <Loader2 className="w-5 h-5 animate-spin text-emerald-600" />
                ) : (
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                  </svg>
                )}
                <span>{isEs ? "Continuar con Google" : "Continue with Google"}</span>
              </button>

              <div className="relative flex py-1 items-center">
                <div className="flex-grow border-t border-slate-200"></div>
                <span className="flex-shrink mx-4 text-slate-400 text-xs font-black uppercase tracking-wider">
                  {isEs ? "o con correo registrado" : "or with registered email"}
                </span>
                <div className="flex-grow border-t border-slate-200"></div>
              </div>

              {/* Email Login Form */}
              <form onSubmit={handleEmailLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    {isEs ? "Correo Electrónico" : "Email Address"}
                  </label>
                  <div className="relative">
                    <Mail className="w-5 h-5 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="email"
                      required
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      placeholder="ejemplo@milpatech.com"
                      className="w-full pl-11 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    {isEs ? "Contraseña / PIN de Acceso" : "Password / Access PIN"}
                  </label>
                  <div className="relative">
                    <Lock className="w-5 h-5 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="password"
                      required
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-11 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all font-medium"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoggingIn}
                  className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm rounded-xl transition-all shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 active:scale-[0.99]"
                >
                  {isLoggingIn ? <Loader2 className="w-5 h-5 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
                  <span>{isEs ? "Entrar a mi Cuenta" : "Log In to Account"}</span>
                </button>
              </form>

              {/* 1-Click Fast Demo Role Access */}
              <div className="pt-4 border-t border-slate-200">
                <p className="text-xs font-black uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>{isEs ? "Acceso Inmediato de Prueba (1-Clic por Rol):" : "1-Click Instant Demo Profiles:"}</span>
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Producer Card */}
                  <button
                    type="button"
                    onClick={() => handleFastDemoLogin('PRODUCER')}
                    className="p-3 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-2xl text-left transition-all group flex flex-col justify-between"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                        🌾
                      </div>
                      <div>
                        <span className="font-extrabold text-xs text-emerald-900 block leading-tight">Don Mateo</span>
                        <span className="text-[10px] font-bold text-emerald-700">{isEs ? "Productor" : "Producer"}</span>
                      </div>
                    </div>
                    <span className="text-[10px] text-emerald-800 font-semibold bg-emerald-200/60 px-2 py-0.5 rounded-md inline-block">
                      {isEs ? "Cosechas & Lotes" : "Crops & Plots"}
                    </span>
                  </button>

                  {/* Investor Card */}
                  <button
                    type="button"
                    onClick={() => handleFastDemoLogin('INVESTOR')}
                    className="p-3 bg-cyan-50 hover:bg-cyan-100 border border-cyan-200 rounded-2xl text-left transition-all group flex flex-col justify-between"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-7 h-7 rounded-lg bg-cyan-600 text-white flex items-center justify-center font-bold text-xs">
                        💎
                      </div>
                      <div>
                        <span className="font-extrabold text-xs text-cyan-900 block leading-tight">Sofía M.</span>
                        <span className="text-[10px] font-bold text-cyan-700">{isEs ? "Inversionista" : "Investor"}</span>
                      </div>
                    </div>
                    <span className="text-[10px] text-cyan-800 font-semibold bg-cyan-200/60 px-2 py-0.5 rounded-md inline-block">
                      $50K MXN Demo
                    </span>
                  </button>

                  {/* Trader Card */}
                  <button
                    type="button"
                    onClick={() => handleFastDemoLogin('TRADER')}
                    className="p-3 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-2xl text-left transition-all group flex flex-col justify-between"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-7 h-7 rounded-lg bg-amber-600 text-white flex items-center justify-center font-bold text-xs">
                        🛒
                      </div>
                      <div>
                        <span className="font-extrabold text-xs text-amber-900 block leading-tight">AgroValle</span>
                        <span className="text-[10px] font-bold text-amber-700">{isEs ? "Comercializador" : "Trader"}</span>
                      </div>
                    </div>
                    <span className="text-[10px] text-amber-800 font-semibold bg-amber-200/60 px-2 py-0.5 rounded-md inline-block">
                      {isEs ? "Marketplace B2B" : "B2B Marketplace"}
                    </span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ======================= MODE: REGISTER ======================= */}
          {mode === 'REGISTER' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-6">
              
              {/* STEP 1: Select Platform Role */}
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-2.5 flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-emerald-600" />
                  <span>{isEs ? "1. Selecciona tu Tipo de Perfil en la Plataforma:" : "1. Select your Platform Profile Role:"}</span>
                </label>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {/* Role 1: PRODUCER */}
                  <div
                    onClick={() => setSelectedRole('PRODUCER')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between relative ${
                      selectedRole === 'PRODUCER'
                        ? 'border-emerald-600 bg-emerald-50/80 shadow-md shadow-emerald-600/10'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    {selectedRole === 'PRODUCER' && (
                      <div className="absolute top-2.5 right-2.5 w-5 h-5 bg-emerald-600 text-white rounded-full flex items-center justify-center">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      </div>
                    )}
                    <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-2 font-black text-lg">
                      🌾
                    </div>
                    <div>
                      <h4 className="font-black text-sm text-slate-900">{isEs ? "Productor Agrícola" : "Agricultural Producer"}</h4>
                      <p className="text-[11px] text-slate-600 mt-1 leading-snug">
                        {isEs ? "Tokeniza tus cosechas, solicita financiamiento semilla y gestiona parcelas con sensores IoT." : "Tokenize harvests, get seed funding and manage sensorized plots."}
                      </p>
                    </div>
                    <div className="mt-3 pt-2 border-t border-emerald-200/60 text-[10px] font-bold text-emerald-800">
                      {isEs ? "Bono inicio: $15,000 MXN" : "Starting: $15,000 MXN"}
                    </div>
                  </div>

                  {/* Role 2: INVESTOR */}
                  <div
                    onClick={() => setSelectedRole('INVESTOR')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between relative ${
                      selectedRole === 'INVESTOR'
                        ? 'border-cyan-600 bg-cyan-50/80 shadow-md shadow-cyan-600/10'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    {selectedRole === 'INVESTOR' && (
                      <div className="absolute top-2.5 right-2.5 w-5 h-5 bg-cyan-600 text-white rounded-full flex items-center justify-center">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      </div>
                    )}
                    <div className="w-10 h-10 rounded-xl bg-cyan-100 text-cyan-800 flex items-center justify-center mb-2 font-black text-lg">
                      💎
                    </div>
                    <div>
                      <h4 className="font-black text-sm text-slate-900">{isEs ? "Inversionista de Impacto" : "Impact Investor"}</h4>
                      <p className="text-[11px] text-slate-600 mt-1 leading-snug">
                        {isEs ? "Financia cultivos regenerativos con rendimiento anual estimado y respaldo real de la cosecha." : "Fund regenerative crops with estimated APY and real harvest backing."}
                      </p>
                    </div>
                    <div className="mt-3 pt-2 border-t border-cyan-200/60 text-[10px] font-bold text-cyan-800">
                      {isEs ? "Bono inicio: $50,000 MXN" : "Starting: $50,000 MXN"}
                    </div>
                  </div>

                  {/* Role 3: TRADER */}
                  <div
                    onClick={() => setSelectedRole('TRADER')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between relative ${
                      selectedRole === 'TRADER'
                        ? 'border-amber-600 bg-amber-50/80 shadow-md shadow-amber-600/10'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    {selectedRole === 'TRADER' && (
                      <div className="absolute top-2.5 right-2.5 w-5 h-5 bg-amber-600 text-white rounded-full flex items-center justify-center">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      </div>
                    )}
                    <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center mb-2 font-black text-lg">
                      🛒
                    </div>
                    <div>
                      <h4 className="font-black text-sm text-slate-900">{isEs ? "Comprador / Vendedor" : "Marketplace Trader"}</h4>
                      <p className="text-[11px] text-slate-600 mt-1 leading-snug">
                        {isEs ? "Comercializador de granos y lotes en secundario con liquidación en USDC o MXN." : "Trade crop lots on secondary market with instant settlement."}
                      </p>
                    </div>
                    <div className="mt-3 pt-2 border-t border-amber-200/60 text-[10px] font-bold text-amber-800">
                      {isEs ? "Bono inicio: $35,000 MXN" : "Starting: $35,000 MXN"}
                    </div>
                  </div>
                </div>
              </div>

              {/* STEP 2: Profile & Account Information */}
              <div className="space-y-4 pt-2">
                <label className="block text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <User className="w-4 h-4 text-emerald-600" />
                  <span>{isEs ? "2. Datos de Cuenta & Identificación:" : "2. Account & Identity Info:"}</span>
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Full Name */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {isEs ? "Nombre Completo o Razón Social *" : "Full Name or Company Name *"}
                    </label>
                    <input
                      type="text"
                      required
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      placeholder={selectedRole === 'PRODUCER' ? "Ej. Agrícola Santa María de Oaxaca" : selectedRole === 'TRADER' ? "Ej. Granos y Derivados del Centro S.A." : "Ej. Lic. Fernando García Morales"}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none font-medium"
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {isEs ? "Correo Electrónico *" : "Email Address *"}
                    </label>
                    <input
                      type="email"
                      required
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="usuario@ejemplo.com"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none font-medium"
                    />
                  </div>

                  {/* Password */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {isEs ? "Contraseña / Clave de Acceso *" : "Password / Passcode *"}
                    </label>
                    <input
                      type="password"
                      required
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none font-medium"
                    />
                  </div>

                  {/* Location */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {isEs ? "Ubicación (Estado / Región)" : "Location (State / Region)"}
                    </label>
                    <input
                      type="text"
                      value={regLocation}
                      onChange={(e) => setRegLocation(e.target.value)}
                      placeholder="Oaxaca, México"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none font-medium"
                    />
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {isEs ? "Teléfono de Contacto" : "Contact Phone"}
                    </label>
                    <input
                      type="tel"
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      placeholder="+52 951 123 4567"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none font-medium"
                    />
                  </div>

                  {/* Role Specific Field: Hectares or Volume */}
                  {selectedRole === 'PRODUCER' && (
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {isEs ? "Hectáreas Cultivables de la Parcela" : "Farm Cultivable Hectares"}
                      </label>
                      <input
                        type="number"
                        min={1}
                        value={regHectares}
                        onChange={(e) => setRegHectares(Number(e.target.value))}
                        className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none font-medium"
                      />
                    </div>
                  )}

                  {selectedRole === 'TRADER' && (
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {isEs ? "Volumen Estimado de Compra/Venta Mensual (MXN)" : "Estimated Monthly Trading Volume (MXN)"}
                      </label>
                      <input
                        type="number"
                        step={5000}
                        value={regVolume}
                        onChange={(e) => setRegVolume(Number(e.target.value))}
                        className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none font-medium"
                      />
                    </div>
                  )}

                  {/* Web3 Wallet info */}
                  <div className="sm:col-span-2 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                        <Wallet className="w-4 h-4 text-amber-500" />
                        <span>{isEs ? "Billetera Digital Polygon (Web3 / MetaMask):" : "Polygon Web3 / MetaMask Wallet:"}</span>
                      </span>
                      {onOpenWalletConnect && (
                        <button
                          type="button"
                          onClick={onOpenWalletConnect}
                          className="text-[11px] font-extrabold text-emerald-700 hover:text-emerald-800 underline"
                        >
                          {externalWalletAddress ? (isEs ? "Cambiar Billetera" : "Change Wallet") : (isEs ? "Conectar MetaMask" : "Connect MetaMask")}
                        </button>
                      )}
                    </div>
                    <div className="text-xs font-mono text-slate-600 truncate bg-white p-2.5 rounded-xl border border-slate-200">
                      {externalWalletAddress ? externalWalletAddress : (isEs ? "🦊 Se generará automáticamente una billetera Polygon segura para esta cuenta." : "🦊 A secure Polygon wallet will be auto-generated for this account.")}
                    </div>
                  </div>
                </div>
              </div>

              {/* Terms Checkbox */}
              <div className="p-3.5 bg-emerald-50/70 border border-emerald-200 rounded-2xl">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={regTermsAccepted}
                    onChange={(e) => setRegTermsAccepted(e.target.checked)}
                    className="mt-0.5 w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                  />
                  <span className="text-xs text-slate-700 font-medium leading-relaxed">
                    {isEs
                      ? "Acepto los términos de gobernanza comunitaria de Milpa Tech, validación descentralizada de cosechas y el almacenamiento seguro de perfil en Firestore."
                      : "I accept the community governance terms of Milpa Tech, decentralized harvest validation, and profile storage in Firestore."}
                  </span>
                </label>
              </div>

              {/* Submit Register Button */}
              <button
                type="submit"
                disabled={isRegistering}
                className="w-full py-4 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-black text-sm rounded-2xl transition-all shadow-xl shadow-emerald-700/20 flex items-center justify-center gap-2 active:scale-[0.99]"
              >
                {isRegistering ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <CheckCircle className="w-5 h-5" />
                )}
                <span>
                  {isEs
                    ? `Registrarme como ${selectedRole === 'PRODUCER' ? '🌾 Productor' : selectedRole === 'INVESTOR' ? '💎 Inversionista' : '🛒 Comprador/Vendedor'}`
                    : `Register as ${selectedRole === 'PRODUCER' ? '🌾 Producer' : selectedRole === 'INVESTOR' ? '💎 Investor' : '🛒 Trader'}`}
                </span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
