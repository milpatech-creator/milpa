import React, { useState } from 'react';
import {
  X, Image as ImageIcon, Upload, Link2, Check, Sparkles,
  Camera, Eye, AlertCircle, RefreshCw, Layers
} from 'lucide-react';
import { Crop, Language } from '../types';

interface CropImageModalProps {
  crop: Crop | null;
  isOpen: boolean;
  onClose: () => void;
  onSaveImage: (cropId: string, newImageUrl: string) => void;
  lang: Language;
}

interface PresetCategory {
  categoryName: { es: string; en: string };
  items: {
    title: { es: string; en: string };
    url: string;
    description: { es: string; en: string };
  }[];
}

const PRESET_CROP_IMAGES: PresetCategory[] = [
  {
    categoryName: {
      es: "🌽 Maíces Criollos & Granos Ancestrales",
      en: "🌽 Heirloom Corn & Ancient Grains"
    },
    items: [
      {
        title: { es: "Mazorca de Maíz Morado / Azul", en: "Purple & Blue Heirloom Corn" },
        url: "https://images.unsplash.com/photo-1551754655-cd27e38d2076?q=80&w=1200&auto=format&fit=crop",
        description: { es: "Maíz azul y morado nativo de los valles centrales de Oaxaca", en: "Native blue and purple heirloom corn from Oaxaca valleys" }
      },
      {
        title: { es: "Milpa Criolla Tradicional", en: "Traditional Milpa Harvest" },
        url: "https://images.unsplash.com/photo-1530595467537-0b5996c41f2d?q=80&w=1200&auto=format&fit=crop",
        description: { es: "Cosecha de maíz criollo en mazorca con hojas secas", en: "Harvested heirloom corn cobs in dry husks" }
      },
      {
        title: { es: "Maíz Dorado y Grano Criollo", en: "Golden Corn & Field Kernels" },
        url: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?q=80&w=1200&auto=format&fit=crop",
        description: { es: "Granos dorados agroecológicos secados al sol", en: "Sun-dried golden agroecological corn kernels" }
      },
      {
        title: { es: "Campo de Trigo y Granos Dorados", en: "Golden Wheat & Cereal Field" },
        url: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?q=80&w=1200&auto=format&fit=crop",
        description: { es: "Cultivo de granos en maduración con cielo despejado", en: "Ripening grain crops with clear sky" }
      }
    ]
  },
  {
    categoryName: {
      es: "🌵 Agaves, Magueyes & Mezcal",
      en: "🌵 Agave, Maguey & Mezcal Fields"
    },
    items: [
      {
        title: { es: "Agave Espadín en Campo Oaxaqueño", en: "Agave Espadín in Oaxacan Field" },
        url: "https://images.unsplash.com/photo-1569428034239-f9565e32e224?q=80&w=1200&auto=format&fit=crop",
        description: { es: "Maguey espadín maduro en terrazas agrícolas de Oaxaca", en: "Mature espadin maguey on agricultural terraces of Oaxaca" }
      },
      {
        title: { es: "Plantación de Agave Azul en Hileras", en: "Blue Agave Rows Landscape" },
        url: "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?q=80&w=1200&auto=format&fit=crop",
        description: { es: "Paisaje agavero con iluminación natural de atardecer", en: "Agave landscape with natural golden hour lighting" }
      },
      {
        title: { es: "Piña de Agave y Jimado", en: "Harvested Agave Heart (Piña)" },
        url: "https://images.unsplash.com/photo-1527061011665-3652c757a4d4?q=80&w=1200&auto=format&fit=crop",
        description: { es: "Piña de agave lista para cocción artesanal", en: "Agave heart ready for artisanal roasting" }
      }
    ]
  },
  {
    categoryName: {
      es: "☕ Café de Sombra & Cacao",
      en: "☕ Shade Coffee & Cocoa Groves"
    },
    items: [
      {
        title: { es: "Cerezas Rojas de Café Arábica", en: "Ripe Red Coffee Cherries" },
        url: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=1200&auto=format&fit=crop",
        description: { es: "Cerezas maduras recolectadas a mano en bosque de niebla", en: "Hand-picked ripe coffee cherries in cloud forest" }
      },
      {
        title: { es: "Finca Cafetalera Agroforestal", en: "Agroforestry Coffee Farm" },
        url: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?q=80&w=1200&auto=format&fit=crop",
        description: { es: "Plantación de café de altura bajo dosel arbóreo", en: "Highland shade-grown coffee plantation" }
      },
      {
        title: { es: "Cacao Criollo en Árbol", en: "Heirloom Cacao Pods on Tree" },
        url: "https://images.unsplash.com/photo-1587132137056-bfbf0166836e?q=80&w=1200&auto=format&fit=crop",
        description: { es: "Mazorcas de cacao orgánico en selva baja", en: "Organic cacao pods in tropical rainforest" }
      }
    ]
  },
  {
    categoryName: {
      es: "🥑 Frutales & Aguacate Hass",
      en: "🥑 Orchards & Hass Avocado"
    },
    items: [
      {
        title: { es: "Huerta de Aguacate Hass", en: "Hass Avocado Orchard" },
        url: "https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?q=80&w=1200&auto=format&fit=crop",
        description: { es: "Árboles de aguacate en producción sustentable", en: "Avocado trees under sustainable canopy management" }
      },
      {
        title: { es: "Cítricos y Limón Persa", en: "Persian Lime & Citrus Grove" },
        url: "https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?q=80&w=1200&auto=format&fit=crop",
        description: { es: "Fruta fresca en árbol con follaje verde intenso", en: "Fresh tree fruit with lush green foliage" }
      }
    ]
  },
  {
    categoryName: {
      es: "🌱 Hortalizas, Invernaderos IoT & Chinampas",
      en: "🌱 Vegetables, IoT Greenhouses & Chinampas"
    },
    items: [
      {
        title: { es: "Invernadero Automatizado IoT", en: "IoT Smart Automated Greenhouse" },
        url: "https://images.unsplash.com/photo-1595974482597-4b8da8879bc5?q=80&w=1200&auto=format&fit=crop",
        description: { es: "Cultivo protegido con monitoreo de microclima", en: "Protected farming with microclimate telemetry" }
      },
      {
        title: { es: "Hortalizas y Jitomates Orgánicos", en: "Organic Heirloom Tomatoes & Greens" },
        url: "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?q=80&w=1200&auto=format&fit=crop",
        description: { es: "Cosecha fresca de hortalizas agroecológicas", en: "Fresh agroecological vegetable harvest" }
      },
      {
        title: { es: "Brotes y Plántulas de Campo", en: "Seedlings & Organic Field Sprouts" },
        url: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?q=80&w=1200&auto=format&fit=crop",
        description: { es: "Germinación en suelo fértil enriquecido con biofertilizantes", en: "Sprouts in fertile soil enriched with biofertilizers" }
      }
    ]
  }
];

export const CropImageModal: React.FC<CropImageModalProps> = ({
  crop,
  isOpen,
  onClose,
  onSaveImage,
  lang
}) => {
  if (!isOpen || !crop) return null;

  const [activeTab, setActiveTab] = useState<'presets' | 'upload' | 'url'>('presets');
  const [selectedUrl, setSelectedUrl] = useState<string>(crop.imageUrl);
  const [customUrlInput, setCustomUrlInput] = useState<string>(crop.imageUrl);
  const [uploadFileName, setUploadFileName] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [imageError, setImageError] = useState(false);

  // File Upload Handler (FileReader to Base64 data URL)
  const handleFileSelection = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert(lang === 'es' ? "Por favor selecciona un archivo de imagen válido (PNG, JPG, WEBP)." : "Please select a valid image file (PNG, JPG, WEBP).");
      return;
    }

    if (file.size > 8 * 1024 * 1024) {
      alert(lang === 'es' ? "La imagen es muy pesada (máximo 8 MB)." : "Image file is too large (max 8 MB).");
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        const dataUrl = e.target.result as string;
        setSelectedUrl(dataUrl);
        setCustomUrlInput(dataUrl);
        setUploadFileName(file.name);
        setImageError(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelection(e.dataTransfer.files[0]);
    }
  };

  const handleSave = () => {
    if (!selectedUrl.trim()) return;
    onSaveImage(crop.id, selectedUrl.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-fade-in" id="crop-image-modal">
      <div className="relative w-full max-w-4xl bg-slate-900 border-2 border-emerald-500/40 rounded-3xl shadow-2xl overflow-hidden my-6 text-left flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="p-6 bg-gradient-to-r from-slate-950 via-emerald-950 to-slate-950 border-b border-emerald-500/30 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300">
              <Camera className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400">
                {lang === 'es' ? "Gestor Multimedia de Cultivos" : "Crop Media Manager"}
              </span>
              <h3 className="text-xl font-black text-white leading-snug">
                {lang === 'es' ? "Cambiar Imagen de:" : "Change Image for:"} <span className="text-emerald-300">{crop.name}</span>
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/80 px-6 overflow-x-auto shrink-0">
          <button
            onClick={() => setActiveTab('presets')}
            className={`px-5 py-3.5 text-xs font-black tracking-wider uppercase border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'presets'
                ? 'border-emerald-500 text-emerald-400 bg-emerald-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>{lang === 'es' ? "Galería de Variedades Agrícolas" : "Agricultural Presets Library"}</span>
          </button>

          <button
            onClick={() => setActiveTab('upload')}
            className={`px-5 py-3.5 text-xs font-black tracking-wider uppercase border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'upload'
                ? 'border-emerald-500 text-emerald-400 bg-emerald-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Upload className="w-4 h-4 text-emerald-400" />
            <span>{lang === 'es' ? "Cargar Foto Local" : "Upload Local Photo"}</span>
          </button>

          <button
            onClick={() => setActiveTab('url')}
            className={`px-5 py-3.5 text-xs font-black tracking-wider uppercase border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'url'
                ? 'border-emerald-500 text-emerald-400 bg-emerald-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Link2 className="w-4 h-4 text-emerald-400" />
            <span>{lang === 'es' ? "Pegar URL Directa" : "Paste Image URL"}</span>
          </button>
        </div>

        {/* Modal Main Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          
          {/* Top Live Preview Banner */}
          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex flex-col md:flex-row items-center gap-4">
            <div className="relative w-full md:w-56 h-36 rounded-xl overflow-hidden border-2 border-emerald-500/50 bg-slate-900 shrink-0 shadow-lg group">
              <img
                src={selectedUrl}
                alt="Vista Previa"
                onError={() => setImageError(true)}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-slate-900/90 border border-emerald-500/50 text-[10px] font-black text-emerald-300 flex items-center gap-1">
                <Eye className="w-3 h-3" />
                <span>{lang === 'es' ? "Vista Previa" : "Live Preview"}</span>
              </div>
            </div>

            <div className="flex-1 space-y-1.5 text-left w-full">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-black uppercase">
                  {crop.type}
                </span>
                <span className="text-xs text-slate-400 font-mono">ID: {crop.id}</span>
              </div>
              <h4 className="text-lg font-black text-white">{crop.name}</h4>
              <p className="text-xs text-slate-400 line-clamp-2">{crop.description}</p>
              <p className="text-[11px] font-mono text-emerald-400/90 truncate pt-1">
                URL: {selectedUrl.startsWith('data:') ? 'imagen_cargada_localmente.data' : selectedUrl}
              </p>
            </div>
          </div>

          {/* TAB 1: PRESET GALLERY */}
          {activeTab === 'presets' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <p className="text-xs text-slate-300 font-semibold">
                  {lang === 'es'
                    ? "Selecciona una fotografía fotográfica de alta resolución representativa de tu cultivo:"
                    : "Select a high-resolution photograph representative of your crop:"}
                </p>
              </div>

              <div className="space-y-6">
                {PRESET_CROP_IMAGES.map((cat, catIdx) => (
                  <div key={catIdx} className="space-y-3">
                    <h5 className="text-xs font-black uppercase tracking-wider text-emerald-400 flex items-center gap-2">
                      <span>{cat.categoryName[lang]}</span>
                    </h5>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                      {cat.items.map((item, itemIdx) => {
                        const isSelected = selectedUrl === item.url;
                        return (
                          <div
                            key={itemIdx}
                            onClick={() => {
                              setSelectedUrl(item.url);
                              setCustomUrlInput(item.url);
                              setImageError(false);
                            }}
                            className={`group relative rounded-2xl overflow-hidden border-2 cursor-pointer transition-all duration-200 bg-slate-950 flex flex-col ${
                              isSelected
                                ? 'border-emerald-400 shadow-lg shadow-emerald-500/20 ring-2 ring-emerald-400/30'
                                : 'border-slate-800 hover:border-emerald-500/50 hover:scale-[1.02]'
                            }`}
                          >
                            <div className="relative aspect-video w-full overflow-hidden bg-slate-900">
                              <img
                                src={item.url}
                                alt={item.title[lang]}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                              />
                              {isSelected && (
                                <div className="absolute top-2 right-2 p-1.5 rounded-full bg-emerald-500 text-slate-950 shadow-md">
                                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                                </div>
                              )}
                            </div>

                            <div className="p-3 flex-1 flex flex-col justify-between">
                              <div>
                                <h6 className="text-xs font-black text-white group-hover:text-emerald-300 transition-colors">
                                  {item.title[lang]}
                                </h6>
                                <p className="text-[10px] text-slate-400 mt-0.5 line-clamp-2 leading-relaxed">
                                  {item.description[lang]}
                                </p>
                              </div>

                              <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px]">
                                <span className={isSelected ? 'text-emerald-400 font-bold' : 'text-slate-500'}>
                                  {isSelected ? (lang === 'es' ? '✓ Seleccionada' : '✓ Selected') : (lang === 'es' ? 'Clic para elegir' : 'Click to select')}
                                </span>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: LOCAL FILE UPLOAD */}
          {activeTab === 'upload' && (
            <div className="space-y-4">
              <div
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-3xl p-8 text-center transition-all flex flex-col items-center justify-center cursor-pointer ${
                  isDragging
                    ? 'border-emerald-400 bg-emerald-950/40'
                    : 'border-slate-700 bg-slate-950 hover:border-emerald-500/60 hover:bg-slate-900/60'
                }`}
                onClick={() => document.getElementById('crop-file-input')?.click()}
              >
                <input
                  id="crop-file-input"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      handleFileSelection(e.target.files[0]);
                    }
                  }}
                />

                <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-3 shadow-inner">
                  <Upload className="w-8 h-8 animate-pulse" />
                </div>

                <h4 className="text-base font-black text-white mb-1">
                  {lang === 'es' ? "Arrastra una imagen de tu cultivo aquí o haz clic para explorar" : "Drag a crop image here or click to browse"}
                </h4>
                <p className="text-xs text-slate-400 max-w-sm mb-4">
                  {lang === 'es'
                    ? "Formatos soportados: JPG, PNG, WEBP. Se optimizará y guardará inmediatamente en tu catálogo."
                    : "Supported formats: JPG, PNG, WEBP. Optimized and saved instantly to your catalog."}
                </p>

                <button
                  type="button"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black shadow-lg shadow-emerald-900/30 transition-all flex items-center gap-2"
                >
                  <Camera className="w-4 h-4" />
                  <span>{lang === 'es' ? "Seleccionar desde Dispositivo" : "Choose from Device"}</span>
                </button>

                {uploadFileName && (
                  <div className="mt-4 px-3.5 py-1.5 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2">
                    <Check className="w-3.5 h-3.5" />
                    <span>{uploadFileName}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: DIRECT IMAGE URL */}
          {activeTab === 'url' && (
            <div className="space-y-4">
              <div className="p-5 bg-slate-950 rounded-2xl border border-slate-800 space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                    {lang === 'es' ? "Enlace directo de la imagen (HTTPS):" : "Direct Image URL (HTTPS):"}
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      value={customUrlInput}
                      onChange={(e) => {
                        setCustomUrlInput(e.target.value);
                        setSelectedUrl(e.target.value);
                        setImageError(false);
                      }}
                      placeholder="https://images.unsplash.com/..."
                      className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedUrl(customUrlInput);
                      }}
                      className="px-4 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black flex items-center gap-1.5"
                    >
                      <Eye className="w-4 h-4" />
                      <span>{lang === 'es' ? "Probar" : "Test"}</span>
                    </button>
                  </div>
                </div>

                {imageError && (
                  <div className="p-3 bg-rose-950/80 border border-rose-500/50 rounded-xl text-rose-300 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{lang === 'es' ? "No se pudo cargar la imagen desde este enlace. Verifica que la URL sea pública y accesible." : "Could not load image from this URL. Please ensure the link is public."}</span>
                  </div>
                )}

                <div className="pt-2 border-t border-slate-800">
                  <span className="text-[11px] font-bold text-slate-400 block mb-2">
                    {lang === 'es' ? "Enlaces de prueba recomendados:" : "Recommended test links:"}
                  </span>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const url = "https://images.unsplash.com/photo-1551754655-cd27e38d2076?q=80&w=1200&auto=format&fit=crop";
                        setCustomUrlInput(url);
                        setSelectedUrl(url);
                        setImageError(false);
                      }}
                      className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-[11px] font-semibold"
                    >
                      🌽 Maíz Morado Unsplash
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const url = "https://images.unsplash.com/photo-1569428034239-f9565e32e224?q=80&w=1200&auto=format&fit=crop";
                        setCustomUrlInput(url);
                        setSelectedUrl(url);
                        setImageError(false);
                      }}
                      className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-[11px] font-semibold"
                    >
                      🌵 Agave Espadín Unsplash
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const url = "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=1200&auto=format&fit=crop";
                        setCustomUrlInput(url);
                        setSelectedUrl(url);
                        setImageError(false);
                      }}
                      className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-[11px] font-semibold"
                    >
                      ☕ Café Arábica Unsplash
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer Actions */}
        <div className="p-5 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-4 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 border border-slate-700 text-slate-300 hover:bg-slate-800 rounded-xl text-xs font-bold transition-colors"
          >
            {lang === 'es' ? "Cancelar" : "Cancel"}
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="px-6 py-2.5 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white rounded-xl text-xs font-black shadow-lg shadow-emerald-900/40 transition-all flex items-center gap-2"
          >
            <Check className="w-4 h-4" />
            <span>{lang === 'es' ? "Guardar y Actualizar Cultivo" : "Save & Update Crop Image"}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
