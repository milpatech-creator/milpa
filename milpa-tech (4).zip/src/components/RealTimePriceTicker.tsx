import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, RefreshCw, Activity, Zap, DollarSign } from 'lucide-react';
import { Crop, Language } from '../types';

interface RealTimePriceTickerProps {
  crops: Crop[];
  lang: Language;
  onSimulatePriceUpdate?: () => void;
}

export const RealTimePriceTicker: React.FC<RealTimePriceTickerProps> = ({
  crops,
  lang,
  onSimulatePriceUpdate
}) => {
  const [isLive, setIsLive] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setLastUpdated(now.toLocaleTimeString(lang === 'es' ? 'es-MX' : 'en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      }));
    };
    updateTime();
    const timer = setInterval(updateTime, 3000);
    return () => clearInterval(timer);
  }, [lang]);

  return (
    <div className="bg-slate-950 border-b border-emerald-900/50 text-white px-4 py-2 text-xs overflow-hidden shadow-md">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
        
        {/* Live Status Badge */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-950/90 border border-emerald-500/40 text-emerald-400 font-extrabold text-[11px] tracking-wider uppercase">
            <span className="relative flex h-2 w-2">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 ${isLive ? '' : 'hidden'}`}></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <Activity className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>{lang === 'es' ? "Precios Agrícolas en Tiempo Real" : "Real-Time Crop Prices"}</span>
          </div>

          <span className="hidden md:inline-block text-[10px] text-slate-400 font-mono">
            {lang === 'es' ? "Última act:" : "Updated:"} {lastUpdated}
          </span>
        </div>

        {/* Ticker Row */}
        <div className="flex items-center gap-6 overflow-x-auto w-full sm:w-auto py-1 scrollbar-none">
          {crops.map((crop) => {
            const price = crop.tokenPrice;
            const change = crop.priceChange24h ?? 2.5;
            const isPositive = change >= 0;

            return (
              <div key={crop.id} className="flex items-center gap-2 shrink-0 bg-slate-900/80 px-3 py-1 rounded-xl border border-slate-800/80 hover:border-emerald-500/40 transition-all">
                <span className="font-extrabold text-slate-200 text-xs truncate max-w-[120px]">{crop.name}</span>
                <span className="font-mono text-emerald-300 font-bold">${price.toFixed(2)}</span>
                
                <span className={`flex items-center text-[10px] font-extrabold px-1.5 py-0.5 rounded-md ${
                  isPositive
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                    : 'bg-rose-950 text-rose-400 border border-rose-500/30'
                }`}>
                  {isPositive ? <TrendingUp className="w-3 h-3 mr-0.5" /> : <TrendingDown className="w-3 h-3 mr-0.5" />}
                  {isPositive ? `+${change.toFixed(1)}%` : `${change.toFixed(1)}%`}
                </span>
              </div>
            );
          })}
        </div>

        {/* Live Simulation Control */}
        <div className="flex items-center gap-2 shrink-0">
          {onSimulatePriceUpdate && (
            <button
              onClick={onSimulatePriceUpdate}
              className="px-2.5 py-1 bg-emerald-900/40 hover:bg-emerald-800/60 border border-emerald-500/30 text-emerald-300 rounded-lg text-[11px] font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
              title={lang === 'es' ? "Simular fluctuación de mercado en vivo" : "Simulate live market price fluctuation"}
            >
              <Zap className="w-3 h-3 text-amber-400" />
              <span>{lang === 'es' ? "Simular Mercado" : "Simulate Prices"}</span>
            </button>
          )}

          <button
            onClick={() => setIsLive(!isLive)}
            className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase transition-all ${
              isLive ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'
            }`}
          >
            {isLive ? (lang === 'es' ? 'En Vivo' : 'Live') : (lang === 'es' ? 'Pausado' : 'Paused')}
          </button>
        </div>

      </div>
    </div>
  );
};
